"""Planilla de viáticos: un Excel por mes, con trabajadores de cualquier obra, y que se sube a la app.

- 28-10-2026: primera versión, una planilla por obra.
- 29-10-2026 (pedido del usuario): una sola planilla para todas las obras. El trabajador se elige de una lista
  desplegable (los activos de TALANA) y el RUT se llena solo. Columnas: Monto viático, Pagado (SI / NO) y Comentario.
  En TALANA el monto va a «Viáticos»; si está pagado, también a «Descuento anticipo viático».
"""
import io
import re

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font
from openpyxl.utils import get_column_letter
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.datavalidation import DataValidation

from . import db
from . import planilla_obra as po
from .comun import clave, formatear_rut, nombre_mes, nombre_propio, normalizar_rut, rut_valido

HOJA = "Viáticos"
HOJA_LISTA = "Lista"      # hoja oculta con nombre y RUT de los trabajadores de la lista desplegable
F_ENC, F1 = 6, 7          # encabezado y primera fila
FILAS = 60
COLS = [("N°", 5), ("Trabajador", 40), ("RUT", 14), ("Monto viático", 14), ("Pagado\n(SI / NO)", 11), ("Comentario", 50)]
C_TRAB, C_RUT, C_MONTO, C_PAGADO, C_COM = 3, 4, 5, 6, 7
SI, NO = "SI", "NO"


def nombre_archivo(periodo):
    return f"Viáticos ({nombre_mes(periodo)}).xlsx"


def lista_trabajadores(con):
    """[(nombre en la lista, RUT)] de los trabajadores activos con RUT, de todas las obras. Nombres repetidos llevan el RUT."""
    trab = [t for t in db.trabajadores(con) if t.get("activo") != "No" and t.get("rut")]
    nombres = [nombre_propio(f"{t['nombres']} {t['apellidos']}") for t in trab]
    out = []
    for t, n in zip(trab, nombres):
        rut = formatear_rut(t["rut"])
        out.append((f"{n} ({rut})" if nombres.count(n) > 1 else n, rut))
    return sorted(out, key=lambda x: clave(x[0]))


def generar(con):
    """Planilla del mes en curso. Devuelve (nombre, bytes)."""
    cfg = db.config(con)
    lista = lista_trabajadores(con)
    if not lista:
        raise ValueError("No hay trabajadores activos. Sube primero la exportación de TALANA en Configuración.")
    wb = Workbook()
    ws = wb.active
    ws.title = HOJA
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 2
    for i, (_, w) in enumerate(COLS, start=2):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws["B1"] = f"VIÁTICOS · {nombre_mes(cfg['periodo']).upper()}"
    ws["B1"].font = Font(name=po.FUENTE, size=20, bold=True, color=po.NEGRO)
    ws.row_dimensions[1].height = 34
    ws["B2"] = (f"Período: {cfg['desde']:%d-%m-%Y} al {cfg['hasta']:%d-%m-%Y}. Elige al trabajador (de cualquier obra), "
                "escribe el monto del viático del mes e indica si ya está pagado.")
    ws["B2"].font = Font(name=po.FUENTE, size=10, color=po.GRIS)
    # Mes que lee la app al subir la planilla (bloqueado)
    ws["B4"], ws["C4"] = "Mes:", cfg["periodo"]
    ws["B4"].font = po.FB
    ws["C4"].font = Font(name=po.FUENTE, size=12, bold=True, color=po.VERDE_OSC)
    ws["C4"].number_format = "0"
    ws["C4"].alignment = Alignment(horizontal="left")
    po.logo(ws, "G1")

    # Lista de trabajadores en una hoja oculta; el menú usa un rango con nombre (si apunta directo a otra hoja,
    # Excel lo guarda como extensión x14 y se pierde)
    wl = wb.create_sheet(HOJA_LISTA)
    wl.append(["Trabajador", "RUT"])
    for nom, rut in lista:
        wl.append([nom, rut])
    wl.sheet_state = "hidden"
    wl.protection.sheet = True
    fin = len(lista) + 1
    wb.defined_names["ListaTrabajadores"] = DefinedName("ListaTrabajadores", attr_text=f"{HOJA_LISTA}!$A$2:$A${fin}")

    for i, (t, _) in enumerate(COLS, start=2):
        po.encabezado(ws.cell(F_ENC, i, t), i in (C_TRAB, C_MONTO, C_PAGADO, C_COM))
    ws.row_dimensions[F_ENC].height = 32

    v_trab = DataValidation(type="list", formula1="ListaTrabajadores", allow_blank=True)
    v_trab.error, v_trab.errorTitle = "Elige un trabajador de la lista.", "Trabajador"
    v_monto = DataValidation(type="decimal", operator="greaterThanOrEqual", formula1="0", allow_blank=True)
    v_monto.promptTitle, v_monto.prompt, v_monto.showInputMessage = "Viático", "Monto en pesos del mes (ej: 80000).", True
    v_monto.error = "Escribe solo el número (ej: 80000)."
    v_pag = DataValidation(type="list", formula1=f'"{SI},{NO}"', allow_blank=True)
    v_pag.promptTitle, v_pag.prompt, v_pag.showInputMessage = "Pagado", "SI = ya se le pagó (anticipo). NO = se paga en la liquidación.", True
    v_pag.error = "Elige SI o NO."
    for dv in (v_trab, v_monto, v_pag):
        ws.add_data_validation(dv)

    for k in range(FILAS):
        r = F1 + k
        ws.cell(r, 2, k + 1).font = po.F
        ws.cell(r, 2).alignment = Alignment(horizontal="center")
        ws.cell(r, 2).border = po.B
        ws.cell(r, C_RUT, f'=IF(C{r}="","",IFERROR(VLOOKUP(C{r},{HOJA_LISTA}!$A:$B,2,FALSE),"No está en la lista"))')
        ws.cell(r, C_RUT).font, ws.cell(r, C_RUT).border = po.F, po.B
        ws.cell(r, C_RUT).alignment = Alignment(horizontal="right")
        for c in (C_TRAB, C_MONTO, C_PAGADO, C_COM):
            po.entrada(ws.cell(r, c), "#,##0" if c == C_MONTO else None)
        ws.cell(r, C_PAGADO).alignment = Alignment(horizontal="center")
    v_trab.add(f"C{F1}:C{F1 + FILAS - 1}")
    v_monto.add(f"E{F1}:E{F1 + FILAS - 1}")
    v_pag.add(f"F{F1}:F{F1 + FILAS - 1}")

    r_tot = F1 + FILAS
    rango_m, rango_p = f"E{F1}:E{r_tot - 1}", f"F{F1}:F{r_tot - 1}"
    for i, (txt, f) in enumerate([("Total", f"=SUM({rango_m})"),
                                  ("Pagado (anticipo)", f'=SUMIF({rango_p},"{SI}",{rango_m})'),
                                  ("Por pagar en la liquidación", f'=SUMIF({rango_p},"{NO}",{rango_m})')]):
        ws.cell(r_tot + i, C_TRAB, txt).font = po.FB
        ws.cell(r_tot + i, C_MONTO, f).font = po.FB
        ws.cell(r_tot + i, C_MONTO).number_format = '"$"#,##0'
    ws.cell(r_tot + 4, 2, "Solo se llena lo verde. Elige al trabajador en la lista (aparecen los de todas las obras); el RUT "
                          "sale solo. Pagado: SI si el viático ya se le adelantó, NO si se paga en la liquidación.").font = po.F_NOTA
    ws.freeze_panes = f"C{F1}"
    po.proteger(ws)
    buf = io.BytesIO()
    wb.save(buf)
    return nombre_archivo(cfg["periodo"]), buf.getvalue()


def _numero(v):
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v or "").strip().replace("$", "").replace(".", "").replace(",", ".").replace(" ", "")
    try:
        return float(s) if s else None
    except ValueError:
        return None


def _pagado(v):
    s = clave(v).upper()
    return True if s in ("SI", "S") else False if s in ("NO", "N") else None


def cargar(con, nombre, contenido):
    """Lee la planilla de viáticos llena y reemplaza todos los viáticos del mes en curso."""
    try:
        wb = load_workbook(io.BytesIO(contenido), data_only=True)
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"No se pudo abrir «{nombre}»: {e}") from e
    if HOJA not in wb.sheetnames:
        raise ValueError(f"«{nombre}» no es una planilla de viáticos (falta la hoja «{HOJA}»).")
    ws = wb[HOJA]
    encabezados = [clave(ws.cell(F_ENC, c).value) for c in range(2, 12)]
    if not any(e.startswith("pagado") for e in encabezados):
        raise ValueError("Es la planilla de viáticos anterior (una por obra). Descarga la nueva en la pestaña Viáticos, "
                         "que trae a todos los trabajadores y la columna Pagado.")
    cfg = db.config(con)
    periodo = ws["C4"].value
    if str(periodo) != str(cfg["periodo"]):
        raise ValueError(f"La planilla es de {nombre_mes(periodo) if str(periodo).isdigit() else '(sin mes)'} y el mes en "
                         f"curso es {nombre_mes(cfg['periodo'])}.")
    # Nombre → RUT: la lista que trae la propia planilla y, de respaldo, Trabajadores de la app
    por_nombre = {clave(n): r for n, r in lista_trabajadores(con)}
    if HOJA_LISTA in wb.sheetnames:
        for n, r in wb[HOJA_LISTA].iter_rows(min_row=2, max_col=2, values_only=True):
            if n and r:
                por_nombre[clave(n)] = r
    trabajadores = {normalizar_rut(t["rut"]): t for t in db.trabajadores(con) if t.get("rut")}

    filas, avisos, sin_pagado, vistos = [], [], [], {}
    r = F1
    while r < F1 + 500 and clave(ws.cell(r, C_TRAB).value) != "total":
        nom, rut, monto = ws.cell(r, C_TRAB).value, ws.cell(r, C_RUT).value, _numero(ws.cell(r, C_MONTO).value)
        pagado, com = _pagado(ws.cell(r, C_PAGADO).value), str(ws.cell(r, C_COM).value or "").strip() or None
        r += 1
        if not monto:
            if nom and monto is None and ws.cell(r - 1, C_MONTO).value not in (None, ""):
                avisos.append(f"{nom}: el monto «{ws.cell(r - 1, C_MONTO).value}» no es un número; no se cargó.")
            continue
        quien = str(nom or "").strip() or "(sin trabajador)"
        rut_n = normalizar_rut(rut) if rut_valido(rut) else normalizar_rut(por_nombre.get(clave(nom)) or "")
        if not rut_n or not rut_valido(rut_n):
            avisos.append(f"{quien}: no está en la lista de trabajadores; no se cargó su viático.")
            continue
        if monto < 0:
            avisos.append(f"{quien}: monto negativo; no se cargó.")
            continue
        if pagado is None:
            sin_pagado.append(quien)
            continue
        t = trabajadores.get(rut_n)
        if not t:
            avisos.append(f"{quien} ({formatear_rut(rut_n)}) no está en Trabajadores: su viático se carga igual.")
        vistos[rut_n] = vistos.get(rut_n, 0) + 1
        if vistos[rut_n] == 2:
            avisos.append(f"{quien} aparece más de una vez: sus viáticos se suman.")
        filas.append({"rut": rut_n, "trabajador": nombre_propio(f"{t['nombres']} {t['apellidos']}") if t else quien,
                      "obra": (t or {}).get("obra"), "monto": monto, "pagado": pagado, "comentario": com})
    if sin_pagado:
        raise ValueError("Falta indicar si el viático está pagado (SI / NO) de: " + ", ".join(sin_pagado)
                         + ". Complétalo y vuelve a subir la planilla.")
    if not filas:   # no borrar lo cargado por una planilla vacía o mal llenada; para borrar está «Quitar»
        raise ValueError("La planilla no trae ningún viático para cargar." + (" " + " ".join(avisos) if avisos else ""))
    db.reemplazar_viaticos(con, cfg["periodo"], filas, nombre)
    pag = sum(f["monto"] for f in filas if f["pagado"])
    return {"personas": len(filas), "total": sum(f["monto"] for f in filas), "pagado": pag, "avisos": avisos}
