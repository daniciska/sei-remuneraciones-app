"use strict";

// ------------------------------------------------------------------ estado y utilidades
let E = null;                 // último /api/estado
let vista = "inicio";
let periodoVista = null;      // null = mes en curso; AAAAMM = mes cerrado (solo consulta)
const abiertas = new Set();   // tarjetas abiertas en «La magia»
const filtro = { estado: "todas", obra: "todas" };
let soloRevisar = true;

const $ = (s, r = document) => r.querySelector(s);
const h = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const n = (v, dec = 1) => (v === null || v === undefined || v === "") ? "—"
  : Number(v).toLocaleString("es-CL", { maximumFractionDigits: dec });
const $$ = (v) => (v === null || v === undefined) ? "—" : "$" + Math.round(v).toLocaleString("es-CL");
const fecha = (iso) => { if (!iso) return "—"; const [a, m, d] = iso.slice(0, 10).split("-"); return `${d}-${m}-${a}`; };
const espera = (ms) => new Promise((r) => setTimeout(r, ms));
const MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
const nombreMes = (p) => p ? `${MESES[Number(p) % 100 - 1]} ${Math.floor(Number(p) / 100)}` : "";

async function api(ruta, opciones = {}) {
  const r = await fetch(ruta, opciones);
  const tipo = r.headers.get("Content-Type") || "";
  const datos = tipo.includes("json") ? await r.json() : null;
  if (!r.ok) throw new Error((datos && datos.error) || `Error ${r.status}`);
  return datos;
}

function aviso(msg, error = false) {
  const t = $("#aviso");
  t.textContent = msg;
  t.className = "toast" + (error ? " error" : "");
  t.hidden = false;
  clearTimeout(aviso.t);
  aviso.t = setTimeout(() => (t.hidden = true), error ? 7000 : 3000);
}

const cerrado = () => Boolean(E && E.cerrado);   // mirando un mes cerrado: todo es solo consulta
const qPeriodo = () => periodoVista ? `?periodo=${periodoVista}` : "";

async function refrescar() {
  E = await api("/api/estado" + qPeriodo());
  const sel = $("#selector-mes");
  sel.innerHTML = E.meses.map((m) => `<option value="${m.periodo}">${h(m.mes)}${m.cerrado_el ? " · cerrado" : " · en curso"}</option>`).join("");
  sel.value = String(E.config.periodo);
  $("#mes-rango").textContent = E.config.desde ? `${fecha(E.config.desde)} al ${fecha(E.config.hasta)}` : "";
  const cinta = $("#cinta-cerrado");
  cinta.hidden = !cerrado();
  if (cerrado()) {
    cinta.innerHTML = `<span>📁 <b>${h(E.mes)}</b> está cerrado (el ${fecha(E.cerrado)}). Solo consulta: así quedó al cerrarlo.</span>
      <button class="link" data-mes-actual>Volver al mes en curso</button>`;
    cinta.querySelector("[data-mes-actual]").onclick = () => verMes(null);
  }
  const b = $("#badge-revisar");
  const porRevisar = E.resumen.revisar + (E.resumen.no_informados_pendientes || 0);
  b.textContent = porRevisar;
  b.hidden = !porRevisar;
  pintar();
}

function verMes(periodo) {
  periodoVista = periodo && Number(periodo) !== E.periodo_actual ? Number(periodo) : null;
  abiertas.clear();
  filtro.estado = filtro.obra = "todas";
  refrescar().catch((e) => aviso(e.message, true));
}

function ir(v) {
  vista = v;
  document.querySelectorAll("#tabs button").forEach((b) => b.classList.toggle("activo", b.dataset.vista === v));
  pintar();
  window.scrollTo(0, 0);
}

function pintar() {
  const fn = { inicio: vInicio, cargar: vCargar, magia: vMagia, revision: vRevision, talana: vTalana, casos: vCasos,
    viaticos: vViaticos, reliq: vReliq, trabajadores: vTrabajadores, config: vConfig }[vista];
  $("#vista").innerHTML = fn();
  enlazar();
}

const chipEstado = (e) => `<span class="chip ${e === "OK" ? "ok" : e === "Revisar" ? "revisar" : "revisado"}">${h(e)}</span>`;

// ------------------------------------------------------------------ Inicio
function vInicio() {
  const r = E.resumen;
  const hayArchivos = E.archivos.length > 0;
  const paso = (cond, actual) => cond ? "hecho" : actual ? "actual" : "";
  return `
    <h1>${h(E.mes)}</h1>
    <p class="sub">Período del ${fecha(E.config.desde)} al ${fecha(E.config.hasta)} · días base ${E.config.dias_base}</p>
    <div class="kpis">
      <div class="tarjeta kpi"><div class="kpi-valor">${E.archivos.length}</div><div class="kpi-etiqueta">archivos de obra cargados</div></div>
      <div class="tarjeta kpi"><div class="kpi-valor">${r.trabajadores}</div><div class="kpi-etiqueta">trabajadores van a TALANA</div></div>
      <div class="tarjeta kpi ${r.revisar ? "alerta" : "bien"}"><div class="kpi-valor">${r.revisar}</div><div class="kpi-etiqueta">filas por revisar</div></div>
      <div class="tarjeta kpi"><div class="kpi-valor">${n(r.he)}</div><div class="kpi-etiqueta">horas extra</div></div>
      <div class="tarjeta kpi"><div class="kpi-valor">${$$(r.desgaste)}</div><div class="kpi-etiqueta">desgaste de herramientas</div></div>
    </div>
    ${cerrado() ? `
    <div class="tarjeta listo si">
      <div class="icono">📁</div>
      <div style="flex:1"><b>Mes cerrado el ${fecha(E.cerrado)}</b><br><span class="muted">Archivos: ${E.archivos.map((a) => h(a.nombre)).join(", ")}</span></div>
      <button class="boton sec" data-guardar="/api/talana${qPeriodo()}">Guardar TALANA de ${h(E.mes)} en Descargas</button>
    </div>` : `
    <div class="tarjeta listo ${r.listo ? "si" : "no"}">
      <div class="icono">${r.listo ? "✅" : "⏳"}</div>
      <div style="flex:1"><b>${r.listo ? "Listo para TALANA" : hayArchivos ? "Todavía no está listo para TALANA" : "Empieza cargando los archivos de las obras"}</b><br>
      <span class="muted">${r.listo ? "Todas las filas están OK o revisadas. Descarga la carga, súbela a TALANA y después cierra el mes."
        : hayArchivos ? `Quedan ${r.revisar} fila(s) en «Revisar»${r.no_informados_pendientes ? ` y ${r.no_informados_pendientes} trabajador(es) no informado(s) por su obra sin marcar como vistos` : ""}.` : "Arrastra los Excel que mandó cada obra en la pestaña «3 · Cargar obras»."}</span></div>
      ${r.listo ? `<button class="boton" data-cerrar>Cerrar ${h(E.mes)}</button>` : ""}
    </div>`}
    ${mesesCerrados()}
    ${cerrado() ? "" : `<h2>Los pasos del mes</h2>`}
    ${cerrado() ? "" : `<ol class="pasos">
      <li class="tarjeta ${paso(E.talana_nueva, !E.talana_nueva)}"><div><div class="t">Trabajadores: subir TALANA y armar el Paquete del mes</div><div class="muted">Al empezar el mes: sube la lista de empleados de TALANA y manda a cada obra su planilla (Paquete del mes).</div></div></li>
      <li class="tarjeta ${paso((E.viaticos || []).length, false)}"><div><div class="t">Viáticos</div><div class="muted">Una sola planilla del mes para todas las obras: se llena durante el mes y se sube antes de descargar la carga para TALANA.</div></div></li>
      <li class="tarjeta ${paso(hayArchivos, E.talana_nueva && !hayArchivos)}"><div><div class="t">Cargar las planillas de las obras</div><div class="muted">Arrastra los Excel que mandó cada obra. La app lee el resumen y el detalle diario.</div></div></li>
      <li class="tarjeta ${paso(hayArchivos, false)}"><div><div class="t">Mirar «La magia»</div><div class="muted">Qué se extrajo de cada archivo y cómo se calculó cada trabajador: días, horas extra, fines de semana, tarifas y bonos.</div></div></li>
      <li class="tarjeta ${paso(hayArchivos && !r.revisar, hayArchivos && r.revisar)}"><div><div class="t">Revisar las diferencias</div><div class="muted">Solo las filas en «Revisar»: eliges Obra o Planilla, o escribes el valor correcto.</div></div></li>
      <li class="tarjeta ${paso(false, r.listo)}"><div><div class="t">Descargar la carga para TALANA</div><div class="muted">El archivo «${h(E.archivo_talana)}», listo para subir.</div></div></li>
      <li class="tarjeta ${paso(false, r.listo)}"><div><div class="t">Cerrar el mes</div><div class="muted">Queda guardado para consultarlo cuando quieras (selector de mes, arriba), sus días pasan al historial para detectar días ya pagados, y se abre el mes siguiente.</div></div></li>
    </ol>`}`;
}

function mesesCerrados() {
  const lista = E.meses.filter((m) => m.cerrado_el);
  if (!lista.length) return "";
  return `<h2>Meses cerrados</h2>
    <div class="tarjeta" style="overflow-x:auto"><table class="tabla">
      <thead><tr><th>Mes</th><th>Cerrado el</th><th></th></tr></thead>
      <tbody>${lista.map((m) => `<tr><td><b>${h(m.mes)}</b></td><td>${fecha(m.cerrado_el)}</td>
        <td style="text-align:right">${Number(m.periodo) === Number(E.config.periodo) ? "<span class='muted'>viendo</span>" : `<button class="link" data-ver-mes="${m.periodo}">Ver</button>`}</td></tr>`).join("")}</tbody>
    </table></div>`;
}

function abrirCierre() {
  $("#cierre-titulo").textContent = `Cerrar ${E.mes}`;
  $("#cierre-desde").value = E.siguiente.desde;
  $("#cierre-hasta").value = E.siguiente.hasta;
  $("#dialogo-cierre").hidden = false;
}

async function cerrarMes() {
  const boton = $("#cierre-ok");
  boton.disabled = true;
  try {
    const r = await api("/api/cerrar", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ desde: $("#cierre-desde").value, hasta: $("#cierre-hasta").value }) });
    $("#dialogo-cierre").hidden = true;
    periodoVista = null;
    abiertas.clear();
    await refrescar();
    aviso(`Mes cerrado: ${r.dias_historial} días pasaron al historial. Ahora estás en ${E.mes}.`);
    ir("inicio");
  } catch (e) { aviso(e.message, true); }
  finally { boton.disabled = false; }
}

// ------------------------------------------------------------------ Cargar
function vCargar() {
  const lista = E.archivos.map((a) => {
    const alertas = a.avisos.filter((x) => x.nivel === "alerta");
    const info = a.avisos.filter((x) => x.nivel !== "alerta");
    return `
      <div class="tarjeta archivo">
        <div class="archivo-cab">
          <span class="nombre">${h(a.nombre)}</span>
          <span class="chip gris">${h(a.obra)}</span>
          <span class="muted small">${a.filas} trabajador(es) · ${h(a.formato)}${a.periodo_txt ? " · período en el archivo: " + h(a.periodo_txt) : ""}</span>
          ${cerrado() ? "" : `<span style="margin-left:auto"><button class="link" data-quitar="${a.id}">Quitar</button></span>`}
        </div>
        ${cerrado() ? "" : `<div class="obra-archivo ${a.obra_configurada ? "" : "falta"}">
          ${a.obra_configurada ? "" : `<b>⚠ «${h(a.obra_leida)}» no calza con ninguna obra configurada:</b> sus tarifas y bonos por obra no se aplican. `}
          Obra: <select class="in" data-obra-archivo="${a.id}">
            ${a.obra_configurada ? "" : `<option value="" selected>¿Cuál es?…</option>`}
            ${(E.maestro.obras_configuradas || []).map((o) => `<option ${o === a.obra ? "selected" : ""}>${h(o)}</option>`).join("")}
          </select>
          ${a.obra_leida !== a.obra ? `<span class="muted small">en el archivo dice «${h(a.obra_leida)}» (se recuerda para los meses siguientes)</span>` : ""}
        </div>`}
        ${alertas.length ? `<ul class="avisos">${alertas.map((x) => `<li class="alerta">${h(x.texto)}</li>`).join("")}</ul>` : ""}
        <details><summary>Ver lo que se leyó (${info.length})</summary>
          <ul class="avisos">${info.map((x) => `<li>${h(x.texto)}</li>`).join("")}</ul>
          ${a.columnas.length ? `<p class="muted small">Columnas del resumen: ${a.columnas.map(h).join(" · ")}</p>` : ""}
        </details>
      </div>`;
  }).join("");
  if (cerrado()) return `<h1>Archivos de ${h(E.mes)}</h1><p class="sub">Los que se cargaron antes de cerrar el mes.</p>${lista}${vCuadratura()}`;
  return `
    <h1>Cargar archivos de obra</h1>
    <p class="sub">Arrastra aquí los Excel que mandó cada obra este mes. Si vuelves a subir una obra (por ejemplo «H&M ALC V.2»), reemplaza a la anterior.</p>
    <label class="zona" id="zona">
      <div class="grande">Arrastra los archivos aquí</div>
      <div class="muted">o haz clic para elegirlos · .xlsx</div>
      <input type="file" id="archivo" accept=".xlsx,.xlsm" multiple hidden>
    </label>
    ${E.archivos.length ? `<h2>Cargados en ${h(E.mes)}</h2>${lista}` : ""}
    ${vCuadratura()}`;
}

function vCuadratura() {
  const c = E.cuadratura;
  if (!c) return "";
  if (!c.talana) return `<h2>Trabajadores por obra: planilla de obra vs TALANA</h2>
    <div class="tarjeta vacio">Sube la exportación de trabajadores de TALANA en <button class="link" data-ir="trabajadores">1 · Trabajadores</button> para comparar.</div>`;
  const dif = (o) => [...o.solo_archivo.map((x) => `<li><b>${h(x.trabajador)}</b> <span class="rut muted small">${h(x.rut)}</span>: viene en la planilla de la obra, pero ${h(x.motivo)}.</li>`),
    ...o.solo_talana.map((x) => `<li><b>${h(x.trabajador)}</b> <span class="rut muted small">${h(x.rut)}</span>: está en TALANA en esta obra, pero ${h(x.motivo)}.</li>`)].join("");
  const filas = c.obras.map((o) => {
    const cuadra = !o.solo_archivo.length && !o.solo_talana.length;
    return `<tr>
      <td><b>${h(o.obra)}</b>${o.configurada ? "" : `<div class="rojo small">no es una obra configurada: elígela arriba</div>`}</td>
      <td class="num">${o.llego_archivo ? o.en_archivo : "<span class='muted'>no llegó</span>"}</td>
      <td class="num">${o.en_talana}</td><td class="num">${o.en_ambas}</td>
      <td>${cuadra ? `<span class="chip ok">cuadra</span>` : `<span class="chip revisar">${o.solo_archivo.length + o.solo_talana.length} diferencia(s)</span>
        <ul class="notas small" style="margin-top:6px">${dif(o)}</ul>`}</td></tr>`;
  }).join("");
  const tot = (k) => c.obras.reduce((s, o) => s + o[k], 0);
  return `<h2>Trabajadores por obra: planilla de obra vs TALANA</h2>
    <p class="sub">Cuántos trabajadores declara cada obra en su planilla de ${h(E.mes)} frente a los que TALANA tiene en esa sucursal.</p>
    <div class="tarjeta" style="overflow-x:auto"><table class="tabla">
      <thead><tr><th>Obra</th><th class="num">En la planilla de la obra</th><th class="num">En TALANA</th><th class="num">En ambas</th><th>Diferencias</th></tr></thead>
      <tbody>${filas}</tbody>
      <tfoot><tr><th>Total</th><th class="num">${tot("en_archivo")}</th><th class="num">${tot("en_talana")}</th><th class="num">${tot("en_ambas")}</th><th></th></tr></tfoot>
    </table></div>`;
}

async function subir(files) {
  files = [...files].filter((f) => /\.xls[xm]$/i.test(f.name));
  if (!files.length) return aviso("Solo se pueden cargar archivos Excel (.xlsx).", true);
  const pasos = [
    ["Leyendo los archivos de las obras", ""],
    ["Extrayendo resumen y detalle diario", ""],
    ["Identificando a cada trabajador por RUT o nombre", ""],
    ["Aplicando tarifas de fin de semana y bonos", ""],
    ["Comparando lo informado con lo calculado", ""],
    ["Armando la carga para TALANA", ""],
  ];
  const ol = $("#proceso-pasos");
  ol.innerHTML = pasos.map(([t]) => `<li><span class="p"></span><span>${t}</span><span class="det"></span></li>`).join("");
  $("#proceso").hidden = false;
  const li = ol.querySelectorAll("li");
  const marcar = async (i, det, ms = 380) => {
    li[i].classList.add("on");
    await espera(ms);
    li[i].classList.remove("on");
    li[i].classList.add("ok");
    li[i].querySelector(".det").textContent = det;
  };
  const errores = [];
  li[0].classList.add("on");
  for (const f of files) {
    try {
      const r = await api("/api/archivos", { method: "POST", headers: { "X-Nombre": encodeURIComponent(f.name) }, body: await f.arrayBuffer() });
      if (r.reemplazo.length) aviso(`«${f.name}» reemplazó a ${r.reemplazo.join(", ")}`);
    } catch (e) { errores.push(e.message); }
  }
  await refrescar();
  const r = E.resumen;
  await marcar(0, `${files.length - errores.length} de ${files.length} archivo(s)`);
  await marcar(1, `${r.filas} filas · ${r.dias_detalle} días`);
  await marcar(2, `${r.trabajadores} trabajadores${r.sin_rut ? ` · ${r.sin_rut} sin RUT` : ""}`);
  await marcar(3, $$(r.desgaste));
  await marcar(4, r.revisar ? `${r.revisar} por revisar` : "todo cuadra");
  await marcar(5, `${E.talana.length} filas`);
  await espera(650);
  $("#proceso").hidden = true;
  if (errores.length) aviso(errores.join(" · "), true);
  ir("magia");
}

// ------------------------------------------------------------------ La magia
function vMagia() {
  if (!E.filas.length) return `<h1>La magia</h1><div class="tarjeta vacio">Todavía no hay archivos cargados.<br><br><button class="boton" data-ir="cargar">Cargar archivos</button></div>`;
  const r = E.resumen;
  const obras = [...new Set(E.filas.map((f) => f.obra))];
  const conBonos = E.filas.filter((f) => f.traza.bonos.length).length;
  const visibles = E.filas.filter((f) => (filtro.estado === "todas" || f.estado === filtro.estado) && (filtro.obra === "todas" || f.obra === filtro.obra));
  const grupos = obras.filter((o) => visibles.some((f) => f.obra === o)).map((o) => {
    const a = E.archivos.find((x) => x.obra === o) || {};
    const fs = visibles.filter((f) => f.obra === o);
    return `<section class="obra">
      <div class="obra-cab"><h2>${h(o)}</h2><span class="muted small">${h(a.nombre)} · ${h(a.formato)}</span></div>
      ${fs.map(tarjetaPersona).join("")}
    </section>`;
  }).join("");
  const f = (k, v, t) => `<button class="filtro ${filtro[k] === v ? "activo" : ""}" data-filtro="${k}" data-valor="${h(v)}">${h(t)}</button>`;
  return `
    <h1>La magia</h1>
    <p class="sub">Todo lo que la app sacó de los archivos y cómo llegó a cada número. Haz clic en un trabajador para ver el detalle.</p>
    <div class="tuberia">
      <div class="etapa"><div class="n">${E.archivos.length}</div><div class="t">Archivos</div><div class="d">${obras.length} obra(s)</div></div>
      <div class="etapa"><div class="n">${r.filas}</div><div class="t">Filas extraídas</div><div class="d">${r.dias_detalle} días de detalle diario</div></div>
      <div class="etapa"><div class="n">${r.trabajadores}</div><div class="t">Trabajadores</div><div class="d">${r.sin_rut ? r.sin_rut + " sin RUT" : "todos identificados"}</div></div>
      <div class="etapa"><div class="n">${$$(r.desgaste)}</div><div class="t">Fin de semana + bonos</div><div class="d">${conBonos} con bono</div></div>
      <div class="etapa ${r.revisar ? "alerta" : ""}"><div class="n">${r.revisar}</div><div class="t">Por revisar</div><div class="d">${r.ok} OK · ${r.revisado} revisadas</div></div>
    </div>
    <div class="filtros">
      ${f("estado", "todas", "Todas")} ${f("estado", "Revisar", `Revisar (${r.revisar})`)} ${f("estado", "Revisado", "Revisadas")} ${f("estado", "OK", "OK")}
      <span class="muted" style="margin-left:10px">Obra:</span>
      ${f("obra", "todas", "Todas")} ${obras.map((o) => f("obra", o, o)).join(" ")}
    </div>
    ${grupos || `<div class="tarjeta vacio">No hay filas con este filtro.</div>`}`;
}

function tarjetaPersona(f) {
  const abierta = abiertas.has(f.id);
  const t = f.talana;
  const rutChip = f.rut === "SIN RUT" ? `<span class="chip rojo">SIN RUT</span>`
    : f.falta_trabajador ? `<span class="chip rojo rut" title="${h(f.notas[0] || "")}">${h(f.rut_txt)}</span>`
    : `<span class="muted small rut">${h(f.rut_txt)}</span>`;
  return `
    <div class="tarjeta persona ${abierta ? "abierta" : ""}" data-persona="${f.id}">
      <div class="persona-cab" data-abrir="${f.id}">
        <span class="flecha">▶</span>
        <span class="quien">${h(f.trabajador)}${f.finiquito ? ` <span class="chip negro">Finiquitado ${fecha(f.finiquito).slice(0, 5)}</span>` : ""}<small>${h(f.lugar || f.obra)}</small></span>
        <span class="rutc">${rutChip}</span>
        <span>${chipEstado(f.estado)}</span>
        <span class="v">${n(t.dias)}<small>días</small></span>
        <span class="v">${n(t.he)}<small>horas extra</small></span>
        <span class="v">${$$(t.monto)}<small>desgaste</small></span>
      </div>
      <div class="persona-cuerpo">${abierta ? cuerpoPersona(f) : ""}</div>
    </div>`;
}

function cuerpoPersona(f) {
  const o = f.obra_val, p = f.planilla, t = f.talana, a = f.alertas, tr = f.traza;
  const celda = (v, fmt, dif) => `<div class="val ${dif ? "dif" : ""}">${fmt(v)}</div>`;
  const fuente = (k) => ({ obra: "de la obra", planilla: "de la planilla", "tu revisión": "tu revisión" }[f.fuente[k]]);
  const comp = `
    <div class="comparacion">
      <div class="cab"></div><div class="cab">Informa la obra</div><div class="cab">Calcula la planilla</div><div class="cab talana">Va a TALANA</div>
      <div class="et">Días</div>${celda(o.dias, n, a.dias)}${celda(p.dias, (v) => v === null ? "sin detalle" : n(v), a.dias)}
        <div class="val talana">${n(t.dias)}<span class="fuente">${fuente("dias")}</span></div>
      <div class="et">Horas extra</div>${celda(o.he, n, a.he)}${celda(p.he, (v) => v === null ? "sin detalle" : n(v), a.he)}
        <div class="val talana">${n(t.he)}<span class="fuente">${fuente("he")}</span></div>
      <div class="et">Monto $</div>${celda(f.obra_informa_monto ? o.monto : null, (v) => v === null ? "no informa" : $$(v), a.monto)}${celda(p.monto, $$, a.monto)}
        <div class="val talana">${$$(t.monto)}<span class="fuente">${fuente("monto")}</span></div>
    </div>`;
  const linea = (txt, origen, val) => `<li><span>${txt}${origen ? `<span class="o">${h(origen)}</span>` : ""}</span><span class="num">${val}</span></li>`;
  const calc = `
    <ul class="calculo">
      ${linea("Días", tr.dias, n(p.dias))}
      ${linea("Horas extra", tr.he, n(p.he))}
      ${linea(`Sábados: ${n(tr.sab.cantidad)} × ${$$(tr.sab.tarifa)}`, tr.sab.origen, $$(tr.sab.total))}
      ${linea(`Domingos / feriados: ${n(tr.dom.cantidad)} × ${$$(tr.dom.tarifa)}`, tr.dom.origen, $$(tr.dom.total))}
      ${tr.bonos.map((b) => linea(h(b.tipo), (b.obra === "TODAS" ? "todas las obras" : b.obra) + (b.comentario ? " · " + b.comentario : ""), $$(b.monto))).join("")}
      ${linea("<b>Fin de semana + bonos</b>", "", $$(tr.monto))}
    </ul>`;
  const inf = f.informado;
  const datosObra = `
    <ul class="calculo">
      ${linea("Nombre en el archivo", "", h(`${inf.nombre || ""} ${inf.apellido || ""}`))}
      ${linea("RUT en el archivo", f.rut_como, h(inf.rut || "— (vacío)"))}
      ${(() => {
        const tal = E.maestro.trabajadores.find((t) => t.rut && t.rut.replace(/\./g, "") === f.rut);
        if (!tal || !tal.talana_el) return "";
        const obraT = tal.obra || `${tal.sucursal || "sin sucursal"} (no es obra)`;
        return linea("Obra en TALANA", tal.sucursal ? `sucursal «${tal.sucursal}»` : "",
          tal.obra === f.obra ? h(obraT) : `<span class="rojo">${h(obraT)}</span>`);
      })()}
      ${linea("Sábados / domingos-feriados informados", "", `${n(o.sab)} / ${n(o.dom)}`)}
      ${linea("Monto fin de semana informado", "", inf.monto_fds === null ? "—" : $$(inf.monto_fds))}
      ${linea("Bonos informados", "", inf.bonos === null ? "—" : $$(inf.bonos))}
      ${f.marcas ? linea("Marcado por la obra este mes", "planilla de obra (hoja Resumen)",
        [["noche", "Bono noche"], ["lejania", "Bono lejanía"], ["trato", "Trato fin de semana"]]
          .map(([k, t]) => `<span class="chip ${f.marcas[k] ? "ok" : "gris"}">${f.marcas[k] ? "✓ " : ""}${t}</span>`).join(" ")) : ""}
      ${f.finiquito ? linea("Finiquito", "último día que cuenta", fecha(f.finiquito)) : ""}
      ${inf.obs ? linea(f.marcas ? "Comentario de la obra" : "Observación", "", h(inf.obs)) : ""}
      ${f.hojas.length ? linea("Detalle diario", "", "hoja(s) " + f.hojas.map(h).join(", ")) : ""}
    </ul>`;
  const conRut = f.rut !== "SIN RUT" && !f.falta_trabajador;
  const rutMaestro = conRut ? (E.maestro.trabajadores.find((x) => (x.rut || "").replace(/\./g, "") === f.rut) || {}).rut : null;
  const botonCaso = !cerrado() && rutMaestro
    ? `<p><button class="boton sec" data-nuevo-caso data-rut="${h(rutMaestro)}">+ Tarifa o bono para ${h(f.trabajador)}</button></p>` : "";
  return `
    ${comp}
    <div class="columnas">
      <div><p class="bloque-t">Cómo calculó la planilla</p>${calc}${botonCaso}</div>
      <div><p class="bloque-t">Lo que viene en el archivo</p>${datosObra}
        ${f.notas.length ? `<p class="bloque-t" style="margin-top:16px">Qué revisar</p><ul class="notas">${f.notas.map((x) => `<li>${h(x)}</li>`).join("")}</ul>` : ""}
        ${false && (f.reliquidacion || []).length ? `<p class="bloque-t" style="margin-top:16px">Cambios en días ya pagados (reliquidación)</p>
          <ul class="notas">${f.reliquidacion.map((c) => `<li>${fecha(c.fecha)}: ${h(c.campo)} ${h(c.antes)} → <b>${h(c.ahora)}</b> <span class="muted small">(pagado en ${h(nombreMes(c.periodo_original))})</span></li>`).join("")}</ul>
          <p class="muted small">No cambian lo que va a TALANA este mes: quedan registrados al cerrar el mes.</p>` : ""}
        ${f.estado === "Revisar" && !cerrado() ? `<p><button class="boton sec" data-ir="revision">Ir a revisar →</button></p>` : ""}
      </div>
    </div>
    ${f.detalle.length ? `<p class="bloque-t" style="margin-top:18px">Detalle diario (${f.detalle.length} días)</p>${calendario(f.detalle)}` : ""}`;
}

function calendario(dias) {
  const nombres = ["lun", "mar", "mié", "jue", "vie", "sáb", "dom"];
  const primera = new Date(dias[0].fecha + "T00:00");
  const offset = (primera.getDay() + 6) % 7;
  let html = nombres.map((d) => `<div class="dsem">${d}</div>`).join("");
  html += Array.from({ length: offset }, () => `<div class="dia nada"></div>`).join("");
  for (const d of dias) {
    const cls = ["dia"];
    if (d.tipo_dia !== "Hábil") cls.push("finde");
    if (d.trabajo) cls.push("trabajo");
    if (d.ausencia) cls.push("ausencia");
    if (!d.en_periodo || d.clase === "futuro" || d.clase === "anterior" || d.sin_contrato) cls.push("fuera");
    if (d.duplicado && (d.clase || "cuenta") === "cuenta") cls.push("duplicado");
    if (d.clase === "pagado") cls.push(d.cambios && d.cambios.length ? "cambio" : "pagado");
    const motivo = { pagado: d.cambios && d.cambios.length ? "YA PAGADO, con cambios: " + d.cambios.map((c) => `${c.campo} ${c.antes} → ${c.ahora}`).join(", ")
      : "YA PAGADO en un mes anterior, sin cambios: no se suma", futuro: "del mes siguiente: no se usa este mes",
      anterior: "antes del período, sin pago registrado: no se suma" }[d.clase] || "";
    const tip = [fecha(d.fecha) + " · " + d.tipo_dia, d.entrada && d.salida ? `${d.entrada.slice(0, 5)}–${d.salida.slice(0, 5)}` : "",
      d.he ? `${n(d.he)} h extra` : "", d.obs, !d.en_periodo && !motivo ? "fuera del período" : "", motivo,
      d.sin_contrato ? "sin contrato: antes del ingreso o después del finiquito" : "",
      d.duplicado && !d.clase ? "YA PAGADO en un mes anterior" : ""]
      .filter(Boolean).join("\n");
    html += `<div class="${cls.join(" ")}" title="${h(tip)}"><div class="f">${d.fecha.slice(8, 10)}/${d.fecha.slice(5, 7)}</div>${d.he ? `<div class="he">+${n(d.he)}h</div>` : d.ausencia ? `<div class="rojo small">aus.</div>` : ""}</div>`;
  }
  return `<div class="calendario">${html}</div>
    <div class="leyenda"><span class="l-trabajo">trabajó</span><span class="l-finde">sábado, domingo o feriado</span><span class="l-ausencia">ausencia</span><span class="l-fuera">fuera del período (no se suma)</span><span class="l-pagado">ya pagado (no se suma)</span><span class="l-dup">ya pagado con cambios</span></div>`;
}

// ------------------------------------------------------------------ Revisión
function vRevision() {
  if (!E.filas.length) return `<h1>Revisión</h1><div class="tarjeta vacio">Todavía no hay archivos cargados.</div>`;
  const filas = E.filas.filter((f) => !soloRevisar || f.estado === "Revisar" || f.estado === "Revisado");
  const trab = E.maestro.trabajadores.filter((t) => t.rut).sort((a, b) => a.muestra.localeCompare(b.muestra));
  const cuerpo = filas.map((f) => {
    const o = f.obra_val, p = f.planilla, d = f.decision, a = f.alertas;
    const trio = (vals, difs) => `<div class="trio">${vals.map((v, i) => `<span class="${difs[i] ? "dif" : ""}">${v}</span>`).join("")}</div>`;
    const necesitaRut = (f.falta_trabajador || f.rut_corregido) && !cerrado();
    const corregidoA = f.rut_corregido ? `<div class="aviso-asignado">Asignado a mano: el archivo dice
      «${h(`${f.informado.nombre || ""} ${f.informado.apellido || ""}`.trim())}»${f.informado.rut ? ` (${h(f.informado.rut)})` : ""}</div>` : "";
    const dis = cerrado() ? "disabled" : "";
    const selRut = necesitaRut ? `<div style="margin-top:6px"><select class="in" data-rut="${f.id}">
        <option value="">${f.rut_corregido ? "— volver a lo informado —" : "¿Quién es? Elegir…"}</option>
        ${trab.map((t) => `<option value="${h(t.rut)}" ${f.rut_corregido && t.rut.replace(/\./g, "") === f.rut ? "selected" : ""}>${h(t.muestra)} · ${h(t.rut)}</option>`).join("")}
      </select></div>
      ${f.falta_trabajador ? `<div style="margin-top:4px"><button class="link" data-nuevo-trab="${f.id}">+ Agregar como trabajador nuevo</button></div>` : ""}` : "";
    return `<tr class="fila-rev">
      <td>${chipEstado(f.estado)}</td>
      <td><b>${h(f.trabajador)}</b>${f.finiquito ? ` <span class="chip negro">Finiquitado</span>` : ""}
        <div class="muted small">${h(f.obra)} · ${f.rut === "SIN RUT" ? "<span class='rojo'>SIN RUT</span>" : `<span class="rut">${h(f.rut_txt)}</span>`}</div>
        ${f.marcas && f.informado.obs ? `<div class="small" style="margin-top:3px">💬 ${h(f.informado.obs)}</div>` : ""}${corregidoA}${selRut}</td>
      <td class="que">${f.notas.map(h).join("<br>") || "<span class='muted'>—</span>"}</td>
      <td>${trio([n(o.dias), n(o.he), f.obra_informa_monto ? $$(o.monto) : "—"], [a.dias, a.he, a.monto])}</td>
      <td>${trio([p.dias === null ? "s/d" : n(p.dias), p.he === null ? "s/d" : n(p.he), $$(p.monto)], [a.dias, a.he, a.monto])}</td>
      <td><div class="seg">
        <button ${dis} data-usar="${f.id}" data-v="Obra" class="${d.usar === "Obra" ? "on" : ""}">Obra</button>
        <button ${dis} data-usar="${f.id}" data-v="Planilla" class="${d.usar === "Planilla" ? "on" : ""}">Planilla</button>
      </div>${f.propuesta ? `<div style="margin-top:6px"><button ${dis} class="boton chico ${d.dias === f.propuesta.dias ? "sec" : ""}"
        data-propuesta="${f.id}">${d.dias === f.propuesta.dias ? "✓ Aceptado" : "Aceptar"}: ${n(f.propuesta.dias)} días aquí</button></div>` : ""}</td>
      <td><div class="trio">
        <input ${dis} class="in" data-corr="${f.id}" data-k="dias" value="${d.dias ?? ""}" placeholder="días">
        <input ${dis} class="in" data-corr="${f.id}" data-k="he" value="${d.he ?? ""}" placeholder="h. extra">
        <input ${dis} class="in" data-corr="${f.id}" data-k="monto" value="${d.monto ?? ""}" placeholder="$" style="width:100px">
      </div></td>
      <td>${f.pendiente ? `<span class="muted small">pendiente</span>` : `<div class="trio"><b>${n(f.talana.dias)}</b><b>${n(f.talana.he)}</b><b>${$$(f.talana.monto)}</b></div>`}</td>
    </tr>`;
  }).join("");
  return `
    <h1>Revisión</h1>
    <p class="sub">Solo se decide en las filas «Revisar». Elige qué valor usar: <b>Obra</b> (lo que informó la obra) o <b>Planilla</b> (detalle diario y tarifas).
      Si ninguno sirve, escribe el valor correcto en «Tu revisión»: ese valor manda.</p>
    <div class="filtros">
      <button class="filtro ${soloRevisar ? "activo" : ""}" data-solo="1">Por revisar y revisadas</button>
      <button class="filtro ${!soloRevisar ? "activo" : ""}" data-solo="0">Todas las filas (${E.filas.length})</button>
    </div>
    ${filas.length ? `<div class="tarjeta" style="overflow-x:auto"><table class="tabla">
      <thead><tr><th>Estado</th><th>Trabajador</th><th>Qué revisar</th><th>Informa la obra<br><span class="muted">días · h.e. · $</span></th>
        <th>Calcula la planilla<br><span class="muted">días · h.e. · $</span></th><th>Usar</th><th>Tu revisión<br><span class="muted">días · h.e. · $</span></th><th>Va a TALANA</th></tr></thead>
      <tbody>${cuerpo}</tbody></table></div>`
      : `<div class="tarjeta vacio">✅ No hay nada por revisar.<br><br><button class="boton" data-ir="talana">Ir a TALANA</button></div>`}
    ${noInformados()}`;
}

// Trabajadores de una obra según TALANA que la planilla de su obra no trae (30-10-2026): van con 30 días por defecto
// (editables), se les puede agregar horas extra o un bono, y quedan pendientes hasta marcarlos como vistos.
function noInformados() {
  const lista = E.no_informados || [];
  if (!lista.length) return "";
  const dis = cerrado() ? "disabled" : "";
  const agregados = (rut) => (E.horas_manuales || []).filter((x) => x.rut.replace(/\./g, "") === rut);
  const filas = lista.map((x) => `<tr class="no-informado">
    <td>${x.pendiente ? `<span class="chip lila">No informado</span>` : `<span class="chip gris">Visto</span>`}</td>
    <td><b>${h(x.trabajador)}</b><div class="muted small">${h(x.obra)} · <span class="rut">${h(x.rut_txt)}</span></div>
      ${x.ingreso ? `<div class="muted small">Ingreso ${fecha(x.ingreso)}${x.termino ? ` · contrato hasta ${fecha(x.termino)}` : ""}</div>` : ""}</td>
    <td><input ${dis} class="in" style="width:70px" data-ni-dias="${x.rut}" value="${n(x.dias)}">
      ${x.dias_editados ? `<div><button ${dis} class="link small" data-ni-defecto="${x.rut}">volver a ${n(x.dias_defecto)}</button></div>` : `<div class="muted small">por defecto</div>`}</td>
    <td>${agregados(x.rut).map((m) => `<div>${m.tipo ? `${h(m.tipo)} ${$$(m.monto)}` : `${n(m.horas)} h. extra`}${m.comentario ? ` <span class="muted small">(${h(m.comentario)})</span>` : ""}
        ${cerrado() ? "" : `<button class="link small" data-quitar-horas="${m.id}">quitar</button>`}</div>`).join("") || `<span class="muted">—</span>`}
      ${cerrado() ? "" : `<div><button class="link" data-ni-agregar="${x.rut}">+ Horas extra o bono</button></div>`}</td>
    <td>${cerrado() ? "" : x.pendiente ? `<button class="boton chico" data-ni-visto="${x.rut}">Visto</button>`
      : x.dias_editados || agregados(x.rut).length ? "" : `<button class="link small" data-ni-novisto="${x.rut}">desmarcar</button>`}</td></tr>`).join("");
  return `
    <h2>No informados por su obra (${lista.length})</h2>
    <p class="muted">Según TALANA trabajan en una obra cuya planilla ya llegó, pero la obra no los informó. Van a TALANA con
      ${n(E.config.dias_base)} días (menos los días antes del ingreso o después del término del contrato); puedes cambiar los días,
      agregar horas extra o un bono. El mes queda listo para TALANA cuando todos estén marcados como vistos.</p>
    <div class="tarjeta" style="overflow-x:auto"><table class="tabla">
      <thead><tr><th>Estado</th><th>Trabajador</th><th>Días</th><th>Agregado a mano</th><th></th></tr></thead>
      <tbody>${filas}</tbody></table></div>`;
}

function agregarANoInformado(rut) {
  const x = (E.no_informados || []).find((y) => y.rut === rut);
  const bonos = (E.maestro.tipos || []).filter((t) => t.clase === "BONO");
  dialogo(`
    <div class="proceso-titulo">Agregar a ${h(x.trabajador)}</div>
    <p class="muted">${h(x.obra)} no lo informó este mes. Lo que agregues va a TALANA junto con sus días.</p>
    <div class="campos">
      <label>Qué <select class="in" id="ni-tipo"><option value="">Horas extra</option>
        ${bonos.map((b) => `<option value="${h(b.tipo)}" data-monto="${b.monto ?? ""}">${h(b.tipo)}</option>`).join("")}</select></label>
      <label id="ni-l-horas">Horas extra <input class="in" id="ni-horas" inputmode="decimal" placeholder="Ej. 10" style="width:90px"></label>
      <label id="ni-l-monto" hidden>Monto <input class="in" id="ni-monto" inputmode="decimal" placeholder="$" style="width:120px"></label>
      <label class="ancho">Comentario <input class="in" id="ni-com" placeholder="Opcional"></label>
    </div>
    <div class="acciones"><button class="boton sec" data-cerrar-dialogo>Cancelar</button><button class="boton" id="ni-ok">Agregar</button></div>`);
  $("[data-cerrar-dialogo]").onclick = cerrarDialogo;
  $("#ni-tipo").onchange = () => {
    const bono = Boolean($("#ni-tipo").value);
    $("#ni-l-horas").hidden = bono; $("#ni-l-monto").hidden = !bono;
    $("#ni-monto").value = $("#ni-tipo").selectedOptions[0].dataset.monto || "";
  };
  $("#ni-ok").onclick = async () => {
    const tipo = $("#ni-tipo").value;
    try {
      await postJSON("/api/horas_manuales", { rut, tipo, horas: tipo ? null : $("#ni-horas").value,
        monto: tipo ? $("#ni-monto").value : null, comentario: $("#ni-com").value });
      cerrarDialogo(); await refrescar(); aviso("Agregado.");
    } catch (e) { aviso(e.message, true); }
  };
}

async function marcarNoInformado(datos) {
  try { await postJSON("/api/no_informado", datos); await refrescar(); } catch (e) { aviso(e.message, true); }
}

function abrirTrabajador(fila) {
  const inf = fila.informado;
  const rutArchivo = inf.rut || "";
  $("#caso-caja").innerHTML = `
    <div class="proceso-titulo">Agregar trabajador nuevo</div>
    <p class="muted">Viene en <b>${h(fila.archivo)}</b> como «${h(`${inf.nombre || ""} ${inf.apellido || ""}`.trim())}»${rutArchivo ? `, RUT ${h(rutArchivo)}` : ", sin RUT"}.
      Revisa los datos (idealmente contra TALANA) y guarda: la fila queda asignada a este trabajador.</p>
    <div class="campos">
      <label>Nombres <input class="in" id="w-nombres" value="${h(inf.nombre || "")}"></label>
      <label>Apellidos <input class="in" id="w-apellidos" value="${h(inf.apellido || "")}"></label>
      <label>RUT <input class="in" id="w-rut" value="${h(rutArchivo)}" placeholder="12.345.678-5">
        <span class="ayuda" id="w-rut-ayuda"></span></label>
      <label>Nombre corto (opcional) <input class="in" id="w-corto" placeholder="vacío = primer nombre + primer apellido"></label>
    </div>
    <div class="acciones">
      <button class="boton sec" id="w-cancelar">Cancelar</button>
      <button class="boton" id="w-guardar">Agregar trabajador</button>
    </div>`;
  const revisarRut = () => {
    const ok = rutValido($("#w-rut").value);
    $("#w-rut-ayuda").textContent = $("#w-rut").value.trim() ? (ok ? "✓ RUT válido" : "✗ el dígito verificador no calza") : "";
    $("#w-rut-ayuda").style.color = ok ? "var(--verde-osc)" : "var(--rojo)";
  };
  $("#w-rut").oninput = revisarRut;
  revisarRut();
  $("#w-cancelar").onclick = () => ($("#dialogo-caso").hidden = true);
  $("#w-guardar").onclick = async () => {
    try {
      const r = await api("/api/trabajadores", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fila_id: fila.id, nombres: $("#w-nombres").value, apellidos: $("#w-apellidos").value,
          rut: $("#w-rut").value, corto: $("#w-corto").value }) });
      $("#dialogo-caso").hidden = true;
      await refrescar();
      aviso(`${r.muestra} (${r.rut}) quedó en Trabajadores.`);
    } catch (e) { aviso(e.message, true); }
  };
  $("#dialogo-caso").hidden = false;
  $("#w-nombres").focus();
}

function rutValido(rut) {
  const s = String(rut || "").replace(/[.\s]/g, "").toUpperCase();
  const m = s.match(/^(\d+)-?([\dK])$/);
  if (!m) return false;
  let suma = 0, peso = 2;
  for (const d of m[1].split("").reverse()) { suma += Number(d) * peso; peso = peso === 7 ? 2 : peso + 1; }
  const r = 11 - (suma % 11);
  return m[2] === (r === 11 ? "0" : r === 10 ? "K" : String(r));
}

async function decidir(id, cambios) {
  const f = E.filas.find((x) => x.id === id);
  const d = { ...f.decision, ...cambios };
  try {
    await api("/api/decision", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fila_id: id, ...d }) });
    await refrescar();
  } catch (e) { aviso(e.message, true); }
}

// ------------------------------------------------------------------ TALANA
function vTalana() {
  const r = E.resumen;
  if (!E.filas.length) return `<h1>Carga para TALANA</h1><div class="tarjeta vacio">Todavía no hay archivos de obra cargados${E.talana.length ? " (los viáticos y las horas extra de oficina ya cargados van a TALANA junto con las obras)" : ""}. Cárgalos en «3 · Cargar obras».</div>`;
  const filas = E.talana.map((t) => `<tr>
    <td class="rut">${h(t.rut)}</td><td>${h(t.trabajador)}<div class="muted small">${t.obras.map(h).join(" + ")}</div></td>
    ${t.pendiente ? `<td colspan="5" class="rojo">PENDIENTE: falta revisar</td>` :
      `<td class="num">${t.dias ? n(t.dias) : ""}</td><td class="num">${t.he ? n(t.he) : ""}</td><td class="num">${t.monto ? $$(t.monto) : ""}</td><td class="num">${t.viatico ? $$(t.viatico) : ""}</td><td class="num">${t.anticipo ? $$(t.anticipo) : ""}</td>`}
  </tr>`).join("");
  return `
    <h1>Carga para TALANA</h1>
    <p class="sub">Una fila por trabajador (si estuvo en más de una obra, se suman). Se llenan Días, Horas extra, Desgaste de herramientas, Viáticos y Descuento anticipo viático (viáticos ya pagados); las demás quedan vacías, igual que el archivo de ejemplo.</p>
    <div class="tarjeta listo ${r.listo ? "si" : "no"}">
      <div class="icono">${r.listo ? "✅" : "⏳"}</div>
      <div style="flex:1"><b>${h(E.archivo_talana)}</b><br><span class="muted">${r.listo ? `${E.talana.length} trabajadores · ${n(r.he)} horas extra · ${$$(r.desgaste)} desgaste`
        : `Quedan ${r.revisar} fila(s) por revisar antes de descargar.`}</span></div>
      ${r.listo ? `<span style="display:flex;gap:8px;flex-wrap:wrap"><button class="boton" data-guardar="/api/talana${qPeriodo()}">Guardar en Descargas</button><a class="boton sec" href="/api/talana${qPeriodo()}" download>Descargar</a></span>` : `<button class="boton" data-ir="revision">Ir a Revisión</button>`}
    </div>
    <div class="tarjeta" style="overflow-x:auto"><table class="tabla">
      <thead><tr><th>rut</th><th>Trabajador</th><th class="num">Días Trabajados</th><th class="num">Horas Extra Trabajadas</th><th class="num">Asignación Desgaste de Herramientas</th><th class="num">Viáticos</th><th class="num">Descuento anticipo viático</th></tr></thead>
      <tbody>${filas}</tbody>
      <tfoot><tr><th></th><th>Total</th><th></th><th class="num">${n(r.he)}</th><th class="num">${$$(r.desgaste)}</th><th class="num">${$$(r.viaticos || 0)}</th><th class="num">${$$(r.anticipo_viaticos || 0)}</th></tr></tfoot>
    </table></div>`;
}

// ------------------------------------------------------------------ Tarifas y bonos (casos especiales)
const claseDe = (tipo) => (E.maestro.tipos.find((t) => t.tipo === tipo) || {}).clase || "";
const montoTipo = (tipo) => (E.maestro.tipos.find((t) => t.tipo === tipo) || {}).monto;

function vigenteEnMes(c) {
  const d = E.config.desde, hs = E.config.hasta;
  return (!c.desde || !hs || c.desde <= hs) && (!c.hasta || !d || c.hasta >= d);
}

function vCasos() {
  const m = E.maestro;
  const casos = [...m.casos].sort((a, b) => a.trabajador.localeCompare(b.trabajador) || a.tipo.localeCompare(b.tipo));
  const filas = casos.map((c) => {
    const vig = vigenteEnMes(c);
    const valor = claseDe(c.tipo) === "TARIFA"
      ? `Sáb ${c.sabado == null ? "estándar" : $$(c.sabado)} · Dom/fer ${c.domingo == null ? "estándar" : $$(c.domingo)}`
      : `${$$(c.bono ?? montoTipo(c.tipo))}${c.bono == null ? " <span class='muted small'>(monto del tipo)</span>" : ""}`;
    return `<tr class="${vig ? "" : "no-vigente"}">
      <td><b>${h(c.trabajador)}</b><div class="muted small rut">${h(c.rut)}</div></td>
      <td>${h(c.obra)}</td><td>${h(c.tipo)}</td><td class="num">${valor}</td>
      <td>${c.desde ? fecha(c.desde) : "siempre"} → ${c.hasta ? fecha(c.hasta) : "sin término"}<br>
        ${vig ? `<span class="chip ok">vigente en ${h(E.mes)}</span>` : `<span class="chip gris">no aplica en ${h(E.mes)}</span>`}</td>
      <td class="small">${h(c.comentario)}</td>
      <td style="white-space:nowrap">${cerrado() ? "" : `<button class="link" data-editar-caso="${c.id}">Editar</button> · <button class="link" data-borrar-caso="${c.id}">Borrar</button>`}</td>
    </tr>`;
  }).join("");
  return `
    <div class="cabecera-lista">
      <div><h1>Tarifas y bonos</h1>
      <p class="sub">Casos especiales por trabajador: tarifa distinta de fin de semana o bonos (noche, desempeño, lejanía…). Todo va a «Asignación Desgaste de Herramientas».
        ${cerrado() ? "Así estaban al cerrar el mes." : "Los cambios se aplican al mes en curso de inmediato; los meses cerrados no cambian."}</p></div>
      ${cerrado() ? "" : `<button class="boton" data-nuevo-caso>+ Agregar tarifa o bono</button>`}
    </div>
    ${casos.length ? `<div class="tarjeta" style="overflow-x:auto"><table class="tabla">
      <thead><tr><th>Trabajador</th><th>Obra</th><th>Tipo</th><th class="num">Valor</th><th>Vigencia</th><th>Comentario</th><th></th></tr></thead>
      <tbody>${filas}</tbody></table></div>` : `<div class="tarjeta vacio">Todavía no hay tarifas especiales ni bonos.</div>`}
    <h2>Tipos de tarifa / bono</h2>
    <p class="sub">TARIFA cambia el valor del sábado y/o domingo-feriado. BONO suma un monto (si el caso no trae monto, se usa el monto por defecto).</p>
    <div class="tarjeta" style="overflow-x:auto"><table class="tabla">
      <thead><tr><th>Tipo</th><th>Clase</th><th class="num">Monto por defecto</th></tr></thead>
      <tbody>${m.tipos.map((t) => `<tr><td>${h(t.tipo)}</td><td>${h(t.clase)}</td><td class="num">${t.monto == null ? "" : $$(t.monto)}</td></tr>`).join("")}</tbody>
    </table></div>`;
}

function abrirCaso(caso = {}) {
  const m = E.maestro;
  const trab = m.trabajadores.filter((t) => t.rut && (t.activo !== "No" || t.rut === caso.rut)).sort((a, b) => a.muestra.localeCompare(b.muestra));
  const obras = ["TODAS", ...m.obras];
  if (caso.obra && !obras.includes(caso.obra)) obras.push(caso.obra);
  const opt = (v, t, sel) => `<option value="${h(v)}" ${sel ? "selected" : ""}>${h(t)}</option>`;
  const tipo = caso.tipo || m.tipos[0]?.tipo || "";
  $("#caso-caja").innerHTML = `
    <div class="proceso-titulo">${caso.id ? "Editar" : "Agregar"} tarifa o bono</div>
    <div class="campos">
      <label class="ancho">Trabajador
        <select class="in" id="c-rut"><option value="">Elegir…</option>${trab.map((t) => opt(t.rut, `${t.muestra} · ${t.rut}`, t.rut === caso.rut)).join("")}</select></label>
      <label>Obra <select class="in" id="c-obra">${obras.map((o) => opt(o, o === "TODAS" ? "TODAS las obras (por defecto)" : `Solo ${o}`, o === (caso.obra || "TODAS"))).join("")}</select>
        <span class="ayuda">Un bono en TODAS se suma una vez al mes, aunque el trabajador esté en varias obras.</span></label>
      <label>Tipo <select class="in" id="c-tipo">${m.tipos.map((t) => opt(t.tipo, `${t.tipo} (${t.clase === "TARIFA" ? "tarifa" : "bono"})`, t.tipo === tipo)).join("")}
        <option value="__nuevo__">+ Tipo nuevo…</option></select></label>
      <div class="nuevo-tipo" id="c-nuevo" hidden>
        <label>Nombre del tipo <input class="in" id="t-nombre" placeholder="Ej. Bono asistencia obra"></label>
        <label>Clase <select class="in" id="t-clase"><option value="BONO">BONO</option><option value="TARIFA">TARIFA</option></select></label>
        <label>Monto por defecto <input class="in" id="t-monto" placeholder="opcional"></label>
        <button class="boton sec" id="t-crear">Crear</button>
      </div>
      <label class="c-tarifa">Sábado <input class="in" id="c-sab" value="${caso.sabado ?? ""}" placeholder="vacío = tarifa normal"></label>
      <label class="c-tarifa">Domingo / feriado <input class="in" id="c-dom" value="${caso.domingo ?? ""}" placeholder="vacío = tarifa normal"></label>
      <label class="c-bono ancho">Monto del bono <input class="in" id="c-bono" value="${caso.bono ?? ""}">
        <span class="ayuda" id="c-bono-ayuda"></span></label>
      <label>Desde <input type="date" class="in" id="c-desde" value="${caso.desde || ""}"></label>
      <label>Hasta <input type="date" class="in" id="c-hasta" value="${caso.hasta || ""}"></label>
      <span class="ayuda ancho" style="grid-column:1/-1">Desde/Hasta vacíos = siempre vigente. Se aplica en los meses cuyo período se cruza con estas fechas (${h(E.mes)}: ${fecha(E.config.desde)} al ${fecha(E.config.hasta)}).</span>
      <label class="ancho">Comentario <input class="in" id="c-com" value="${h(caso.comentario || "")}" placeholder="Ej. acordado en octubre"></label>
    </div>
    <div class="acciones">
      <button class="boton sec" id="c-cancelar">Cancelar</button>
      <button class="boton" id="c-guardar">Guardar</button>
    </div>`;
  const cambiaTipo = () => {
    const t = $("#c-tipo").value;
    $("#c-nuevo").hidden = t !== "__nuevo__";
    const clase = claseDe(t);
    document.querySelectorAll(".c-tarifa").forEach((e) => (e.hidden = clase !== "TARIFA"));
    document.querySelectorAll(".c-bono").forEach((e) => (e.hidden = clase !== "BONO"));
    const def = montoTipo(t);
    $("#c-bono").placeholder = def == null ? "obligatorio" : `vacío = ${$$(def)} (monto del tipo)`;
    $("#c-bono-ayuda").textContent = def == null ? "Este tipo no tiene monto por defecto." : "";
  };
  $("#c-tipo").onchange = cambiaTipo;
  cambiaTipo();
  $("#t-crear").onclick = async () => {
    try {
      const r = await api("/api/tipos", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tipo: $("#t-nombre").value, clase: $("#t-clase").value, monto: $("#t-monto").value || null }) });
      E = await api("/api/estado" + qPeriodo());
      const datos = leerCaso(caso.id);
      abrirCaso({ ...datos, tipo: r.tipo });
      aviso(`Tipo «${r.tipo}» creado.`);
    } catch (e) { aviso(e.message, true); }
  };
  $("#c-cancelar").onclick = () => ($("#dialogo-caso").hidden = true);
  $("#c-guardar").onclick = async () => {
    try {
      const d = leerCaso(caso.id);
      if (d.tipo === "__nuevo__") throw new Error("Primero crea el tipo nuevo o elige uno de la lista.");
      await api("/api/casos", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(d) });
      $("#dialogo-caso").hidden = true;
      await refrescar();
      aviso("Guardado. El mes en curso ya se recalculó.");
    } catch (e) { aviso(e.message, true); }
  };
  $("#dialogo-caso").hidden = false;
}

function leerCaso(id) {
  const v = (s) => $(s).value.trim() || null;
  return { id: id || null, rut: v("#c-rut"), obra: v("#c-obra"), tipo: v("#c-tipo"), sabado: v("#c-sab"), domingo: v("#c-dom"),
    bono: v("#c-bono"), desde: v("#c-desde"), hasta: v("#c-hasta"), comentario: v("#c-com") };
}

// ------------------------------------------------------------------ Viáticos (planilla del mes)
const rutConPuntos = (r) => { const m = String(r || "").match(/^(\d+)-([\dK])$/i); return m ? `${Number(m[1]).toLocaleString("es-CL")}-${m[2].toUpperCase()}` : r; };

function vViaticos() {
  const lista = E.viaticos || [];
  const url = "/api/viaticos/planilla";
  const total = lista.reduce((s, v) => s + (v.monto || 0), 0);
  const pagado = lista.reduce((s, v) => s + (v.pagado ? v.monto || 0 : 0), 0);
  const tabla = `
    <div class="cabecera-lista"><h2>${lista.length} viático(s) · ${$$(total)}
      <span class="muted small">· pagados ${$$(pagado)} · por pagar ${$$(total - pagado)}</span></h2>
      ${cerrado() ? "" : `<button class="link" data-quitar-viaticos>Quitar los viáticos de ${h(E.mes)}</button>`}</div>
    <div class="tarjeta" style="overflow-x:auto"><table class="tabla">
      <thead><tr><th>Trabajador</th><th>RUT</th><th>Obra (TALANA)</th><th class="num">Viático</th><th>Pagado</th><th>Comentario</th></tr></thead>
      <tbody>${lista.map((v) => `<tr><td><b>${h(v.trabajador)}</b></td><td class="rut">${h(rutConPuntos(v.rut))}</td><td>${h(v.obra || "")}</td>
        <td class="num">${$$(v.monto)}</td><td>${v.pagado ? "<b>SI</b>" : "NO"}</td>
        <td class="small">${h(v.comentario || "")}</td></tr>`).join("")}</tbody></table></div>
    ${lista.length ? `<p class="muted small">Cargado desde «${h(lista[lista.length - 1].archivo)}» el ${fecha(lista[lista.length - 1].cargado_el)}.</p>` : ""}`;
  const solo = (E.resumen.solo_viatico || []);
  return `
    <h1>Viáticos</h1>
    <p class="sub">Cada mes se llena una sola planilla con los viáticos de los trabajadores de cualquier obra. Al subirla, cada monto va a
      «Viáticos» en la carga TALANA de ${h(E.mes)}; si está <b>pagado</b>, también a «Descuento anticipo viático». Si se sube de nuevo, reemplaza la anterior.</p>
    ${cerrado() ? "" : `<div class="tarjeta" style="padding:16px 18px">
      <h3>1 · Descargar la planilla</h3>
      <div class="obra-archivo"><button class="boton" data-guardar="${h(url)}">Guardar planilla en Descargas</button>
        <a class="boton sec" href="${h(url)}" download>Descargar</a></div>
      <p class="muted small">Trae la lista de los trabajadores activos de todas las obras (según TALANA). Se elige al trabajador, el RUT sale solo, se
        escribe el monto, se marca Pagado SI / NO y, opcionalmente, un comentario.</p>
      <h3 style="margin-top:14px">2 · Subir la planilla llena</h3>
      <label class="zona" id="v-zona" style="padding:22px"><div class="grande">Arrastra aquí la planilla de viáticos</div>
        <div class="muted">o haz clic para elegirla · .xlsx</div><input type="file" id="v-archivo" accept=".xlsx" hidden></label>
    </div>`}
    ${solo.length ? `<div class="tarjeta listo no" style="margin-top:14px"><div class="icono">⚠</div><div>Con viático pero sin archivo de obra este mes
      (van a TALANA solo con el viático): <b>${solo.map(h).join(", ")}</b></div></div>` : ""}
    ${lista.length ? `<div style="margin-top:18px">${tabla}</div>`
      : `<div class="tarjeta vacio" style="margin-top:14px">Todavía no hay viáticos cargados en ${h(E.mes)}.</div>`}`;
}

async function subirViaticos(file) {
  try {
    const r = await api("/api/viaticos", { method: "POST", headers: { "X-Nombre": encodeURIComponent(file.name) }, body: await file.arrayBuffer() });
    await refrescar();
    aviso(`${r.personas} viático(s) por ${$$(r.total)} (pagados ${$$(r.pagado)}).` + (r.avisos.length ? " " + r.avisos.join(" ") : ""), r.avisos.length > 0);
  } catch (e) { aviso(e.message, true); }
}

// ------------------------------------------------------------------ Reliquidaciones
let ultimaCorreccion = null;

function vReliq() {
  const registradas = E.reliquidaciones || [];
  const pendientes = E.filas.flatMap((f) => f.reliquidacion || []);
  const fila = (c, origen) => `<tr><td>${h(nombreMes(c.periodo_original))}</td><td><b>${h(c.trabajador)}</b></td><td>${h(c.obra)}</td>
    <td>${c.fecha ? fecha(c.fecha) : "<span class='muted'>resumen del mes</span>"}</td><td>${h(c.campo)}</td>
    <td class="num">${h(c.antes)}</td><td class="num"><b>${h(c.ahora)}</b></td><td class="small">${h(origen ?? c.origen)}</td></tr>`;
  const cab = `<thead><tr><th>Mes pagado</th><th>Trabajador</th><th>Obra</th><th>Día</th><th>Qué cambió</th><th class="num">Antes</th><th class="num">Ahora</th><th>Origen</th></tr></thead>`;
  const meses = E.meses_cerrados_todos || [];
  const res = ultimaCorreccion;
  return `
    <h1>Reliquidaciones</h1>
    <p class="sub">Registro de cambios en lo que ya se pagó: horas extra, ausencias o licencias y trabajo de fin de semana, día por día,
      y el resumen de cada trabajador cuando el mes se cerró en la app. Cómo se sube a TALANA todavía está por definir; por ahora queda el registro.</p>
    ${cerrado() ? "" : `<div class="tarjeta" style="padding:16px 18px">
      <h3>Subir el archivo corregido de un mes cerrado</h3>
      <p class="muted small">La obra reenvía la planilla de un mes ya pagado con correcciones. La app la compara con lo pagado y anota cada cambio.</p>
      ${meses.length ? `<div class="obra-archivo">Mes: <select class="in" id="r-mes">${meses.map((m) => `<option value="${m.periodo}">${h(m.mes)} (${fecha(m.desde)} al ${fecha(m.hasta)})</option>`).join("")}</select>
        <label class="boton sec" style="cursor:pointer">Elegir archivo… <input type="file" id="r-archivo" accept=".xlsx,.xlsm" hidden></label></div>`
        : `<p class="muted">Todavía no hay meses cerrados.</p>`}
      ${res ? `<div class="tarjeta listo ${res.cambios.length ? "no" : "si"}" style="margin:14px 0 0">
        <div class="icono">${res.cambios.length ? "📝" : "✅"}</div>
        <div><b>${h(res.nombre)}</b> (${h(nombreMes(res.periodo))}, ${h(res.obra)}): ${res.cambios.length ? `${res.cambios.length} cambio(s) registrados.` : "sin cambios respecto de lo pagado."}
        ${res.avisos.map((a) => `<br><span class="muted small">${h(a)}</span>`).join("")}</div></div>` : ""}
    </div>`}
    ${pendientes.length ? `<h2>Detectadas en los archivos de ${h(E.mes)} <span class="muted small">(se registran al cerrar el mes)</span></h2>
      <div class="tarjeta" style="overflow-x:auto"><table class="tabla">${cab}<tbody>${pendientes.map((c) => fila(c, "archivo de " + E.mes)).join("")}</tbody></table></div>` : ""}
    <div class="cabecera-lista"><h2>Registradas (${registradas.length})</h2>
      ${registradas.length ? `<button class="boton sec" data-guardar="/api/reliquidaciones">Guardar registro en Descargas (Excel)</button>` : ""}</div>
    ${registradas.length ? `<div class="tarjeta" style="overflow-x:auto"><table class="tabla">${cab}<tbody>${registradas.map((c) => fila(c)).join("")}</tbody></table></div>`
      : `<div class="tarjeta vacio">Todavía no hay reliquidaciones registradas.</div>`}`;
}

async function subirCorreccion(file) {
  try {
    const periodo = $("#r-mes").value;
    const r = await api("/api/correccion", { method: "POST", headers: { "X-Nombre": encodeURIComponent(file.name), "X-Periodo": periodo },
      body: await file.arrayBuffer() });
    ultimaCorreccion = { ...r, nombre: file.name };
    await refrescar();
  } catch (e) { aviso(e.message, true); }
}

// ------------------------------------------------------------------ guardar en la carpeta Descargas
async function guardarEnDescargas(url) {
  try {
    const r = await postJSON("/api/guardar", { url });
    aviso(`Guardado en ${r.ruta}`);
    return true;
  } catch (e) { aviso(e.message, true); return false; }
}

// ------------------------------------------------------------------ diálogos de obras y TALANA
const dialogo = (html) => { $("#caso-caja").innerHTML = html; $("#dialogo-caso").hidden = false; };
const cerrarDialogo = () => ($("#dialogo-caso").hidden = true);
const postJSON = (ruta, datos) => api(ruta, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(datos) });

function abrirObra(obra) {
  const t = obra ? E.maestro.tarifas.find((x) => x.obra === obra) : {};
  dialogo(`
    <div class="proceso-titulo">${obra ? `Tarifas de ${h(obra)}` : "Nueva obra"}</div>
    <div class="campos">
      ${obra ? "" : `<label class="ancho">Nombre de la obra <input class="in" id="o-nombre" placeholder="Ej. Unimarc Los Militares"></label>`}
      <label>Sábado <input class="in" id="o-sab" value="${t.sabado ?? ""}" placeholder="vacío = estándar"></label>
      <label>Domingo / feriado <input class="in" id="o-dom" value="${t.domingo ?? ""}" placeholder="vacío = estándar"></label>
      <span class="ayuda ancho" style="grid-column:1/-1">Vacío = tarifa ESTÁNDAR. Las tarifas especiales de un trabajador se ponen en Tarifas y bonos.</span>
    </div>
    <div class="acciones"><button class="boton sec" data-cerrar-dialogo>Cancelar</button><button class="boton" id="o-ok">${obra ? "Guardar" : "Crear obra"}</button></div>`);
  $("[data-cerrar-dialogo]").onclick = cerrarDialogo;
  $("#o-ok").onclick = async () => {
    try {
      const r = await postJSON("/api/obras", { editar: Boolean(obra), obra: obra || $("#o-nombre").value,
        sabado: $("#o-sab").value || null, domingo: $("#o-dom").value || null });
      cerrarDialogo(); await refrescar(); aviso(obra ? "Tarifas guardadas." : `Obra «${r.obra}» creada.`);
    } catch (e) { aviso(e.message, true); }
  };
}

function abrirPlanilla(obra) {
  const p = E.config.periodo;
  const mes = (k) => { const a = Math.floor(p / 100), m = p % 100 - 1 + k; return `${a + Math.floor(m / 12)}-${String(m % 12 + 1).padStart(2, "0")}`; };
  const o = (E.maestro.obras_detalle || []).find((x) => x.obra === obra) || {};
  dialogo(`
    <div class="proceso-titulo">Planilla de ${h(obra)}</div>
    <p class="muted">Formato nuevo: por mes, una hoja Resumen (finiquito, bonos, trato de fin de semana y comentario) y el detalle diario.
      Trae ${o.trabajadores ?? 0} trabajador(es) de TALANA con su fecha de ingreso y contrato; cada uno aparece solo en los meses en que su contrato está vigente.</p>
    <div class="fechas"><label>Desde <input type="month" class="in fecha" id="p-desde" value="${mes(0)}"></label>
      <label>Hasta <input type="month" class="in fecha" id="p-hasta" value="${mes(2)}"></label></div>
    <div class="acciones"><button class="boton sec" data-cerrar-dialogo>Cancelar</button><button class="boton sec" id="p-ok">Descargar</button><button class="boton" id="p-guardar">Guardar en Descargas</button></div>`);
  $("[data-cerrar-dialogo]").onclick = cerrarDialogo;
  $("#p-guardar").onclick = async () => {
    if (await guardarEnDescargas(`/api/planilla?obra=${encodeURIComponent(obra)}&desde=${$("#p-desde").value}&hasta=${$("#p-hasta").value}`)) cerrarDialogo();
  };
  $("#p-ok").onclick = async () => {
    const url = `/api/planilla?obra=${encodeURIComponent(obra)}&desde=${$("#p-desde").value}&hasta=${$("#p-hasta").value}`;
    const r = await fetch(url);
    if (!r.ok) return aviso(((await r.json()) || {}).error || "No se pudo armar la planilla.", true);
    const nombre = decodeURIComponent((r.headers.get("Content-Disposition") || "").split("''")[1] || "planilla.xlsx");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(await r.blob()); a.download = nombre; a.click();
    cerrarDialogo(); aviso(`Descargada: ${nombre}`);
  };
}

// Paquete del mes (30-10-2026): la planilla de ese mes de cada obra con trabajadores, todas en un zip
// Se habilita al subir la exportación de TALANA después del último cierre (E.talana_nueva); por defecto, el mes en curso
function abrirPaquete() {
  const p = E.config.periodo;
  const mes = `${Math.floor(p / 100)}-${String(p % 100).padStart(2, "0")}`;
  const obras = (E.maestro.obras_detalle || []).filter((o) => o.trabajadores > 0);
  const url = () => `/api/paquete?mes=${$("#pq-mes").value}`;
  dialogo(`
    <div class="proceso-titulo">Paquete del mes</div>
    <p class="muted">Arma la planilla del mes de cada obra, con sus trabajadores activos de TALANA y su fecha de ingreso, todas en un solo archivo .zip para enviar a las obras.</p>
    <p class="muted">Trabajadores según la exportación de TALANA del ${fecha(E.talana_nueva.slice(0, 10))}.</p>
    <div class="fechas"><label>Mes <input type="month" class="in fecha" id="pq-mes" value="${mes}"></label></div>
    <p class="small">${obras.length} obra(s): ${obras.map((o) => `${h(o.obra)} (${o.trabajadores})`).join(" · ")}</p>
    <div class="acciones"><button class="boton sec" data-cerrar-dialogo>Cancelar</button><button class="boton sec" id="pq-ok">Descargar</button><button class="boton" id="pq-guardar">Guardar en Descargas</button></div>`);
  $("[data-cerrar-dialogo]").onclick = cerrarDialogo;
  $("#pq-guardar").onclick = async () => { if (await guardarEnDescargas(url())) cerrarDialogo(); };
  $("#pq-ok").onclick = async () => {
    const r = await fetch(url());
    if (!r.ok) return aviso(((await r.json()) || {}).error || "No se pudo armar el paquete.", true);
    const nombre = decodeURIComponent((r.headers.get("Content-Disposition") || "").split("''")[1] || "Planillas obras.zip");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(await r.blob()); a.download = nombre; a.click();
    cerrarDialogo(); aviso(`Descargado: ${nombre}`);
  };
}

async function subirTalana(file) {
  const datos = await file.arrayBuffer();
  let v;
  try { v = await api("/api/talana/vista", { method: "POST", body: datos }); } catch (e) { return aviso(e.message, true); }
  const obras = E.maestro.obras_configuradas || [];
  const fila = (s, i) => {
    const sugerida = s.obra || s.parecida || (s.sugerencia === "no_es_obra" ? "__no__" : "");
    const nombreNueva = s.sucursal.replace(/^SEI\s*[-–]\s*/i, "");
    const nota = s.obra ? "elegida antes" : s.parecida ? "sugerida: revisa" : s.sugerencia ? "sugerida: revisa" : "";
    return `<tr><td><b>${h(s.sucursal)}</b><div class="muted small">${s.personas} persona(s)${s.nuevos ? ` · ${s.nuevos} nueva(s)` : ""}</div></td>
      <td><select class="in" data-suc="${i}" style="width:230px">
        <option value="" ${sugerida ? "" : "selected"}>Elegir…</option>
        ${obras.map((o) => `<option value="${h(o)}" ${o === sugerida ? "selected" : ""}>${h(o)}</option>`).join("")}
        <option value="__nueva__" ${sugerida === "__nueva__" ? "selected" : ""}>+ Crear obra nueva…</option>
        <option value="__no__" ${sugerida === "__no__" ? "selected" : ""}>No es obra (oficina u otro)</option>
      </select>
      <input class="in" data-nueva="${i}" value="${h(nombreNueva)}" style="width:230px;margin-top:4px;display:none" placeholder="Nombre de la obra nueva">
      ${nota ? `<div class="muted small">${nota}</div>` : ""}</td></tr>`;
  };
  dialogo(`
    <div class="proceso-titulo">Trabajadores de TALANA</div>
    <p><b>${v.personas}</b> personas en el archivo: <b>${v.nuevos}</b> nuevas y <b>${v.actualizados}</b> que ya estaban (se actualizan nombre, obra y contrato).</p>
    <p class="muted small">Elige a qué obra corresponde cada sucursal. Queda recordado para la próxima vez.</p>
    <div style="max-height:46vh;overflow:auto"><table class="tabla"><thead><tr><th>Sucursal en TALANA</th><th>Obra en la app</th></tr></thead>
      <tbody>${v.sucursales.map(fila).join("")}</tbody></table></div>
    ${v.no_estan.length ? `<p class="muted small" style="margin-top:10px">En la app pero no en este archivo (no se cambian): ${v.no_estan.map((t) => h(t.nombre)).join(", ")}.</p>` : ""}
    <div class="acciones" style="margin-top:12px"><button class="boton sec" data-cerrar-dialogo>Cancelar</button><button class="boton" id="t-ok">Importar</button></div>`);
  document.querySelectorAll("[data-suc]").forEach((s) => s.onchange = () => {
    $(`[data-nueva="${s.dataset.suc}"]`).style.display = s.value === "__nueva__" ? "" : "none";
  });
  $("[data-cerrar-dialogo]").onclick = cerrarDialogo;
  $("#t-ok").onclick = async () => {
    const mapeo = {};
    const sinElegir = v.sucursales.filter((s, i) => !$(`[data-suc="${i}"]`).value).map((s) => s.sucursal);
    if (sinElegir.length) return aviso("Falta elegir la obra de: " + sinElegir.join(", "), true);
    v.sucursales.forEach((s, i) => {
      const val = $(`[data-suc="${i}"]`).value;
      mapeo[s.sucursal] = val === "__no__" ? "__no_es_obra__" : val === "__nueva__" ? { nueva: $(`[data-nueva="${i}"]`).value } : val;
    });
    try {
      const r = await api("/api/talana/importar", { method: "POST", headers: { "X-Mapeo": encodeURIComponent(JSON.stringify(mapeo)) }, body: datos });
      cerrarDialogo(); await refrescar(); aviso(`Listo: ${r.nuevos} trabajador(es) nuevo(s) y ${r.actualizados} actualizado(s).`);
      if (E.talana_nueva) abrirPaquete();   // siguiente paso: armar las planillas de las obras
    } catch (e) { aviso(e.message, true); }
  };
}

// ------------------------------------------------------------------ 1 · Trabajadores: TALANA, obras y Paquete del mes
function vTrabajadores() {
  const m = E.maestro;
  const tabla = (cab, filas) => `<div class="tarjeta" style="overflow-x:auto"><table class="tabla"><thead><tr>${cab.map((c) => `<th>${c}</th>`).join("")}</tr></thead><tbody>${filas.join("")}</tbody></table></div>`;
  const est = m.tarifas.find((t) => t.obra === "ESTÁNDAR") || {};
  const tar = (v, d) => v == null ? `<span class='muted'>estándar (${$$(d)})</span>` : $$(v);
  const obras = (m.obras_detalle || []).map((o) => `<tr>
    <td><b>${h(o.obra)}</b>${o.sucursales.length ? `<div class="muted small">TALANA: ${o.sucursales.map(h).join(", ")}</div>` : ""}</td>
    <td class="num">${o.trabajadores}</td><td class="num">${tar(o.sabado, est.sabado)}</td><td class="num">${tar(o.domingo, est.domingo)}</td>
    <td style="white-space:nowrap">${cerrado() ? "" : `<button class="link" data-planilla="${h(o.obra)}">Descargar planilla</button> ·
      <button class="link" data-tarifa-obra="${h(o.obra)}">Tarifas</button>`}</td></tr>`);
  const trab = [...m.trabajadores].sort((a, b) => (a.obra || "~").localeCompare(b.obra || "~") || a.muestra.localeCompare(b.muestra));
  const contrato = (t) => [t.tipo_contrato, t.contrato_hasta ? `hasta ${fecha(t.contrato_hasta)}` : ""].filter(Boolean).join(" ");
  return `
    <h1>Trabajadores</h1>
    <p class="sub">Al empezar el mes: sube la lista de empleados de TALANA y después arma el Paquete del mes para enviar a las obras.</p>
    ${cerrado() ? "" : `<div class="tarjeta listo ${E.talana_nueva ? "si" : "no"}">
      <div class="icono">${E.talana_nueva ? "✅" : "⏳"}</div>
      <div style="flex:1"><b>${E.talana_nueva ? `Exportación de TALANA subida el ${fecha(E.talana_nueva.slice(0, 10))}` : `Falta subir la exportación de TALANA de ${h(E.mes)}`}</b><br>
        <span class="muted">${E.talana_nueva ? "Ya puedes armar el Paquete del mes: una planilla por obra, con sus trabajadores al día."
          : "En TALANA: Colaboradores → exportar la lista de empleados (Excel). El Paquete del mes se habilita al subirla."}</span></div>
      <label class="boton ${E.talana_nueva ? "sec" : ""}" style="cursor:pointer">Subir exportación de TALANA…<input type="file" id="t-talana" accept=".xlsx" hidden></label>
      <button class="boton" data-paquete ${E.talana_nueva ? "" : "disabled title='Primero sube la exportación de TALANA'"}>Paquete del mes…</button>
    </div>`}
    <div class="cabecera-lista"><h2>Obras</h2>${cerrado() ? "" : `<button class="boton sec" data-nueva-obra>+ Nueva obra</button>`}</div>
    ${tabla(["Obra", "Trabajadores", "Sábado", "Domingo / feriado", ""], obras)}
    <p class="muted small">Tarifa ESTÁNDAR: sábado ${$$(est.sabado)} · domingo/feriado ${$$(est.domingo)}. «Descargar planilla» arma la de una sola obra, eligiendo los meses. Los casos especiales por trabajador están en
      <button class="link" data-ir="casos">Tarifas y bonos</button>.</p>
    ${horasOficina()}
    <h2>Trabajadores (${m.trabajadores.length})</h2>
    <p class="muted small">De la exportación de TALANA se leen solo RUT, nombre, apellidos, sucursal y fechas y tipo de contrato; no se guardan sueldos ni datos bancarios.</p>
    ${tabla(["Se muestra como", "RUT", "Obra", "Ingreso", "Contrato", "Activo"], trab.map((t) => `<tr class="${t.activo === "No" ? "no-vigente" : ""}">
      <td><b>${h(t.muestra)}</b><div class="muted small">${h(t.nombres)} ${h(t.apellidos)}</div></td>
      <td class="rut">${h(t.rut)} ${t.rut_ok === false ? "<span class='rojo'>✗</span>" : ""}</td>
      <td>${t.obra ? h(t.obra) : `<span class="muted">${t.sucursal ? h(t.sucursal) + " (no es obra)" : "—"}</span>`}</td>
      <td>${t.ingreso ? fecha(t.ingreso) : ""}</td><td class="small">${h(contrato(t))}${t.egreso ? `<div class="rojo small">${h(t.egreso)}</div>` : ""}</td>
      <td>${h(t.activo)}</td></tr>`))}`;
}

// Horas extra a mano para quienes no son de obra (30-10-2026): van solo a «Horas Extra Trabajadas» en TALANA
function horasOficina() {
  const oficina = E.maestro.trabajadores.filter((t) => !t.obra && t.rut && t.activo !== "No")
    .sort((a, b) => a.muestra.localeCompare(b.muestra));
  const deOficina = new Set(oficina.map((t) => t.rut.replace(/\./g, "")));
  const lista = (E.horas_manuales || []).filter((x) => !x.tipo && deOficina.has(x.rut.replace(/\./g, "")));
  const total = lista.reduce((s, x) => s + Number(x.horas || 0), 0);
  return `
    <h2>Horas extra de oficina (${h(E.mes)})</h2>
    <p class="muted small">Para quienes no son de obra (${oficina.length} activos). Van a TALANA solo en «Horas Extra Trabajadas»; si la persona tiene viático, va en la misma fila.</p>
    ${lista.length ? `<div class="tarjeta" style="overflow-x:auto"><table class="tabla"><thead><tr><th>Trabajador</th><th>RUT</th><th class="num">Horas extra</th><th>Comentario</th><th></th></tr></thead><tbody>
      ${lista.map((x) => `<tr><td><b>${h(x.trabajador)}</b></td><td class="rut">${h(x.rut)}</td><td class="num">${n(x.horas)}</td>
        <td>${h(x.comentario || "")}</td><td>${cerrado() ? "" : `<button class="link" data-quitar-horas="${x.id}">Quitar</button>`}</td></tr>`).join("")}
      </tbody><tfoot><tr><td colspan="2"><b>Total</b></td><td class="num"><b>${n(total)}</b></td><td colspan="2"></td></tr></tfoot></table></div>`
      : `<p class="muted">Todavía no hay horas extra de oficina este mes.</p>`}
    ${cerrado() ? "" : `<div class="campos">
      <label>Trabajador <select class="in" id="ho-rut"><option value="">Elegir…</option>
        ${oficina.map((t) => `<option value="${h(t.rut)}">${h(t.muestra)} (${h(t.sucursal || "oficina")})</option>`).join("")}</select></label>
      <label>Horas extra <input class="in" id="ho-horas" inputmode="decimal" placeholder="Ej. 15" style="width:90px"></label>
      <label class="ancho">Comentario <input class="in" id="ho-com" placeholder="Opcional"></label>
      <button class="boton" id="ho-ok" style="align-self:end">Agregar</button>
    </div>`}`;
}

async function agregarHorasOficina() {
  try {
    await postJSON("/api/horas_manuales", { rut: $("#ho-rut").value, horas: $("#ho-horas").value, comentario: $("#ho-com").value });
    await refrescar(); aviso("Horas extra agregadas.");
  } catch (e) { aviso(e.message, true); }
}

// ------------------------------------------------------------------ Configuración: versión de la app
// Feriados y palabras de ausencia ya no se muestran (30-10-2026): la planilla de obra es estándar y la app los usa por dentro
function vConfig() {
  return `
    <h1>Configuración</h1>
    <h2>Versión de la app</h2>
    <p>Versión ${h(E.version || "")} · <button class="boton sec" data-buscar-act>Buscar actualización</button></p>
    <div id="act-resultado"></div>
    <p class="muted small">Actualizar cambia solo el programa: los trabajadores, meses, viáticos y archivos cargados se mantienen.
      La versión anterior queda guardada en la carpeta «app/respaldos_app».</p>`;
}

// ------------------------------------------------------------------ actualizar la app (30-10-2026)
async function buscarActualizacion() {
  const caja = $("#act-resultado");
  caja.innerHTML = `<p class="muted">Revisando…</p>`;
  let r;
  try { r = await api("/api/actualizacion"); } catch (e) { caja.innerHTML = `<p class="rojo">${h(e.message)}</p>`; return; }
  if (!r.hay) { caja.innerHTML = `<p>Tienes la última versión (${h(r.actual)}).</p>`; return; }
  caja.innerHTML = `<div class="tarjeta"><p><b>Hay una versión nueva: ${h(r.nueva)}</b></p>
    ${r.notas ? `<p>${h(r.notas)}</p>` : ""}
    <p class="muted small">Toma menos de un minuto. La app se vuelve a abrir sola en esta misma página.</p>
    <button class="boton" id="act-ok">Actualizar ahora</button></div>`;
  $("#act-ok").onclick = actualizarApp;
}

async function actualizarApp() {
  dialogo(`<div class="proceso-titulo">Actualizando la app…</div><p id="act-paso">Bajando la versión nueva. No cierres esta página ni la ventana de la app.</p>`);
  try {
    await api("/api/actualizar", { method: "POST", headers: { "X-SEI": "actualizar" } });
  } catch (e) {
    $("#act-paso").innerHTML = `<span class="rojo">${h(e.message)}</span>`;
    $("#caso-caja").insertAdjacentHTML("beforeend", `<div class="acciones"><button class="boton" data-cerrar-dialogo>Cerrar</button></div>`);
    $("[data-cerrar-dialogo]").onclick = cerrarDialogo;
    return;
  }
  $("#act-paso").textContent = "Listo. Volviendo a abrir la app con la versión nueva…";
  await new Promise((ok) => setTimeout(ok, 1500));
  for (let i = 0; i < 60; i++) {   // espera hasta un minuto a que el servidor nuevo responda
    try { const r = await fetch("/api/instancia", { cache: "no-store" }); if (r.ok) return location.reload(); } catch (e) { /* todavía no */ }
    await new Promise((ok) => setTimeout(ok, 1000));
  }
  $("#act-paso").innerHTML = `La app se actualizó, pero no volvió a abrirse sola. Cierra la ventana de la app y ábrela de nuevo con doble clic.`;
}

// ------------------------------------------------------------------ eventos
function enlazar() {
  document.querySelectorAll("[data-ir]").forEach((b) => b.onclick = () => ir(b.dataset.ir));
  document.querySelectorAll("[data-ver-mes]").forEach((b) => b.onclick = () => verMes(b.dataset.verMes));
  document.querySelectorAll("[data-cerrar]").forEach((b) => b.onclick = abrirCierre);
  document.querySelectorAll("[data-nuevo-caso]").forEach((b) => b.onclick = () => abrirCaso({
    rut: b.dataset.rut || undefined, obra: b.dataset.obra || undefined }));
  document.querySelectorAll("[data-guardar]").forEach((b) => b.onclick = () => guardarEnDescargas(b.dataset.guardar));
  const vZona = $("#v-zona");
  if (vZona) {
    $("#v-archivo").onchange = (e) => { if (e.target.files[0]) subirViaticos(e.target.files[0]); e.target.value = ""; };
    vZona.ondragover = (e) => { e.preventDefault(); vZona.classList.add("encima"); };
    vZona.ondragleave = () => vZona.classList.remove("encima");
    vZona.ondrop = (e) => { e.preventDefault(); vZona.classList.remove("encima"); if (e.dataTransfer.files[0]) subirViaticos(e.dataTransfer.files[0]); };
  }
  document.querySelectorAll("[data-quitar-viaticos]").forEach((b) => b.onclick = async () => {
    if (!confirm(`¿Quitar todos los viáticos de ${E.mes}?`)) return;
    try { await postJSON("/api/viaticos/quitar", {}); await refrescar(); } catch (e) { aviso(e.message, true); }
  });
  document.querySelectorAll("[data-nueva-obra]").forEach((b) => b.onclick = () => abrirObra(null));
  document.querySelectorAll("[data-paquete]").forEach((b) => b.onclick = abrirPaquete);
  document.querySelectorAll("[data-buscar-act]").forEach((b) => b.onclick = buscarActualizacion);
  if ($("#ho-ok")) $("#ho-ok").onclick = agregarHorasOficina;
  document.querySelectorAll("[data-ni-agregar]").forEach((b) => b.onclick = () => agregarANoInformado(b.dataset.niAgregar));
  document.querySelectorAll("[data-ni-visto]").forEach((b) => b.onclick = () => marcarNoInformado({ rut: b.dataset.niVisto, visto: true }));
  document.querySelectorAll("[data-ni-novisto]").forEach((b) => b.onclick = () => marcarNoInformado({ rut: b.dataset.niNovisto, visto: false }));
  document.querySelectorAll("[data-ni-defecto]").forEach((b) => b.onclick = () => marcarNoInformado({ rut: b.dataset.niDefecto, por_defecto: true }));
  document.querySelectorAll("[data-ni-dias]").forEach((i) => i.onchange = () => marcarNoInformado({ rut: i.dataset.niDias, dias: i.value }));
  document.querySelectorAll("[data-quitar-horas]").forEach((b) => b.onclick = async () => {
    try { await postJSON("/api/horas_manuales/quitar", { id: b.dataset.quitarHoras }); await refrescar(); aviso("Quitadas."); }
    catch (e) { aviso(e.message, true); }
  });
  document.querySelectorAll("[data-tarifa-obra]").forEach((b) => b.onclick = () => abrirObra(b.dataset.tarifaObra));
  document.querySelectorAll("[data-planilla]").forEach((b) => b.onclick = () => abrirPlanilla(b.dataset.planilla));
  const tTalana = $("#t-talana");
  if (tTalana) tTalana.onchange = (e) => { if (e.target.files[0]) subirTalana(e.target.files[0]); e.target.value = ""; };
  const rArchivo = $("#r-archivo");
  if (rArchivo) rArchivo.onchange = (e) => e.target.files[0] && subirCorreccion(e.target.files[0]);
  document.querySelectorAll("[data-obra-archivo]").forEach((s) => s.onchange = async () => {
    if (!s.value) return;
    try {
      const r = await api("/api/obra", { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ archivo_id: Number(s.dataset.obraArchivo), obra: s.value }) });
      await refrescar();
      aviso(`«${r.obra_leida}» = ${r.obra}. Se aplicaron sus tarifas y bonos, y se recordará el próximo mes.`);
    } catch (e) { aviso(e.message, true); }
  });
  document.querySelectorAll("[data-nuevo-trab]").forEach((b) => b.onclick = () =>
    abrirTrabajador(E.filas.find((f) => f.id === Number(b.dataset.nuevoTrab))));
  document.querySelectorAll("[data-editar-caso]").forEach((b) => b.onclick = () =>
    abrirCaso(E.maestro.casos.find((c) => c.id === Number(b.dataset.editarCaso))));
  document.querySelectorAll("[data-borrar-caso]").forEach((b) => b.onclick = async () => {
    const c = E.maestro.casos.find((x) => x.id === Number(b.dataset.borrarCaso));
    if (!confirm(`¿Borrar «${c.tipo}» de ${c.trabajador} (${c.obra})?`)) return;
    try { await api(`/api/casos/${c.id}`, { method: "DELETE" }); await refrescar(); aviso("Borrado. El mes en curso ya se recalculó."); }
    catch (e) { aviso(e.message, true); }
  });
  const zona = $("#zona");
  if (zona) {
    $("#archivo").onchange = (e) => subir(e.target.files);
    zona.ondragover = (e) => { e.preventDefault(); zona.classList.add("encima"); };
    zona.ondragleave = () => zona.classList.remove("encima");
    zona.ondrop = (e) => { e.preventDefault(); zona.classList.remove("encima"); subir(e.dataTransfer.files); };
  }
  document.querySelectorAll("[data-quitar]").forEach((b) => b.onclick = async () => {
    if (!confirm("¿Quitar este archivo y todo lo que se extrajo de él?")) return;
    await api(`/api/archivos/${b.dataset.quitar}`, { method: "DELETE" });
    await refrescar();
  });
  document.querySelectorAll("[data-abrir]").forEach((el) => el.onclick = () => {
    const id = Number(el.dataset.abrir);
    abiertas.has(id) ? abiertas.delete(id) : abiertas.add(id);
    pintar();
  });
  document.querySelectorAll("[data-filtro]").forEach((b) => b.onclick = () => { filtro[b.dataset.filtro] = b.dataset.valor; pintar(); });
  document.querySelectorAll("[data-solo]").forEach((b) => b.onclick = () => { soloRevisar = b.dataset.solo === "1"; pintar(); });
  document.querySelectorAll("[data-propuesta]").forEach((b) => b.onclick = () => {
    const f = E.filas.find((x) => x.id === Number(b.dataset.propuesta));
    decidir(f.id, { dias: f.decision.dias === f.propuesta.dias ? null : f.propuesta.dias });
  });
  document.querySelectorAll("[data-usar]").forEach((b) => b.onclick = () => {
    const id = Number(b.dataset.usar);
    const actual = E.filas.find((x) => x.id === id).decision.usar;
    decidir(id, { usar: actual === b.dataset.v ? null : b.dataset.v });
  });
  document.querySelectorAll("[data-corr]").forEach((i) => i.onchange = () => decidir(Number(i.dataset.corr), { [i.dataset.k]: i.value.trim() === "" ? null : i.value.trim() }));
  document.querySelectorAll("[data-rut]").forEach((s) => s.onchange = async () => {
    const fila = E.filas.find((f) => f.id === Number(s.dataset.rut));
    if (s.value) {
      // Confirmación: evita asignar una fila a otra persona sin querer
      const t = E.maestro.trabajadores.find((x) => x.rut === s.value);
      const inf = fila.informado;
      const otras = E.filas.filter((f) => f.id !== fila.id && f.rut === s.value.replace(/\./g, "")).map((f) => f.obra);
      const msg = `En el archivo dice: ${`${inf.nombre || ""} ${inf.apellido || ""}`.trim()}${inf.rut ? ` (RUT ${inf.rut})` : " (sin RUT)"}.\n\n`
        + `¿Asignar esta fila a ${t.muestra} (${t.rut})?`
        + (otras.length ? `\n\nOJO: ${t.muestra} ya aparece este mes en ${otras.join(", ")}; sus días y horas se van a sumar.` : "");
      if (!confirm(msg)) { s.value = ""; return; }
    }
    try {
      await api("/api/rut", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ fila_id: Number(s.dataset.rut), rut: s.value }) });
      await refrescar();
    } catch (e) { aviso(e.message, true); }
  });
}

document.querySelectorAll("#tabs button").forEach((b) => b.onclick = () => ir(b.dataset.vista));
$("#selector-mes").onchange = (e) => verMes(e.target.value);
$("#cierre-cancelar").onclick = () => ($("#dialogo-cierre").hidden = true);
$("#cierre-ok").onclick = cerrarMes;
refrescar().catch((e) => { $("#vista").innerHTML = `<div class="tarjeta vacio">No se pudo conectar con la app: ${h(e.message)}</div>`; });
