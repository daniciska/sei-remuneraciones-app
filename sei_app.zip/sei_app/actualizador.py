"""Actualizar la app desde la app (pedido 30-10-2026): baja la versión nueva y reemplaza SOLO `app/sei_app`.

- La carpeta `app/datos` (trabajadores, meses, archivos) nunca se toca.
- La versión anterior queda en `app/respaldos_app/` (se guardan las 3 últimas).
- El zip se revisa antes de instalarlo: huella sha256 del version.json, rutas solo dentro de `sei_app/` y que el
  código nuevo se pueda importar. Si algo falla, la versión actual queda como estaba.
"""
import datetime as dt
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import urllib.request
import zipfile

from .version import URL_ACTUALIZACIONES, VERSION

CARPETA_APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))   # app/
CODIGO = os.path.join(CARPETA_APP, "sei_app")
RESPALDOS = os.path.join(CARPETA_APP, "respaldos_app")
TEMPORAL = os.path.join(CARPETA_APP, "_actualizacion")
MAX_BYTES = 20 * 1024 * 1024
OBLIGATORIOS = ("sei_app/__init__.py", "sei_app/servidor.py", "sei_app/version.py", "sei_app/static/app.js")


def _num(v):
    return tuple(int(x) for x in str(v).split("."))


def _bajar(nombre):
    base = os.environ.get("SEI_URL_ACTUALIZACIONES") or URL_ACTUALIZACIONES   # la variable, solo para pruebas
    req = urllib.request.Request(base + nombre, headers={"Cache-Control": "no-cache"})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            datos = r.read(MAX_BYTES + 1)
    except OSError:
        raise ValueError("No se pudo revisar si hay actualizaciones. Revisa la conexión a internet.") from None
    if len(datos) > MAX_BYTES:
        raise ValueError("El archivo de actualización es demasiado grande.")
    return datos


def _manifiesto():
    datos = _bajar("version.json")
    try:
        m = json.loads(datos)
        _num(m["version"])
        return m
    except (ValueError, KeyError, TypeError):
        raise ValueError("La información de la actualización no es válida.") from None


def revisar():
    """{'actual', 'nueva', 'notas', 'hay'}."""
    m = _manifiesto()
    return {"actual": VERSION, "nueva": m["version"], "notas": m.get("notas") or "",
            "hay": _num(m["version"]) > _num(VERSION)}


def instalar():
    """Baja, revisa e instala la versión nueva. Devuelve la versión instalada. Después hay que reiniciar."""
    m = _manifiesto()
    if _num(m["version"]) <= _num(VERSION):
        raise ValueError("Ya tienes la última versión.")
    datos = _bajar(m.get("archivo") or "sei_app.zip")
    if hashlib.sha256(datos).hexdigest() != m.get("sha256"):
        raise ValueError("El archivo bajado no coincide con la versión publicada. Inténtalo de nuevo más tarde.")
    try:
        z = zipfile.ZipFile(io.BytesIO(datos))
        nombres = z.namelist()
    except zipfile.BadZipFile:
        raise ValueError("El archivo de actualización está dañado.") from None
    if any(not n.startswith("sei_app/") or ".." in n.split("/") or "\\" in n for n in nombres) \
            or not all(o in nombres for o in OBLIGATORIOS):
        raise ValueError("El archivo de actualización no tiene la forma esperada.")

    shutil.rmtree(TEMPORAL, ignore_errors=True)
    os.makedirs(TEMPORAL)
    z.extractall(TEMPORAL)
    nuevo = os.path.join(TEMPORAL, "sei_app")
    # Que el código nuevo se pueda importar (con una carpeta de datos de prueba, sin tocar la real)
    prueba = subprocess.run([sys.executable, "-c", "import sei_app.servidor, sei_app.version as v; print(v.VERSION)"],
                            cwd=TEMPORAL, capture_output=True, text=True, timeout=60,
                            env={**os.environ, "SEI_DATOS": os.path.join(TEMPORAL, "datos_prueba")})
    if prueba.returncode != 0 or prueba.stdout.strip() != m["version"]:
        shutil.rmtree(TEMPORAL, ignore_errors=True)
        raise ValueError("La versión nueva no pasó la revisión; se dejó la actual.")
    shutil.rmtree(os.path.join(nuevo, "__pycache__"), ignore_errors=True)

    os.makedirs(RESPALDOS, exist_ok=True)
    respaldo = os.path.join(RESPALDOS, f"sei_app {VERSION} ({dt.datetime.now():%Y-%m-%d %H%M})")
    os.replace(CODIGO, respaldo)
    try:
        os.replace(nuevo, CODIGO)
    except OSError:
        os.replace(respaldo, CODIGO)   # volver a dejar la actual
        raise ValueError("No se pudo reemplazar la app; se dejó la versión actual.") from None
    shutil.rmtree(TEMPORAL, ignore_errors=True)
    for viejo in sorted(os.listdir(RESPALDOS), key=lambda n: os.path.getmtime(os.path.join(RESPALDOS, n)))[:-3]:
        shutil.rmtree(os.path.join(RESPALDOS, viejo), ignore_errors=True)
    return m["version"]
