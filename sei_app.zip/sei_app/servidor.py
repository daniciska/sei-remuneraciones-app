"""Servidor local (solo 127.0.0.1): sirve las pantallas y una API JSON pequeña. Sin dependencias externas."""
import datetime as dt
import json
import mimetypes
import os
import re
import sys
import threading
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import actualizador, db, maestro, motor, servicio, talana, viaticos
from .version import VERSION
from .comun import formatear_rut, nombre_mes

ESTATICOS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")
_lock = threading.Lock()
_con = None


def con():
    global _con
    if _con is None:
        _con = db.conectar()
    return _con


def _json(v):
    if isinstance(v, (dt.date, dt.datetime, dt.time)):
        return v.isoformat()
    raise TypeError(type(v))


def meses(c):
    """Mes en curso + meses cerrados, para el selector de mes."""
    cfg = db.config(c)
    out = [{"periodo": cfg["periodo"], "mes": nombre_mes(cfg["periodo"]), "cerrado_el": None}]
    out += [{"periodo": m["periodo"], "mes": nombre_mes(m["periodo"]), "cerrado_el": m["cerrado_el"]}
            for m in db.meses_cerrados(c) if m["con_foto"]]
    return out


def estado(periodo=None):
    c = con()
    actual = db.config(c)["periodo"]
    if periodo and int(periodo) != actual:
        datos = servicio.foto_mes(c, int(periodo))
    else:
        datos = servicio.estado(c)
        sig = servicio.periodo_siguiente(c)
        datos["siguiente"] = sig | {"mes": nombre_mes(sig["periodo"])}
        datos["talana_nueva"] = servicio.talana_nueva(c)
    return datos | {"meses": meses(c), "periodo_actual": actual, "version": VERSION}


DESCARGAS = ("/api/talana", "/api/planilla", "/api/paquete", "/api/reliquidaciones", "/api/viaticos/planilla")


def archivo_descarga(ruta, q):
    """(nombre, bytes) de un archivo para descargar: carga TALANA, planilla de obra o registro de reliquidaciones."""
    c = con()
    periodo = (q.get("periodo") or [None])[0]
    if ruta == "/api/planilla":
        return servicio.planilla_obra(c, (q.get("obra") or [""])[0], (q.get("desde") or [""])[0], (q.get("hasta") or [""])[0])
    if ruta == "/api/paquete":
        return servicio.paquete_mes(c, (q.get("mes") or [""])[0])
    if ruta == "/api/reliquidaciones":
        return "Registro de reliquidaciones SEI.xlsx", talana.registro_reliquidaciones(db.reliquidaciones(c))
    if ruta == "/api/viaticos/planilla":
        return viaticos.generar(c)
    actual = db.config(c)["periodo"]
    if periodo and int(periodo) != actual:   # mes cerrado: el archivo tal como se guardó al cerrar
        m = db.mes_cerrado(c, int(periodo))
        if not m or not m["talana"]:
            raise ValueError("Ese mes no tiene archivo TALANA guardado.")
        return talana.nombre_archivo(int(periodo)), m["talana"]
    return talana.nombre_archivo(actual), talana.generar(motor.calcular(c)["talana"])


def guardar_en_descargas(nombre, contenido):
    """Guarda en la carpeta Descargas del usuario (si el archivo está abierto en Excel, con otro nombre) y la abre."""
    import subprocess
    carpeta = os.path.join(os.path.expanduser("~"), "Downloads")
    os.makedirs(carpeta, exist_ok=True)
    base, ext = os.path.splitext(nombre)
    ruta, n = os.path.join(carpeta, nombre), 2
    while True:
        try:
            with open(ruta, "wb") as fh:
                fh.write(contenido)
            break
        except PermissionError:   # abierto en Excel
            if os.name != "nt":   # en Mac un archivo abierto no se bloquea: es falta de permiso del sistema
                raise ValueError("El Mac no dio permiso para guardar en Descargas (Configuración del Sistema > "
                                 "Privacidad y seguridad > Archivos y carpetas > Terminal). Mientras, usa «Descargar».") from None
            ruta, n = os.path.join(carpeta, f"{base} ({n}){ext}"), n + 1
            if n > 20:
                raise ValueError("No se pudo guardar: cierra el archivo en Excel y vuelve a intentar.") from None
    if os.name == "nt":
        subprocess.Popen(["explorer", "/select,", ruta])
    elif sys.platform == "darwin":   # Mac: muestra el archivo en el Finder
        subprocess.Popen(["open", "-R", ruta])
    return ruta


class Handler(BaseHTTPRequestHandler):
    server_version = "SEI"

    def log_message(self, *a):  # silencio en la consola
        pass

    # ---------------------------------------------------------------- respuestas
    def _enviar(self, codigo, cuerpo, tipo="application/json; charset=utf-8", extra=None):
        if isinstance(cuerpo, (dict, list)):
            cuerpo = json.dumps(cuerpo, default=_json, ensure_ascii=False).encode("utf-8")
        self.send_response(codigo)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(cuerpo)))
        self.send_header("Cache-Control", "no-store")
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(cuerpo)

    def _error(self, codigo, msg):
        self._enviar(codigo, {"error": msg})

    def _cuerpo(self):
        n = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(n) if n else b""

    def _datos(self):
        return json.loads(self._cuerpo() or b"{}")

    def _xlsx(self, nombre, contenido):
        disp = f"attachment; filename*=UTF-8''{urllib.parse.quote(nombre)}"
        tipo = "application/zip" if nombre.endswith(".zip") else \
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        return self._enviar(200, contenido, tipo, {"Content-Disposition": disp})

    # ---------------------------------------------------------------- rutas
    def do_GET(self):
        url = urllib.parse.urlparse(self.path)
        ruta, q = url.path, urllib.parse.parse_qs(url.query)
        periodo = (q.get("periodo") or [None])[0]
        try:
            if ruta == "/api/instancia":   # para que una instancia nueva encuentre a la anterior de la misma base
                return self._enviar(200, {"app": "sei", "datos": os.path.abspath(db.carpeta_datos())})
            if ruta == "/api/actualizacion":   # sin _lock: consulta internet y no toca la base
                return self._enviar(200, actualizador.revisar())
            if ruta == "/api/estado":
                with _lock:
                    return self._enviar(200, estado(periodo))
            if ruta in DESCARGAS:
                with _lock:
                    nombre, contenido = archivo_descarga(ruta, q)
                return self._xlsx(nombre, contenido)
            return self._estatico(ruta)
        except ValueError as e:
            return self._error(400, str(e))

    def do_POST(self):
        ruta = urllib.parse.urlparse(self.path).path
        if ruta == "/api/apagar":
            # Solo la app (encabezado propio: un sitio web externo no puede mandarlo sin permiso del navegador)
            # y sin cortar una operación a medias
            if self.headers.get("X-SEI") != "apagar":
                return self._error(403, "No permitido")
            self._enviar(200, {"ok": True})
            threading.Thread(target=lambda: (_lock.acquire(), os._exit(0)), daemon=True).start()
            return None
        if ruta == "/api/actualizar":
            # Instala la versión nueva (solo app/sei_app) y reinicia el servidor con ella (ver Servidor.serve_forever)
            if self.headers.get("X-SEI") != "actualizar":   # solo desde la app, como /api/apagar
                return self._error(403, "No permitido")
            try:
                with _lock:
                    version = actualizador.instalar()
            except ValueError as e:
                return self._error(400, str(e))
            self._enviar(200, {"version": version})
            self.server.reiniciar = True
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return None
        try:
            with _lock:
                if ruta == "/api/guardar":
                    # Guarda la descarga directo en la carpeta Descargas y la muestra (sirve aunque el navegador no
                    # permita descargar, ej. el panel de navegador de Claude)
                    url = urllib.parse.urlparse(self._datos().get("url") or "")
                    if url.path not in DESCARGAS:
                        return self._error(400, "No se puede guardar eso.")
                    nombre, contenido = archivo_descarga(url.path, urllib.parse.parse_qs(url.query))
                    return self._enviar(200, {"ruta": guardar_en_descargas(nombre, contenido)})
                if ruta == "/api/archivos":
                    nombre = urllib.parse.unquote(self.headers.get("X-Nombre") or "")
                    return self._enviar(200, servicio.cargar(con(), nombre, self._cuerpo()))
                if ruta == "/api/viaticos":
                    nombre = urllib.parse.unquote(self.headers.get("X-Nombre") or "")
                    return self._enviar(200, viaticos.cargar(con(), nombre, self._cuerpo()))
                if ruta == "/api/horas_manuales":
                    d = self._datos()
                    return self._enviar(200, servicio.agregar_horas_manuales(
                        con(), d.get("rut"), _num(d.get("horas")), d.get("comentario"), d.get("tipo") or None,
                        _num(d.get("monto"))))
                if ruta == "/api/no_informado":
                    d = self._datos()
                    return self._enviar(200, servicio.marcar_no_informado(
                        con(), d.get("rut"), _num(d.get("dias")), d.get("visto"), bool(d.get("por_defecto"))))
                if ruta == "/api/horas_manuales/quitar":
                    db.borrar_horas_manuales(con(), db.config(con())["periodo"], int(self._datos().get("id") or 0))
                    return self._enviar(200, {"ok": True})
                if ruta == "/api/viaticos/quitar":
                    cfg = db.config(con())
                    db.borrar_viaticos(con(), cfg["periodo"])
                    return self._enviar(200, {"ok": True})
                if ruta == "/api/correccion":
                    nombre = urllib.parse.unquote(self.headers.get("X-Nombre") or "")
                    periodo = int(self.headers.get("X-Periodo") or 0)
                    return self._enviar(200, servicio.cargar_correccion(con(), periodo, nombre, self._cuerpo()))
                if ruta == "/api/decision":
                    d = self._datos()
                    db.guardar_decision(con(), int(d["fila_id"]), d.get("usar"), _num(d.get("dias")), _num(d.get("he")),
                                        _num(d.get("monto")))
                    return self._enviar(200, {"ok": True})
                if ruta == "/api/rut":
                    d = self._datos()
                    db.corregir_rut(con(), int(d["fila_id"]), formatear_rut(d.get("rut")) if d.get("rut") else None)
                    return self._enviar(200, {"ok": True})
                if ruta == "/api/casos":
                    d = self._datos()
                    for k in ("sabado", "domingo", "bono"):
                        d[k] = _num(d.get(k))
                    return self._enviar(200, {"id": servicio.guardar_caso(con(), d)})
                if ruta == "/api/obras":
                    d = self._datos()
                    d["sabado"], d["domingo"] = _num(d.get("sabado")), _num(d.get("domingo"))
                    if d.get("editar"):
                        return self._enviar(200, {"obra": maestro.tarifa_obra(con(), d)})
                    return self._enviar(200, {"obra": maestro.crear_obra(con(), d)})
                if ruta == "/api/talana/vista":
                    return self._enviar(200, maestro.vista_previa(con(), self._cuerpo()))
                if ruta == "/api/talana/importar":
                    mapeo = json.loads(urllib.parse.unquote(self.headers.get("X-Mapeo") or "{}"))
                    return self._enviar(200, maestro.importar(con(), self._cuerpo(), mapeo))
                if ruta == "/api/obra":
                    d = self._datos()
                    return self._enviar(200, servicio.asignar_obra(con(), int(d["archivo_id"]), d.get("obra")))
                if ruta == "/api/trabajadores":
                    return self._enviar(200, servicio.agregar_trabajador(con(), self._datos()))
                if ruta == "/api/tipos":
                    d = self._datos()
                    d["monto"] = _num(d.get("monto"))
                    return self._enviar(200, {"tipo": servicio.guardar_tipo(con(), d)})
                if ruta == "/api/cerrar":
                    d = self._datos()
                    return self._enviar(200, servicio.cerrar(con(), d.get("desde"), d.get("hasta")))
            return self._error(404, "No existe")
        except ValueError as e:
            return self._error(400, str(e))

    def do_DELETE(self):
        ruta = urllib.parse.urlparse(self.path).path
        if ruta.startswith("/api/archivos/"):
            try:
                with _lock:
                    db.borrar_archivo(con(), int(ruta.rsplit("/", 1)[1]))
            except ValueError as e:
                return self._error(400, str(e))
            return self._enviar(200, {"ok": True})
        if ruta.startswith("/api/casos/"):
            with _lock:
                db.borrar_caso(con(), int(ruta.rsplit("/", 1)[1]))
            return self._enviar(200, {"ok": True})
        return self._error(404, "No existe")

    def _estatico(self, ruta):
        if ruta in ("", "/"):
            ruta = "/index.html"
        archivo = os.path.normpath(os.path.join(ESTATICOS, ruta.lstrip("/")))
        if not archivo.startswith(ESTATICOS) or not os.path.isfile(archivo):
            return self._error(404, "No existe")
        tipo = mimetypes.guess_type(archivo)[0] or "application/octet-stream"
        if tipo.startswith("text/") or tipo in ("application/javascript",):
            tipo += "; charset=utf-8"
        with open(archivo, "rb") as fh:
            self._enviar(200, fh.read(), tipo)


def _num(v):
    if v in (None, ""):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace("$", "").replace(" ", "")
    if "," in s or s.count(".") > 1 or re.fullmatch(r"\d{1,3}\.\d{3}", s):   # formato chileno: 1.234,5 / 50.000
        s = s.replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        raise ValueError(f"«{v}» no es un número.") from None


class Servidor(ThreadingHTTPServer):
    # Windows: sin SO_REUSEADDR, porque ahí deja que dos instancias escuchen el mismo puerto y las peticiones se
    # reparten entre ambas. Así, una segunda instancia falla al enlazar y pasa al puerto siguiente.
    # Mac/Linux: con SO_REUSEADDR, que ahí no permite dos instancias y evita que al reabrir la app el 8765 quede
    # ocupado unos segundos (TIME_WAIT) y se abra en otro puerto.
    allow_reuse_address = os.name != "nt"
    daemon_threads = True
    reiniciar = False

    def serve_forever(self, *args, **kwargs):
        super().serve_forever(*args, **kwargs)
        if self.reiniciar:
            # Después de actualizar: la app vuelve a abrirse con el código nuevo, en la misma ventana (este proceso
            # espera al nuevo, así que cerrar la ventana sigue cerrando la app, en Windows y en Mac)
            import subprocess
            self.server_close()
            args = [a for a in sys.argv[1:] if a != "--sin-navegador"] + ["--sin-navegador"]
            print("\nApp actualizada. Volviendo a abrir...\n", flush=True)
            raise SystemExit(subprocess.call([sys.executable, sys.argv[0], *args]))


def cerrar_anteriores(desde, hasta):
    """Cierra las instancias abiertas antes con la MISMA base (así siempre corre la versión nueva y hay una sola)."""
    import socket
    import time
    import urllib.request
    mia = os.path.abspath(db.carpeta_datos())
    cerradas = 0
    for p in range(desde, hasta):
        # Prueba rápida: en Windows conectarse a un puerto cerrado tarda ~0,4 s; con 0,05 s basta en el mismo PC
        with socket.socket() as s:
            s.settimeout(0.05)
            if s.connect_ex(("127.0.0.1", p)) != 0:
                continue
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{p}/api/instancia", timeout=0.4) as r:
                info = json.loads(r.read() or b"{}")
        except Exception:  # noqa: BLE001 — puerto libre, otra app o una versión vieja sin /api/instancia
            continue
        if info.get("app") == "sei" and os.path.normcase(info.get("datos", "")) == os.path.normcase(mia):
            try:
                urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{p}/api/apagar", method="POST",
                                                              headers={"X-SEI": "apagar"}), timeout=2)
            except Exception:  # noqa: BLE001
                pass
            cerradas += 1
    if cerradas:
        time.sleep(0.8)
    return cerradas


def servir(puerto=None):
    """Abre el servidor en el primer puerto libre desde `puerto` (o PORT, o 8765). Devuelve (servidor, url)."""
    puerto = int(puerto or os.environ.get("PORT") or 8765)
    cerrar_anteriores(puerto, puerto + 20)
    for p in range(puerto, puerto + 20):
        try:
            srv = Servidor(("127.0.0.1", p), Handler)
            return srv, f"http://127.0.0.1:{p}/"
        except OSError:
            continue
    raise OSError("No hay puertos libres")
