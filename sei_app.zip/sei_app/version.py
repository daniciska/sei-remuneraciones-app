"""Versión de la app y de dónde se bajan las actualizaciones (ver `actualizador.py`).

Al publicar una versión nueva se sube VERSION (AAAA.MM.DD, con .2, .3… si hay más de una el mismo día) y se corre
`python app/herramientas/publicar_actualizacion.py "qué cambió"`.
"""
VERSION = "2026.10.30"

# Repositorio público con solo el código (sin datos): version.json + sei_app.zip
URL_ACTUALIZACIONES = "https://raw.githubusercontent.com/daniciska/sei-remuneraciones-app/main/"
