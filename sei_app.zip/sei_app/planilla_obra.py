"""COPIA EXACTA de .claude/skills/sei-planilla-obra/scripts/crear_planilla_obra.py (formato de la planilla de obra).
Si cambia el formato, cambiar el del skill y correr herramientas/copiar_planilla_skill.py (solo cambian las líneas «app»).
"""
"""Crea la planilla de asistencia y horas extra de UNA obra, solo para los meses que dura.

Uso:
    python crear_planilla_obra.py --obra "FAL" --desde 2026-10 --hasta 2026-12 --carpeta "<carpeta destino>"
                                  [--trabajadores trabajadores.json]

Genera "Planilla Obra FAL (oct-2026 a dic-2026).xlsx" con:
- Hoja "Trabajadores": nombre y apellido, RUT, fecha de ingreso, plazo de contrato
  (1 mes / 3 meses / 6 meses / Indefinido / Finalizado) y fecha de término (solo si finalizó).
  Calcula "Vigente hasta" y el estado del contrato (vigente, vence pronto, vencido, finalizado).
- Dos hojas por mes (formato pedido por SEI el 28-10-2026):
  - "Resumen Octubre 2026": una fila por trabajador. Calcula días, horas extra, sábados, domingos/feriados,
    faltas, licencias y permisos desde el detalle; la obra llena Finiquito (fecha), Bono noche, Bono lejanía,
    Trato fin de semana («Sí», sin montos) y un Comentario. Estado = Finiquitado / Vigente.
  - "Octubre 2026" (detalle diario): días en filas (Día, N°, Mes, Hora inicio, Hora término); tres columnas por
    trabajador (Ausencia: Falta/Licencia/Permiso/Finiquito; Horas extra; Comentario). En sábados, domingos y
    feriados (filas en color) se escribe 1 en Horas extra si trabajó.
  Cada mes cubre el mes calendario (del 1 al último día); octubre 2026 es de transición (25-09 al 31-10) y
  hasta septiembre 2026 era del 25 del mes anterior al 24.
- Los trabajadores aparecen SOLOS en los meses en que su contrato está vigente. Los días fuera de contrato
  quedan en gris y se descuentan de los días trabajados.
- Todo lo que no se llena está bloqueado (protección sin contraseña).

trabajadores.json (opcional) = lista de {"nombre", "rut", "ingreso": "AAAA-MM-DD", "plazo", "termino",
"marcas": {"AAAA-MM": {"noche", "lejania", "trato"}}}; «marcas» (opcional) escribe «Sí» en Bono noche, Bono lejanía y
Trato fin de semana del Resumen de ese mes (la app las calcula desde Tarifas y bonos vigentes en cada mes).
"""
import argparse
import calendar
import datetime as dt
import json
import os
import re
import sys

from openpyxl import Workbook
from openpyxl.drawing.image import Image
from openpyxl.formatting.rule import FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Protection, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

AQUI = os.path.dirname(os.path.abspath(__file__))
from .feriados_chile import ANIOS_COMPLETOS, FERIADOS_CHILE  # noqa: E402,F401  (app)

LOGO = os.path.join(AQUI, "static", "logo_sei.jpeg")  # (app)
MESES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre",
         "Noviembre", "Diciembre"]
MES_CORTO = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"]
DIAS = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
AUSENCIAS = ["Falta", "Licencia", "Permiso"]   # en el detalle también se puede marcar «Finiquito»
PLAZOS = ["1 mes", "3 meses", "6 meses", "Plazo fijo", "Indefinido", "Finalizado"]
DIAS_BASE = 30
HORARIO = {False: (dt.time(8, 0), dt.time(18, 0)), True: (dt.time(8, 0), dt.time(15, 0))}  # True = viernes
N_TRAB = 15                       # trabajadores por hoja de mes
MAX_TRAB = 40                     # filas de la hoja Trabajadores
T_ENC, T1 = 5, 6                  # Trabajadores: encabezado y primera fila
TN = T1 + MAX_TRAB - 1
COL0 = 6                          # primera columna de trabajadores en las hojas de mes (F)
ANCHO = 3                         # columnas por trabajador en el detalle: Ausencia, Horas extra, Comentario
R_ENC, R1 = 5, 6                  # hoja Resumen: encabezado y primera fila de trabajadores
F_NOM, F_RUT, F_ENC, F_DIA1 = 3, 4, 5, 6
HELPER0 = 12                      # Trabajadores: columnas auxiliares (ocultas) desde L, una por mes
MARCAS = ["noche", "lejania", "trato"]   # Resumen: columnas M, N, O (Bono noche, Bono lejanía, Trato fin de semana)

FUENTE = "Calibri"
NEGRO, GRIS, VERDE, VERDE_OSC = "1A1A1A", "7F7F7F", "5BB12F", "3F8A1F"
COLOR_FINDE, COLOR_FUERA = "D6E4CC", "BFBFBF"
F = Font(name=FUENTE, size=10, color=NEGRO)
FB = Font(name=FUENTE, size=10, bold=True, color=NEGRO)
FH = Font(name=FUENTE, size=10, bold=True, color="FFFFFF")
F_NOTA = Font(name=FUENTE, size=9, italic=True, color=GRIS)
HEAD, HEAD_IN = PatternFill("solid", fgColor="404040"), PatternFill("solid", fgColor=VERDE_OSC)
INPUT = PatternFill("solid", fgColor="F2F9EE")
LIN = Side(style="thin", color="D9D9D9")
B = Border(left=LIN, right=LIN, top=LIN, bottom=LIN)
B_SEP = Border(left=Side(style="medium", color="A6A6A6"), right=LIN, top=LIN, bottom=LIN)
ABIERTA = Protection(locked=False)
TRB = "Trabajadores"


def relleno(color):
    return PatternFill(start_color=color, end_color=color, fill_type="solid")


def logo(ws, celda, alto=40):
    if os.path.exists(LOGO):
        img = Image(LOGO)
        img.height, img.width = alto, int(alto * 720 / 420)
        ws.add_image(img, celda)


def proteger(ws):
    ws.protection.sheet = True
    ws.protection.formatColumns = False
    ws.protection.formatRows = False


def periodo(anio, mes):
    """Período de la hoja de un mes (confirmado por SEI el 28-10-2026).

    Hasta sep-2026: del 25 del mes anterior al 24 del mes. Oct-2026 (transición): del 25-09 al 31-10.
    Desde nov-2026: mes calendario, del 1 al último día. La base de cálculo sigue siendo 30 días.
    """
    if (anio, mes) < (2026, 10):
        return dt.date(anio - (mes == 1), 12 if mes == 1 else mes - 1, 25), dt.date(anio, mes, 24)
    if (anio, mes) == (2026, 10):
        return dt.date(2026, 9, 25), dt.date(2026, 10, 31)
    return dt.date(anio, mes, 1), dt.date(anio, mes, calendar.monthrange(anio, mes)[1])


def meses_entre(desde, hasta):
    (a, m), out = desde, []
    while (a, m) <= hasta:
        out.append((a, m))
        a, m = (a + 1, 1) if m == 12 else (a, m + 1)
    return out


def encabezado(c, es_entrada=False, borde=B):
    c.font, c.border = FH, borde
    c.fill = HEAD_IN if es_entrada else HEAD
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def entrada(c, fmt=None):
    c.fill, c.font, c.border, c.protection = INPUT, F, B, ABIERTA
    if fmt:
        c.number_format = fmt


# ------------------------------------------------------------------ hoja Trabajadores
def hoja_trabajadores(wb, obra, meses, trabajadores):
    ws = wb.active
    ws.title = TRB
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = VERDE
    ws.column_dimensions["A"].width = 2
    ws["B1"] = "Trabajadores"
    ws["B1"].font = Font(name=FUENTE, size=20, bold=True, color=NEGRO)
    ws.row_dimensions[1].height = 34
    ws["B2"] = ("Un trabajador por fila. Aparece solo en los meses en que su contrato está vigente. "
                "No borres ni reordenes filas: agrega los nuevos al final.")
    ws["B2"].font = Font(name=FUENTE, size=10, color=GRIS)
    ws["B3"], ws["C3"] = "Obra:", obra
    ws["B3"].font = FB
    ws["C3"].font = Font(name=FUENTE, size=12, bold=True, color=VERDE_OSC)
    a0, m0 = meses[0]
    a1, m1 = meses[-1]
    ws["E3"] = f"Meses: {MES_CORTO[m0 - 1]}-{a0} a {MES_CORTO[m1 - 1]}-{a1}"
    ws["E3"].font = FB
    logo(ws, "I1")

    tit = [("N°", 5, False), ("Nombre y apellido", 36, True), ("RUT", 15, True), ("Fecha de ingreso", 12, True),
           ("Plazo de contrato", 13, True), ("Fecha de término", 13, True),
           ("Vigente hasta", 12, False), ("Estado", 20, False)]
    for i, (t, w, es_in) in enumerate(tit, start=2):
        encabezado(ws.cell(T_ENC, i, t), es_in)
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[T_ENC].height = 32

    plazo = DataValidation(type="list", formula1='"' + ",".join(PLAZOS) + '"', allow_blank=True)
    plazo.error = "Elige un plazo de la lista."
    fecha = DataValidation(type="date", operator="greaterThan", formula1="36526")
    fecha.error = "Escribe una fecha, ej: 01-10-2026"
    rut = DataValidation(type="custom", allow_blank=True,
                         formula1=f'AND(LEN(D{T1})>=11,MID(D{T1},LEN(D{T1})-1,1)="-",LEN(D{T1})-LEN(SUBSTITUTE(D{T1},".",""))=2)')
    rut.errorTitle, rut.error = "RUT", "Escribe el RUT con puntos y guion. Ej: 12.345.678-5"
    for dv in (plazo, fecha, rut):
        ws.add_data_validation(dv)
    plazo.add(f"F{T1}:F{TN}")
    fecha.add(f"E{T1}:E{TN}")
    fecha.add(f"G{T1}:G{TN}")
    rut.add(f"D{T1}:D{TN}")

    for r in range(T1, TN + 1):
        ws.cell(r, 2, r - T1 + 1).font = F
        ws.cell(r, 2).alignment = Alignment(horizontal="center")
        ws.cell(r, 2).border = B
        for c in (3, 4, 5, 6, 7):
            entrada(ws.cell(r, c), "dd-mm-yyyy" if c in (5, 7) else None)
        ws.cell(r, 4).alignment = Alignment(horizontal="right")
        # La fecha de término, si está, manda (plazo fijo con fecha exacta, finalizado o renuncia)
        ws.cell(r, 8, f'=IF(C{r}="","",IF(G{r}<>"",G{r},IF(OR(E{r}="",F{r}="",F{r}="Indefinido",F{r}="Plazo fijo",'
                      f'F{r}="Finalizado"),"",EDATE(E{r},VALUE(LEFT(F{r},1)))-1)))')
        ws.cell(r, 9, f'=IF(C{r}="","",IF(E{r}="","Falta fecha de ingreso",IF(F{r}="","Falta plazo",'
                      f'IF(AND(OR(F{r}="Finalizado",F{r}="Plazo fijo"),G{r}=""),"Falta fecha de término",'
                      f'IF(F{r}="Finalizado","Finalizado",IF(H{r}="","Vigente",IF(H{r}<TODAY(),"Vencido: renovar o finalizar",'
                      f'IF(H{r}-TODAY()<=15,"Vence en "&(H{r}-TODAY())&" días","Vigente"))))))))')
        for c in (8, 9):
            ws.cell(r, c).font, ws.cell(r, c).border = F, B
        ws.cell(r, 8).number_format = "dd-mm-yyyy"
        # auxiliares por mes: N° de orden del trabajador en ese mes (vacío si no está vigente)
        for i in range(len(meses)):
            col = get_column_letter(HELPER0 + i)
            ws.cell(r, HELPER0 + i, f'=IF(AND(C{r}<>"",OR(E{r}="",E{r}<={col}$4),OR(H{r}="",H{r}>={col}$3)),'
                                    f'MAX({col}${T_ENC}:{col}{r - 1})+1,"")')
    for i, (a, m) in enumerate(meses):
        ini, fin = periodo(a, m)
        c = HELPER0 + i
        ws.cell(T_ENC, c, f"{MESES[m - 1]} {a}")
        ws.cell(3, c, ini).number_format = "dd-mm-yyyy"
        ws.cell(4, c, fin).number_format = "dd-mm-yyyy"
        ws.column_dimensions[get_column_letter(c)].hidden = True
    ws.column_dimensions["J"].width = 2
    est = f"I{T1}:I{TN}"
    ws.conditional_formatting.add(est, FormulaRule(formula=[f'OR(LEFT(I{T1},5)="Falta",LEFT(I{T1},7)="Vencido")'],
                                                   fill=relleno("FBE3E1"), font=Font(color="B03A2E", bold=True)))
    ws.conditional_formatting.add(est, FormulaRule(formula=[f'LEFT(I{T1},5)="Vence"'], fill=relleno("FFF1CC"),
                                                   font=Font(color="7A5200", bold=True)))
    ws.conditional_formatting.add(est, FormulaRule(formula=[f'I{T1}="Vigente"'], font=Font(color=VERDE_OSC, bold=True)))
    ws.conditional_formatting.add(est, FormulaRule(formula=[f'I{T1}="Finalizado"'], font=Font(color=GRIS)))
    ws.cell(TN + 2, 2, "Si hay fecha de término, esa manda. Si no: 1, 3 o 6 meses → ingreso + plazo; Indefinido → sin término. "
                       "Plazo fijo y Finalizado necesitan fecha de término. Si se renueva, cambia el plazo o la fecha.").font = F_NOTA

    for i, t in enumerate(trabajadores):
        r = T1 + i
        ws.cell(r, 3, t.get("nombre"))
        ws.cell(r, 4, t.get("rut"))
        for col, k in ((5, "ingreso"), (7, "termino")):
            if t.get(k):
                ws.cell(r, col, dt.date.fromisoformat(t[k]))
        ws.cell(r, 6, t.get("plazo"))
    ws.freeze_panes = f"C{T1}"
    proteger(ws)


# ------------------------------------------------------------------ hojas de mes: detalle diario y resumen
def nombre_detalle(anio, mes):
    return f"{MESES[mes - 1]} {anio}"


def nombre_resumen(anio, mes):
    return f"Resumen {MESES[mes - 1]} {anio}"


def fila_total(f_fin, etiqueta):
    """Fila del bloque de totales (bajo el detalle) para cada etiqueta."""
    return f_fin + 2 + TOTALES.index(etiqueta)


TOTALES = ["Días trabajados", "Horas extra (días hábiles)", "Sábados trabajados", "Domingos / feriados trabajados",
           "Faltas", "Licencias", "Permisos", "Finiquito", "Ingreso", "Vigente hasta"]


def hoja_mes(wb, i_mes, anio, mes, feriados):
    """Detalle diario: por trabajador 3 columnas (Ausencia, Horas extra, Comentario). Totales al final."""
    nombre = nombre_detalle(anio, mes)
    ws = wb.create_sheet(nombre)
    ws.sheet_view.showGridLines = False
    ini, fin = periodo(anio, mes)
    dias = [ini + dt.timedelta(days=k) for k in range((fin - ini).days + 1)]
    f_fin = F_DIA1 + len(dias) - 1
    ultima = COL0 + ANCHO * N_TRAB - 1
    aux = get_column_letter(HELPER0 + i_mes)       # columna auxiliar de este mes en Trabajadores
    orden = f"{TRB}!${aux}${T1}:${aux}${TN}"

    ws.merge_cells("A1:L1")
    ws["A1"] = f"{nombre.upper()} · DETALLE DIARIO"
    ws["A1"].font = Font(name=FUENTE, size=20, bold=True, color=NEGRO)
    ws["A1"].alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 34
    ws["A2"] = f'="Obra: "&{TRB}!$C$3&"   ·   Período: {ini:%d-%m-%Y} al {fin:%d-%m-%Y}"'
    ws["A2"].font = Font(name=FUENTE, size=10, color=GRIS)
    ws["M2"] = f'=IF(MAX({orden})>{N_TRAB},"⚠ Hay más de {N_TRAB} trabajadores vigentes: avisar a RRHH","")'
    ws["M2"].font = Font(name=FUENTE, size=10, bold=True, color="B03A2E")
    logo(ws, "R1")

    fijas = [("Día", 17), ("N°", 5), ("Mes", 11), ("Hora inicio", 9), ("Hora término", 9)]
    for i, (t, w) in enumerate(fijas, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
        encabezado(ws.cell(F_ENC, i, t), i in (4, 5))
    ws.cell(F_NOM, 1, "Trabajador →").font = FB
    ws.cell(F_RUT, 1, "RUT →").font = FB
    ws.row_dimensions[F_ENC].height = 30
    ws.row_dimensions[F_NOM].height = 22

    for k in range(N_TRAB):
        ca, ch, cc = (COL0 + ANCHO * k + j for j in range(ANCHO))
        for col, w in ((ca, 11), (ch, 7), (cc, 18)):
            ws.column_dimensions[get_column_letter(col)].width = w
        for fila, col_trb in ((F_NOM, "C"), (F_RUT, "D")):
            ws.merge_cells(start_row=fila, start_column=ca, end_row=fila, end_column=cc)
            c = ws.cell(fila, ca, f'=IFERROR(INDEX({TRB}!${col_trb}${T1}:${col_trb}${TN},MATCH({k + 1},{orden},0)),"")')
            c.font = FB if fila == F_NOM else F
            c.border = B_SEP
            for col in (ch, cc):
                ws.cell(fila, col).border = B
            c.alignment = Alignment(horizontal="center", vertical="center", shrink_to_fit=True)
        encabezado(ws.cell(F_ENC, ca, "Ausencia"), True, B_SEP)
        encabezado(ws.cell(F_ENC, ch, "Horas extra"), True)
        encabezado(ws.cell(F_ENC, cc, "Comentario"), True)

    lista = DataValidation(type="list", formula1='"' + ",".join(AUSENCIAS + ["Finiquito"]) + '"', allow_blank=True)
    lista.promptTitle, lista.showInputMessage = "Ausencia", True
    lista.prompt = "Vacío = vino. Falta, Licencia o Permiso si no vino. Finiquito = último día del trabajador."
    he = DataValidation(type="decimal", operator="greaterThanOrEqual", formula1="0")
    he.promptTitle, he.prompt, he.showInputMessage = "Horas extra", "Número de horas extra (ej: 2).", True
    he.error = "Solo el número de horas (ej: 2)."
    he_finde = DataValidation(type="whole", operator="between", formula1="0", formula2="1")
    he_finde.promptTitle, he_finde.showInputMessage = "Sábado, domingo o feriado", True
    he_finde.prompt = "Escribe 1 si trabajó este día (se paga el día completo)."
    he_finde.error = "En sábado, domingo o feriado solo se escribe 1 (trabajó) o se deja vacío."
    hora = DataValidation(type="time", operator="between", formula1="0", formula2="0.999988")
    hora.error = "Escribe una hora, ej: 08:00"
    for dv in (lista, he, he_finde, hora):
        ws.add_data_validation(dv)

    for i, d in enumerate(dias):
        r = F_DIA1 + i
        es_feriado = d in feriados
        es_finde = d.weekday() >= 5 or es_feriado
        ws.cell(r, 1, DIAS[d.weekday()] + (" · Feriado" if es_feriado else ""))
        ws.cell(r, 2, d).number_format = "d"
        ws.cell(r, 3, MESES[d.month - 1])
        for col in (1, 2, 3):
            ws.cell(r, col).font, ws.cell(r, col).border = F, B
        ws.cell(r, 2).alignment = Alignment(horizontal="center")
        for col in (4, 5):
            entrada(ws.cell(r, col), "hh:mm")
            ws.cell(r, col).alignment = Alignment(horizontal="center")
        if not es_finde:  # horario de la empresa (editable): lun-jue 08:00-18:00, viernes 08:00-15:00; feriados sin horario
            ws.cell(r, 4).value, ws.cell(r, 5).value = HORARIO[d.weekday() == 4]
        hora.add(f"D{r}:E{r}")
        for k in range(N_TRAB):
            ca, ch, cc = (COL0 + ANCHO * k + j for j in range(ANCHO))
            for col in (ca, ch, cc):
                entrada(ws.cell(r, col))
                ws.cell(r, col).border = B_SEP if col == ca else B
                ws.cell(r, col).alignment = Alignment(horizontal="left" if col == cc else "center", shrink_to_fit=col == cc)
            lista.add(ws.cell(r, ca).coordinate)
            (he_finde if es_finde else he).add(ws.cell(r, ch).coordinate)

    # Totales por trabajador (los usa la hoja de resumen)
    for etiqueta in TOTALES:
        r = fila_total(f_fin, etiqueta)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=5)
        c = ws.cell(r, 1, etiqueta)
        c.font, c.fill = FH, HEAD
        c.alignment = Alignment(horizontal="right", indent=1)
    fechas = f"$B${F_DIA1}:$B${f_fin}"
    dias_col = f"$A${F_DIA1}:$A${f_fin}"
    for k in range(N_TRAB):
        ca, ch, cc = (COL0 + ANCHO * k + j for j in range(ANCHO))
        la, lh = get_column_letter(ca), get_column_letter(ch)
        nom = f"{la}${F_NOM}"
        aus = f"{la}${F_DIA1}:{la}${f_fin}"
        hx = f"{lh}${F_DIA1}:{lh}${f_fin}"
        t = {e: f"{la}${fila_total(f_fin, e)}" for e in TOTALES}
        ing, vig, finq = t["Ingreso"], t["Vigente hasta"], t["Finiquito"]
        # Último día que cuenta: el menor entre «vigente hasta» y el finiquito (si hay alguno)
        ultimo = f'IF({vig}="",{finq},IF({finq}="",{vig},MIN({vig},{finq})))'
        # Días sin contrato, en escala de 30 con el número del día (confirmado el 28-10-2026), tenga el mes 28, 30
        # o 31 días: antes del ingreso = día de ingreso − 1 (entró el 05-10 → 4 → 26 días); después del finiquito o
        # del término = 30 − ese día (finiquito el 14-10 → 16 → 14 días). Último día el 30 o después: no se descuenta.
        inicio, finmes = f"DATE({anio},{mes},1)", f"DATE({fin.year},{fin.month},{fin.day})"
        antes = f'IF({ing}="",0,IF({ing}<={inicio},0,IF({ing}>{finmes},{DIAS_BASE},MIN({DIAS_BASE},DAY({ing})-1))))'
        despues = (f'IF(AND({vig}="",{finq}=""),0,IF({ultimo}>={finmes},0,IF({ultimo}<{inicio},{DIAS_BASE},'
                   f'MAX(0,{DIAS_BASE}-DAY({ultimo})))))')
        fuera = f"({antes})+({despues})"
        sab = f'COUNTIFS({dias_col},"Sábado",{hx},1)'
        dom = (f'COUNTIFS({dias_col},"Domingo*",{hx},1)+COUNTIFS({dias_col},"*Feriado",{hx},1)'
               f'-COUNTIFS({dias_col},"Domingo · Feriado",{hx},1)')
        habil = (f'SUM({hx})-SUMIFS({hx},{dias_col},"Sábado*")-SUMIFS({hx},{dias_col},"Domingo*")'
                 f'-SUMIFS({hx},{dias_col},"*Feriado")+SUMIFS({hx},{dias_col},"Sábado · Feriado")'
                 f'+SUMIFS({hx},{dias_col},"Domingo · Feriado")')
        indice = lambda col: (f'IFERROR(IF(INDEX({TRB}!${col}${T1}:${col}${TN},MATCH({k + 1},{orden},0))="","",'  # noqa: E731
                              f'INDEX({TRB}!${col}${T1}:${col}${TN},MATCH({k + 1},{orden},0))),"")')
        formulas = {
            "Días trabajados": f'=IF({nom}="","",MAX(0,{DIAS_BASE}-{t["Faltas"]}-{t["Licencias"]}-{t["Permisos"]}-({fuera})))',
            "Horas extra (días hábiles)": f'=IF({nom}="","",{habil})',
            "Sábados trabajados": f'=IF({nom}="","",{sab})',
            "Domingos / feriados trabajados": f'=IF({nom}="","",{dom})',
            "Faltas": f'=IF({nom}="","",COUNTIF({aus},"Falta"))',
            "Licencias": f'=IF({nom}="","",COUNTIF({aus},"Licencia"))',
            "Permisos": f'=IF({nom}="","",COUNTIF({aus},"Permiso"))',
            # Finiquito: el día marcado «Finiquito» en el detalle diario (el resumen solo lo muestra; pedido 28-10-2026)
            "Finiquito": f'=IF({nom}="","",IFERROR(INDEX({fechas},MATCH("Finiquito",{aus},0)),""))',
            "Ingreso": f"={indice('E')}",
            "Vigente hasta": f"={indice('H')}",
        }
        for etiqueta, fo in formulas.items():
            r = fila_total(f_fin, etiqueta)
            ws.merge_cells(start_row=r, start_column=ca, end_row=r, end_column=cc)
            c = ws.cell(r, ca, fo)
            c.font, c.border = FB, B_SEP
            for col in (ch, cc):
                ws.cell(r, col).border = B
            c.alignment = Alignment(horizontal="center")
            if etiqueta in ("Finiquito", "Ingreso", "Vigente hasta"):
                c.number_format = "dd-mm-yyyy"
                c.font = F

    # Formato condicional: fuera de contrato o después del finiquito (gris) > alertas > fin de semana (color)
    finde = (f'OR(LEFT($A{F_DIA1},6)="Sábado",LEFT($A{F_DIA1},7)="Domingo",ISNUMBER(SEARCH("Feriado",$A{F_DIA1})))')
    for k in range(N_TRAB):
        ca, ch, cc = (COL0 + ANCHO * k + j for j in range(ANCHO))
        la, lh, lc = (get_column_letter(x) for x in (ca, ch, cc))
        rango = f"{la}{F_DIA1}:{lc}{f_fin}"
        ing, vig, finq = (f"${la}${fila_total(f_fin, e)}" for e in ("Ingreso", "Vigente hasta", "Finiquito"))
        fuera = (f'AND(${la}${F_NOM}<>"",OR(AND({ing}<>"",$B{F_DIA1}<{ing}),AND({vig}<>"",$B{F_DIA1}>{vig}),'
                 f'AND({finq}<>"",$B{F_DIA1}>{finq})))')
        ws.conditional_formatting.add(rango, FormulaRule(formula=[fuera], fill=relleno(COLOR_FUERA)))
        ws.conditional_formatting.add(rango, FormulaRule(formula=[f'${la}${F_NOM}=""'], fill=relleno("F7F7F7")))
        ausente = f'OR({la}{F_DIA1}="Falta",{la}{F_DIA1}="Licencia",{la}{F_DIA1}="Permiso")'
        ws.conditional_formatting.add(f"{lh}{F_DIA1}:{lh}{f_fin}", FormulaRule(
            formula=[f'AND(N({lh}{F_DIA1})>0,{ausente})'], fill=relleno("F4B6B0"), font=Font(color="B03A2E", bold=True)))
        ws.conditional_formatting.add(f"{lh}{F_DIA1}:{lh}{f_fin}", FormulaRule(
            formula=[f'AND({finde},{lh}{F_DIA1}=1)'], fill=relleno(VERDE), font=Font(color="FFFFFF", bold=True)))
        ws.conditional_formatting.add(f"{la}{F_DIA1}:{la}{f_fin}", FormulaRule(
            formula=[ausente], font=Font(color="B03A2E", bold=True)))
        ws.conditional_formatting.add(f"{la}{F_DIA1}:{la}{f_fin}", FormulaRule(
            formula=[f'{la}{F_DIA1}="Finiquito"'], fill=relleno("404040"), font=Font(color="FFFFFF", bold=True)))
    ws.conditional_formatting.add(f"A{F_DIA1}:{get_column_letter(ultima)}{f_fin}", FormulaRule(
        formula=[finde], fill=relleno(COLOR_FINDE), font=Font(bold=True)))

    nota = fila_total(f_fin, TOTALES[-1]) + 2
    ws.cell(nota, 1, "Días hábiles: «Horas extra» = número de horas extra. Sábados, domingos y feriados (filas en color): "
                     "escribir 1 si trabajó; se paga el día completo. Falta, licencia o permiso descuentan días. "
                     "Finiquito = último día del trabajador (desde el día siguiente no cuenta). Gris = fuera de contrato "
                     "o después del finiquito. Los bonos y el trato de fin de semana se marcan en la hoja Resumen.").font = F_NOTA
    ws.freeze_panes = ws.cell(F_DIA1, COL0)
    proteger(ws)
    return f_fin


def vigente_hasta(t):
    """Igual que la columna «Vigente hasta» de Trabajadores: término; si no, ingreso + 1/3/6 meses − 1 día."""
    if t.get("termino"):
        return dt.date.fromisoformat(str(t["termino"])[:10])
    plazo, ingreso = t.get("plazo") or "", t.get("ingreso")
    if not ingreso or plazo[:1] not in "136" or not plazo[:1]:
        return None
    i = dt.date.fromisoformat(str(ingreso)[:10])
    y, m = divmod(i.month - 1 + int(plazo[0]), 12)
    return dt.date(i.year + y, m + 1, min(i.day, calendar.monthrange(i.year + y, m + 1)[1])) - dt.timedelta(days=1)


def vigentes_del_mes(trabajadores, anio, mes):
    """Trabajadores vigentes en el mes, en el orden de la hoja Trabajadores (igual que sus columnas auxiliares)."""
    ini, fin = periodo(anio, mes)
    out = []
    for t in trabajadores:
        ingreso = dt.date.fromisoformat(str(t["ingreso"])[:10]) if t.get("ingreso") else None
        vh = vigente_hasta(t)
        if t.get("nombre") and (ingreso is None or ingreso <= fin) and (vh is None or vh >= ini):
            out.append(t)
    return out


def hoja_resumen(wb, i_mes, anio, mes, f_fin, trabajadores=()):
    """Resumen del mes: una fila por trabajador. Calcula del detalle (incluido el finiquito) y la obra marca bonos y trato."""
    ws = wb.create_sheet(nombre_resumen(anio, mes))
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = VERDE
    det = f"'{nombre_detalle(anio, mes)}'"
    vigentes = vigentes_del_mes(trabajadores, anio, mes)   # mismo orden que la columna auxiliar de Trabajadores
    ini, fin = periodo(anio, mes)
    ws.merge_cells("A1:J1")
    ws["A1"] = f"{MESES[mes - 1].upper()} {anio} · RESUMEN"
    ws["A1"].font = Font(name=FUENTE, size=20, bold=True, color=NEGRO)
    ws.row_dimensions[1].height = 34
    ws["A2"] = f'="Obra: "&{TRB}!$C$3&"   ·   Período: {ini:%d-%m-%Y} al {fin:%d-%m-%Y}   ·   Base de cálculo: {DIAS_BASE} días"'
    ws["A2"].font = Font(name=FUENTE, size=10, color=GRIS)
    logo(ws, "N1")

    cols = [("N°", 5, False), ("Trabajador", 38, False), ("RUT", 14, False), ("Días", 7, False),
            ("Horas extra", 8, False), ("Sábados", 8, False), ("Domingos / feriados", 10, False), ("Faltas", 7, False),
            ("Licencias", 8, False), ("Permisos", 8, False), ("Finiquito", 12, False), ("Estado", 12, False),
            ("Bono noche", 8, True), ("Bono lejanía", 8, True), ("Trato fin de semana", 10, True),
            ("Comentario", 44, True)]
    for i, (t, w, es_in) in enumerate(cols, start=1):
        encabezado(ws.cell(R_ENC, i, t), es_in)
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.row_dimensions[R_ENC].height = 32
    for a, b, t in ((4, 12, "Se calcula solo, desde el detalle diario"), (13, 16, "Lo llena la obra")):
        ws.merge_cells(start_row=R_ENC - 1, start_column=a, end_row=R_ENC - 1, end_column=b)
        c = ws.cell(R_ENC - 1, a, t)
        c.font = Font(name=FUENTE, size=9, bold=True, color=GRIS)
        c.alignment = Alignment(horizontal="center")

    si = DataValidation(type="list", formula1='"Sí"', allow_blank=True)
    si.promptTitle, si.showInputMessage = "Marcar si corresponde este mes", True
    si.prompt = "Elige «Sí» si corresponde este mes. El monto lo pone RRHH."
    ws.add_data_validation(si)

    for k in range(N_TRAB):
        r = R1 + k
        la = get_column_letter(COL0 + ANCHO * k)
        tot = lambda e: f"{det}!${la}${fila_total(f_fin, e)}"  # noqa: E731
        nom = f"{det}!${la}${F_NOM}"
        valores = [k + 1, f'=IF({nom}="","",{nom})', f'=IF({nom}="","",{det}!${la}${F_RUT})',
                   f"={tot('Días trabajados')}", f"={tot('Horas extra (días hábiles)')}", f"={tot('Sábados trabajados')}",
                   f"={tot('Domingos / feriados trabajados')}", f"={tot('Faltas')}", f"={tot('Licencias')}",
                   f"={tot('Permisos')}", f'=IF({tot("Finiquito")}="","",{tot("Finiquito")})',
                   f'=IF({nom}="","",IF({tot("Finiquito")}<>"","Finiquitado","Vigente"))']
        for i, v in enumerate(valores, start=1):
            c = ws.cell(r, i, v)
            c.font, c.border = F, B
            c.alignment = Alignment(horizontal="left" if i == 2 else "center")
        ws.cell(r, 2).font = FB
        ws.cell(r, 11).number_format = "dd-mm-yyyy"
        for i in range(13, 17):   # solo esto lo llena la obra (verde); el resto queda bloqueado
            entrada(ws.cell(r, i))
            ws.cell(r, i).alignment = Alignment(horizontal="left" if i == 16 else "center", wrap_text=i == 16)
        # Bono noche, lejanía y trato vienen ya escritos según Tarifas y bonos vigentes este mes (pedido 28-10-2026);
        # la obra los puede cambiar si este mes no corresponde
        if k < len(vigentes):
            marcas = (vigentes[k].get("marcas") or {}).get(f"{anio}-{mes:02d}") or {}
            for j, m in enumerate(MARCAS):
                if m in marcas:
                    ws.cell(r, 13 + j, "Sí")
        si.add(f"M{r}:O{r}")
    rango = f"L{R1}:L{R1 + N_TRAB - 1}"
    ws.conditional_formatting.add(rango, FormulaRule(formula=[f'L{R1}="Finiquitado"'], fill=relleno("404040"),
                                                     font=Font(color="FFFFFF", bold=True)))
    ws.conditional_formatting.add(rango, FormulaRule(formula=[f'L{R1}="Vigente"'], font=Font(color=VERDE_OSC, bold=True)))
    ws.conditional_formatting.add(f"M{R1}:O{R1 + N_TRAB - 1}", FormulaRule(formula=[f'M{R1}="Sí"'], fill=relleno(VERDE),
                                                                         font=Font(color="FFFFFF", bold=True)))
    ws.cell(R1 + N_TRAB + 1, 1, "Bono noche, bono lejanía y trato de fin de semana: marcar «Sí» si corresponde este mes; "
                                "el monto lo pone RRHH. Finiquito: se marca en el detalle diario («Finiquito» en el último día del "
                                "trabajador) y aquí solo se muestra. Lo demás sale del detalle diario.").font = F_NOTA
    ws.freeze_panes = f"C{R1}"
    proteger(ws)


def nombre_archivo(obra, meses):
    (a0, m0), (a1, m1) = meses[0], meses[-1]
    limpio = re.sub(r'[\\/:*?"<>|]', "-", obra).strip()
    return f"Planilla Obra {limpio} ({MES_CORTO[m0 - 1]}-{a0} a {MES_CORTO[m1 - 1]}-{a1}).xlsx"


def construir(obra, meses, trabajadores):
    """Arma la planilla de la obra (libro de openpyxl). meses = [(año, mes)], trabajadores = lista del JSON."""
    feriados = {f for f, _ in FERIADOS_CHILE}
    wb = Workbook()
    hoja_trabajadores(wb, obra, meses, trabajadores)
    for i, (anio, mes) in enumerate(meses):
        f_fin = hoja_mes(wb, i, anio, mes, feriados)
        hoja_resumen(wb, i, anio, mes, f_fin, trabajadores)
        wb.move_sheet(nombre_resumen(anio, mes), offset=-1)   # el resumen va antes que su detalle diario
    wb.calculation.fullCalcOnLoad = True
    return wb


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--obra", required=True)
    ap.add_argument("--desde", required=True, help="AAAA-MM")
    ap.add_argument("--hasta", required=True, help="AAAA-MM")
    ap.add_argument("--carpeta", default=".")
    ap.add_argument("--trabajadores", help="JSON con la lista de trabajadores (opcional)")
    a = ap.parse_args()
    desde = tuple(int(x) for x in a.desde.split("-"))
    hasta = tuple(int(x) for x in a.hasta.split("-"))
    meses = meses_entre(desde, hasta)
    if not meses or len(meses) > 24:
        sys.exit("Rango de meses inválido (debe ser entre 1 y 24 meses, desde <= hasta).")
    trabajadores = []
    if a.trabajadores:
        with open(a.trabajadores, encoding="utf-8") as fh:
            trabajadores = json.load(fh)
        if len(trabajadores) > MAX_TRAB:
            sys.exit(f"Máximo {MAX_TRAB} trabajadores.")
    destino = os.path.join(a.carpeta, nombre_archivo(a.obra, meses))
    if os.path.exists(destino):
        sys.exit(f"Ya existe {destino}. No se sobrescribe.")
    construir(a.obra, meses, trabajadores).save(destino)
    print(f"Planilla creada: {destino}")
    print(f"Meses: {', '.join(f'{MESES[m - 1]} {y}' for y, m in meses)}. Trabajadores precargados: {len(trabajadores)}.")
    sin_feriados = sorted({y for y, _ in meses} - ANIOS_COMPLETOS)
    if sin_feriados:
        print(f"OJO: los feriados de {sin_feriados} no están completos. Agrégalos en scripts/feriados.py y vuelve a generar.")


if __name__ == "__main__":
    main()
