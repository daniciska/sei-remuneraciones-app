"""Genera el archivo de carga para TALANA: AAAAMM - Haberes y Cargos Obra SEI.xlsx (hoja «Carga de items»)."""
import io

from openpyxl import Workbook

from .comun import TALANA_COLUMNAS, TALANA_HOJA


def nombre_archivo(periodo):
    return f"{periodo} - Haberes y Cargos Obra SEI.xlsx"


def registro_reliquidaciones(filas):
    """Registro de cambios en meses ya pagados (todavía no hay formato TALANA para subirlos)."""
    from .comun import formatear_rut, nombre_mes
    wb = Workbook()
    ws = wb.active
    ws.title = "Reliquidaciones"
    ws.append(["Mes pagado", "Trabajador", "RUT", "Obra", "Día", "Qué cambió", "Antes", "Ahora", "Origen", "Detectado el",
               "Registrado en"])
    for r in filas:
        ws.append([nombre_mes(r["periodo_original"]), r["trabajador"], formatear_rut(r["rut"]), r["obra"],
                   "-".join(reversed(r["fecha"].split("-"))) if r["fecha"] else "(resumen del mes)", r["campo"], r["antes"],
                   r["ahora"], r["origen"], r["detectado_el"].replace("T", " "),
                   nombre_mes(r["periodo_registro"]) if r["periodo_registro"] else ""])
    for col, ancho in zip("ABCDEFGHIJK", (14, 22, 13, 18, 16, 28, 10, 10, 44, 20, 14)):
        ws.column_dimensions[col].width = ancho
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def generar(filas_talana):
    """Devuelve los bytes del .xlsx. Falla si queda alguna fila PENDIENTE: no se exporta a medias."""
    pendientes = [t["trabajador"] for t in filas_talana if t["pendiente"]]
    if pendientes:
        raise ValueError("Faltan filas por revisar: " + ", ".join(pendientes))
    wb = Workbook()
    ws = wb.active
    ws.title = TALANA_HOJA
    ws.append(TALANA_COLUMNAS)
    for t in filas_talana:
        fila = [t["rut"]]
        for c in TALANA_COLUMNAS[1:]:
            v = t["celdas"][c]
            if isinstance(v, float) and v.is_integer():
                v = int(v)
            fila.append(v)    # vacío (None) cuando no hay valor, igual que el archivo de ejemplo
        ws.append(fila)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
