"""COPIA EXACTA de .claude/skills/sei-planilla-obra/scripts/feriados.py. Mantener iguales."""
"""Feriados nacionales de Chile. Mantener igual a FERIADOS_CHILE de sei-remuneraciones/scripts/crear_libro.py."""
import datetime as dt

FERIADOS_CHILE = [
    (dt.date(2026, 1, 1), "Año Nuevo (irrenunciable)"),
    (dt.date(2026, 4, 3), "Viernes Santo"),
    (dt.date(2026, 4, 4), "Sábado Santo"),
    (dt.date(2026, 5, 1), "Día del Trabajo (irrenunciable)"),
    (dt.date(2026, 5, 21), "Día de las Glorias Navales"),
    (dt.date(2026, 6, 21), "Día Nacional de los Pueblos Indígenas"),
    (dt.date(2026, 6, 29), "San Pedro y San Pablo"),
    (dt.date(2026, 7, 16), "Día de la Virgen del Carmen"),
    (dt.date(2026, 8, 15), "Asunción de la Virgen"),
    (dt.date(2026, 9, 18), "Independencia Nacional (irrenunciable)"),
    (dt.date(2026, 9, 19), "Día de las Glorias del Ejército"),
    (dt.date(2026, 10, 12), "Encuentro de Dos Mundos"),
    (dt.date(2026, 10, 31), "Día de las Iglesias Evangélicas y Protestantes"),
    (dt.date(2026, 11, 1), "Día de Todos los Santos"),
    (dt.date(2026, 12, 8), "Inmaculada Concepción"),
    (dt.date(2026, 12, 25), "Navidad (irrenunciable)"),
    (dt.date(2027, 1, 1), "Año Nuevo (irrenunciable)"),
]

# Años con el calendario completo cargado (2027 solo tiene Año Nuevo).
ANIOS_COMPLETOS = {2026}
