"""Constantes y utilidades compartidas (RUT, nombres, columnas TALANA).

Copiado de .claude/skills/sei-remuneraciones/scripts/sei_comun.py: la app no depende del skill.
"""
import re
import unicodedata

# Columnas exactas de la carga "Haberes y Cargos" de TALANA (hoja "Carga de items").
TALANA_COLUMNAS = [
    "rut", "Aguinaldo fiestas patrias", "Aguinaldo navidad", "Anticipo Manual",
    "Asignación Desgaste de Herramientas", "Bono Asistencia", "Bono Noche",
    "Bono Productividad", "Bono Responsabilidad", "Colación (M)",
    "Descuento anticipo viático", "Descuento Crédito Personal CCAF",
    "Descuento Préstamo Empresa", "Descuento Seguro de Vida CCAF",
    "Descuento Seguro Salud", "Horas Extra Trabajadas", "Imponible AFC",
    "Movilización (M)", "Otras Asignaciones", "Otros Descuentos", "Viáticos",
    "Días Trabajados", "Horas Trabajadas",
]
TALANA_HOJA = "Carga de items"
# Las únicas 3 columnas que se llenan (confirmado).
TALANA_DIAS = "Días Trabajados"
TALANA_HE = "Horas Extra Trabajadas"
TALANA_DESGASTE = "Asignación Desgaste de Herramientas"
TALANA_VIATICOS = "Viáticos"   # desde el 28-10-2026: planilla de viáticos del mes
TALANA_ANTICIPO_VIATICO = "Descuento anticipo viático"   # desde el 29-10-2026: viático ya pagado (Pagado = SI)

MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre",
         "noviembre", "diciembre"]


def sin_tildes(texto):
    return "".join(c for c in unicodedata.normalize("NFD", str(texto)) if unicodedata.category(c) != "Mn")


def clave(texto):
    """Normaliza un texto para comparar nombres: minúsculas, sin tildes, espacios simples."""
    if texto is None:
        return ""
    return re.sub(r"\s+", " ", sin_tildes(texto).strip().lower())


def nombre_propio(texto):
    """'  juan   PEREZ soto ' -> 'Juan Perez Soto'."""
    if texto is None:
        return ""
    return " ".join(p[:1].upper() + p[1:].lower() for p in str(texto).split())


def normalizar_rut(rut):
    """Formato TALANA: '18.331.100-k' -> '18331100-K'. Devuelve '' si viene vacío."""
    if rut is None:
        return ""
    s = re.sub(r"[.\s]", "", str(rut)).upper()
    if not s:
        return ""
    if "-" not in s and len(s) >= 2:
        s = s[:-1] + "-" + s[-1]
    return s


def formatear_rut(rut):
    """Formato de lectura: '18331100-K' -> '18.331.100-K'."""
    s = normalizar_rut(rut)
    if "-" not in s:
        return s
    cuerpo, dv = s.split("-", 1)
    if not cuerpo.isdigit():
        return s
    return f"{int(cuerpo):,}".replace(",", ".") + "-" + dv


def rut_valido(rut):
    s = normalizar_rut(rut)
    if "-" not in s:
        return False
    cuerpo, dv = s.split("-", 1)
    if not cuerpo.isdigit():
        return False
    suma = sum(int(d) * w for d, w in zip(reversed(cuerpo), [2, 3, 4, 5, 6, 7] * 3))
    r = 11 - suma % 11
    return dv == ("0" if r == 11 else "K" if r == 10 else str(r))


def obra_desde_archivo(nombre_archivo):
    """'06Jun-H&M ALC.xlsx' o '2026-H&M ALC.xlsx' (planilla anual) -> 'H&M ALC'."""
    base = re.sub(r"\.xls[xm]?$", "", nombre_archivo, flags=re.I).strip()
    base = re.sub(r"\s*(\([^)]*\)|[vV]\.?\s*\d+|[-_]?\s*correg\w*)$", "", base, flags=re.I).strip()
    m = (re.match(r"^\d{1,2}[A-Za-zÁÉÍÓÚáéíóú]{3,}-(.+)$", base)
         or re.match(r"^\d{4}\s*[-_ ]\s*(.+)$", base)
         # Formato de oct-26: «SEI-Remuneraciones-Mall Plaza La Serena-Oct2026» → «Mall Plaza La Serena»
         or re.match(r"^SEI\s*[-_ ]\s*Remuneraciones\s*[-_ ]\s*(.+?)\s*[-_ ]\s*[A-Za-zÁÉÍÓÚáéíóú]{3,10}\.?\s*[-_ ]?\s*\d{4}$",
                     base, flags=re.I))
    obra = (m.group(1) if m else base).strip()
    # Versiones corregidas que manda la obra: "H&M ALC V.2", "H&M ALC v2", "H&M ALC (2)", "H&M ALC (corregido)",
    # "H&M ALC - corregida" → "H&M ALC"
    obra = re.sub(r"\s*[-_]?\s*correg\w*$", "", obra, flags=re.I).strip()
    return re.sub(r"\s*(\([^)]*\)|[vV]\.?\s*\d+)$", "", obra).strip()


def dias_fuera_base30(base, inicio_mes, fin_mes, ingreso, ultimo):
    """Días a descontar de la base (30) por entrar o salir a mitad de mes (confirmado el 28-10-2026).

    Se cuenta con el número del día, en escala de 30, sin importar si el mes tiene 28, 30 o 31 días:
    - antes del ingreso: día de ingreso − 1 (entró el 05-10 → 4; 30 − 4 = 26);
    - después del último día (finiquito o término): 30 − ese día (finiquito el 14-10 → 16; 30 − 16 = 14 días).
      Si el último día es el 30 o después, no se descuenta nada.
    Devuelve (antes, después).
    """
    antes = 0
    if ingreso and ingreso > inicio_mes:
        antes = base if ingreso > fin_mes else min(base, ingreso.day - 1)
    despues = 0
    if ultimo and ultimo < fin_mes:
        despues = base if ultimo < inicio_mes else max(0, base - ultimo.day)
    return antes, despues


def nombre_mes(periodo):
    """202606 -> 'Junio 2026'."""
    p = int(periodo)
    return f"{MESES[p % 100 - 1].capitalize()} {p // 100}"
