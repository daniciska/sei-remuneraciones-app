"""Lee un archivo de horas de una obra y devuelve lo extraído (resumen, detalle diario y avisos).

La lectura es la misma de .claude/skills/sei-remuneraciones/scripts/cargar_obras.py, pero en vez de escribir
en el libro devuelve los datos para que la app los guarde y los muestre.
"""
import collections
import datetime as dt
import re

from openpyxl import load_workbook

from .comun import (MESES, clave, dias_fuera_base30, formatear_rut, nombre_propio, normalizar_rut, obra_desde_archivo,
                    rut_valido)

HOJA_RESUMEN = "general remuneraciones"
RE_HORAS = re.compile(r"(\d+(?:[.,]\d+)?)\s*(?:h|hr|hrs|hora|horas)\b")
AUSENCIAS_ANUAL = ["licencia", "permiso", "injustificado", "falta"]
MAX_HE_DIA = 24   # un número mayor en el detalle diario no son horas extra (ej. un monto en pesos)


def numero(v):
    if v is None or v == "":
        return None
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip().replace("$", "").replace(".", "").replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def texto(v):
    return "" if v is None else str(v).strip()


# ------------------------------------------------------------------ resumen
def mapear_encabezados(fila):
    m = {"bonos": []}
    for idx, v in fila:
        h = clave(v)
        if not h:
            continue
        if h == "rut":
            m["rut"] = idx
        elif h == "nombre":
            m["nombre"] = idx
        elif h.startswith("apellido"):
            m["apellido"] = idx
        elif h == "obra":
            m["lugar"] = idx
        elif h.startswith("dias"):
            m["dias"] = idx
        elif "horas extra" in h:
            m["he"] = idx
        elif h.startswith("sabado") and "sab" not in m:
            m["sab"] = idx
        elif ("domingo" in h or "feriado" in h) and "dom" not in m:
            m["dom"] = idx
        elif "fin de semana" in h and ("total" in h or "monto" in h):
            m["monto_fds"] = idx
        elif "bono" in h:
            m["bonos"].append(idx)
        elif h.startswith("observ"):
            m["obs"] = idx
        elif h.startswith("hoja"):
            m["hoja"] = idx  # columna informativa de la plantilla SEI
    return m


def leer_resumen(ws):
    fila_h = None
    for r in range(1, 21):
        if any(clave(ws.cell(r, c).value) == "rut" for c in range(1, 30)):
            fila_h = r
            break
    if fila_h is None:
        raise ValueError(f"No se encontró la fila de encabezados (con 'RUT') en la hoja '{ws.title}'")
    m = mapear_encabezados([(c, ws.cell(fila_h, c).value) for c in range(1, ws.max_column + 1)])
    faltan = [k for k in ("nombre", "dias", "he") if k not in m]
    if faltan:
        raise ValueError(f"Faltan columnas en '{ws.title}': {faltan}")
    obra_d4 = texto(ws["D4"].value)
    periodo_txt = ws["D2"].value
    usadas = {v for k, v in m.items() if k != "bonos"} | set(m["bonos"])
    filas, notas = [], []
    for r in range(fila_h + 1, ws.max_row + 1):
        g = lambda k: ws.cell(r, m[k]).value if k in m else None  # noqa: E731
        rut, nom, ape = texto(g("rut")), texto(g("nombre")), texto(g("apellido"))
        if not (rut or nom or ape):
            for c in range(1, ws.max_column + 1):
                v = ws.cell(r, c).value
                if isinstance(v, str) and v.strip():
                    notas.append(v.strip())
            continue
        bonos = [numero(ws.cell(r, c).value) for c in m["bonos"]]
        bonos = [b for b in bonos if b]
        # Finiquito anotado en la fila (ej. CC Pedro Fontova oct-26: «FINIQUITO» y la fecha en columnas al final)
        celdas = [ws.cell(r, c).value for c in range(1, ws.max_column + 1)]
        finiquito = None
        if any(isinstance(v, str) and "finiquit" in clave(v) for v in celdas):
            finiquito = next((v.date() if isinstance(v, dt.datetime) else v for v in celdas
                              if isinstance(v, (dt.date, dt.datetime))), None)
        filas.append({
            "rut": rut, "nombre": nom, "apellido": ape,
            "lugar": texto(g("lugar")) or obra_d4,
            "dias": numero(g("dias")), "he": numero(g("he")),
            "sab": numero(g("sab")), "dom": numero(g("dom")),
            "monto_fds": numero(g("monto_fds")),
            "bonos": sum(bonos) if bonos else None,
            "obs": texto(g("obs")),
            "fila_archivo": r,
            "finiquito": finiquito,
        })
        for c in range(1, ws.max_column + 1):
            v = ws.cell(r, c).value
            if c not in usadas and isinstance(v, str) and v.strip():
                notas.append(f"{ws.cell(r, c).coordinate}: {v.strip()}"
                             + (f" ({finiquito:%d-%m-%Y})" if finiquito and "finiquit" in clave(v) else ""))
    columnas = [(clave(ws.cell(fila_h, c).value) or "") for c in range(1, ws.max_column + 1)]
    return filas, notas, periodo_txt, sorted(m.keys()), [c for c in columnas if c]


# ------------------------------------------------------------------ detalle diario
def es_hora(v):
    return isinstance(v, (dt.time, dt.datetime)) or bool(re.fullmatch(r"\d{1,2}:\d{2}(:\d{2})?", texto(v)))


def leer_detalle(ws, palabras_ausencia):
    fila_h = None
    for r in range(1, 9):
        if any(clave(ws.cell(r, c).value) == "fecha" for c in range(1, 15)):
            fila_h = r
            break
    if fila_h is None:
        return None, "sin encabezado FECHA"
    cols = {"obs": []}
    for c in range(1, ws.max_column + 1):
        h = clave(ws.cell(fila_h, c).value)
        if h == "fecha":
            cols["fecha"] = c
        elif h.startswith("asistencia") or h == "estado":
            cols["asist"] = c  # plantilla SEI: Trabajó / Libre / Licencia / Permiso / Falla
        elif "nombre" in h:
            cols["nombre"] = c
        elif "entrada" in h:
            cols["entrada"] = c
        elif "salida" in h:
            cols["salida"] = c
        elif "horas extra" in h or h in ("he", "hrs extra", "h.e."):
            cols["he"] = c
        elif h.startswith("observ"):
            cols["obs"].append(c)
    if "fecha" not in cols or "nombre" not in cols:
        return None, "sin columnas FECHA/NOMBRE"
    filas = [r for r in range(fila_h + 1, ws.max_row + 1)
             if isinstance(ws.cell(r, cols["fecha"]).value, (dt.datetime, dt.date))]
    fuente_he = "columna HORAS EXTRA" if "he" in cols else None
    if "he" not in cols and "salida" in cols:
        c = cols["salida"] + 1
        if clave(ws.cell(fila_h, c).value) == "" and any(isinstance(ws.cell(r, c).value, (int, float)) for r in filas):
            cols["he"] = c
            fuente_he = "columna sin título junto a HORA SALIDA"
    ultima = max(c for c in range(1, ws.max_column + 1) if clave(ws.cell(fila_h, c).value))
    if "he" not in cols:
        # Otra columna sin título con números de horas (ej. DOITE oct-26: junto a OBSERVACIONES)
        for c in range(1, min(ws.max_column, ultima + 1) + 1):
            if c in cols.values() or c in cols["obs"] or clave(ws.cell(fila_h, c).value):
                continue
            nums = [ws.cell(r, c).value for r in filas if isinstance(ws.cell(r, c).value, (int, float))]
            if any(0 < x <= MAX_HE_DIA for x in nums):   # los montos de la misma columna se apartan como aviso
                cols["he"] = c
                fuente_he = "columna sin título con números de horas"
                break
    # columnas de texto sin título que también son observaciones (ej. 'casa blanca', 'cchc')
    extra_obs = [c for c in range(1, min(ws.max_column, ultima + 1) + 1)
                 if c not in cols.values() and c not in cols["obs"] and clave(ws.cell(fila_h, c).value) == ""
                 and any(isinstance(ws.cell(r, c).value, str) for r in filas)]
    cols["obs"] += extra_obs

    conteo = collections.Counter()
    for r in filas:
        v = ws.cell(r, cols["nombre"]).value
        k = clave(v)
        if isinstance(v, str) and len(k) > 2 and not es_hora(v) and not any(p in k for p in palabras_ausencia):
            conteo[k] += 1
    if not conteo:
        return None, "sin nombre de trabajador (hoja vacía o plantilla sin usar)"
    trabajador = conteo.most_common(1)[0][0]

    registros, montos = [], []
    for r in filas:
        f = ws.cell(r, cols["fecha"]).value
        f = f.date() if isinstance(f, dt.datetime) else f
        nom = ws.cell(r, cols["nombre"]).value
        knom = clave(nom)
        obs_txt = [texto(ws.cell(r, c).value) for c in cols["obs"] if texto(ws.cell(r, c).value)]
        if "asist" in cols:
            va = clave(ws.cell(r, cols["asist"]).value)
            asistio = 1 if va.startswith("trabaj") else 0
            if va and not va.startswith("trabaj") and va != "libre":
                obs_txt.insert(0, texto(ws.cell(r, cols["asist"]).value))
        else:
            asistio = 1 if knom == trabajador else 0
        if knom and knom != trabajador and not es_hora(nom):
            obs_txt.insert(0, texto(nom))
        todo = " ".join(clave(o) for o in obs_txt)
        ausencia = 1 if any(re.search(rf"\b{re.escape(p)}\b", todo) for p in palabras_ausencia) else 0
        he = None
        if "he" in cols:
            v = ws.cell(r, cols["he"]).value
            he = numero(v) if not isinstance(v, str) else None
            if isinstance(v, str):
                mm = RE_HORAS.search(clave(v))
                he = float(mm.group(1).replace(",", ".")) if mm else None
            if he is not None and he > MAX_HE_DIA:   # un monto (ej. 50000 el sábado), no horas
                montos.append((f, he))
                he = None
        if he is None:
            # Un número solo en OBSERVACIONES = horas extra del día (ej. CC Pedro Fontova oct-26: «5» los viernes)
            for c in cols["obs"]:
                v = ws.cell(r, c).value
                if isinstance(v, (int, float)) or re.fullmatch(r"\d+(?:[.,]\d+)?", texto(v)):
                    x = numero(v) if not isinstance(v, str) else float(texto(v).replace(",", "."))
                    if 0 < x <= MAX_HE_DIA:
                        he = x
                        fuente_he = fuente_he or "número escrito en OBSERVACIONES"
                    elif x > MAX_HE_DIA:
                        montos.append((f, x))
                    break
        if he is None:
            mm = RE_HORAS.search(todo)
            if mm:
                he = float(mm.group(1).replace(",", "."))
                fuente_he = fuente_he or "texto en observaciones (ej. '2 horas')"
        ent = ws.cell(r, cols["entrada"]).value if "entrada" in cols else None
        sal = ws.cell(r, cols["salida"]).value if "salida" in cols else None
        registros.append({
            "fecha": f, "nombre": texto(nom), "entrada": ent if isinstance(ent, dt.time) else None,
            "salida": sal if isinstance(sal, dt.time) else None, "he": he, "asistio": asistio,
            "ausencia": ausencia, "obs": "; ".join(obs_txt),
            # En el formato antiguo los fines de semana trabajados no se marcan (confirmado): no se comparan día a día
            "fds_fiable": 1 if "asist" in cols else 0,
        })
    return {"trabajador": trabajador, "registros": registros, "fuente_he": fuente_he or "sin horas extra", "montos": montos,
            "formato": "plantilla SEI (con ASISTENCIA)" if "asist" in cols else "formato antiguo"}, None


def unir_hoja_con_fila(trabajador, filas_resumen):
    """Devuelve el índice de la fila del resumen que corresponde al nombre de la hoja de detalle."""
    tk = set(trabajador.split())
    puntajes = []
    for i, f in enumerate(filas_resumen):
        fk = set(clave(f["nombre"] + " " + f["apellido"]).split())
        inter = len(tk & fk)
        if inter:
            puntajes.append((inter, inter / len(tk | fk), i))
    if not puntajes:
        return None, "sin coincidencia"
    puntajes.sort(reverse=True)
    if len(puntajes) > 1 and puntajes[0][:2] == puntajes[1][:2]:
        return None, "ambiguo"
    return puntajes[0][2], None


# ------------------------------------------------------------------ planilla por obra (una hoja por mes)
def _mes_de_hoja(ws):
    partes = clave(ws.title).split()
    return partes[0] if partes and partes[0] in MESES else None


def es_anual(src):
    """Planilla de obra por meses: hojas "Junio" (anual) o "Octubre 2026" (planilla por obra)."""
    return any(_mes_de_hoja(ws) and clave(ws.cell(5, 1).value) == "dia" for ws in src.worksheets)


def hoja_del_mes(src, periodo):
    """Hoja del mes (y año, si la hoja lo indica) del período configurado (AAAAMM)."""
    try:
        anio, mes = int(periodo) // 100, MESES[int(periodo) % 100 - 1]
    except (TypeError, ValueError, IndexError):
        return None
    for ws in src.worksheets:
        partes = clave(ws.title).split()
        if _mes_de_hoja(ws) == mes and (len(partes) < 2 or partes[1] == str(anio)):
            return ws
    return None


def obra_de_planilla(src):
    """Nombre de la obra escrito en la hoja Trabajadores (planilla por obra), si existe."""
    ws = next((w for w in src.worksheets if clave(w.title) == "trabajadores"), None)
    return texto(ws["C3"].value) if ws is not None else ""


def _fila_etiqueta(ws, etiqueta, desde):
    for r in range(desde, desde + 60):
        if clave(ws.cell(r, 1).value) == etiqueta:
            return r
    return None


def hoja_resumen_del_mes(src, hoja_mes):
    """Hoja «Resumen Octubre 2026» de la planilla nueva (si existe)."""
    buscada = "resumen " + clave(hoja_mes.title)
    return next((w for w in src.worksheets if clave(w.title) == buscada), None)


def leer_resumen_planilla(ws):
    """Marcas y comentario por trabajador de la hoja Resumen: {rut o n°: {...}}."""
    out = {}
    a_fecha = lambda v: v.date() if isinstance(v, dt.datetime) else (v if isinstance(v, dt.date) else None)  # noqa: E731
    si = lambda v: clave(v) in ("si", "x", "1")  # noqa: E731
    for r in range(6, 6 + 40):
        n = ws.cell(r, 1).value
        if not isinstance(n, (int, float)):
            break
        datos = {"finiquito": a_fecha(ws.cell(r, 11).value),
                 "marcas": {"noche": si(ws.cell(r, 13).value), "lejania": si(ws.cell(r, 14).value),
                            "trato": si(ws.cell(r, 15).value)},
                 "comentario": texto(ws.cell(r, 16).value)}
        out[int(n)] = datos
        rut = normalizar_rut(ws.cell(r, 3).value)
        if rut:
            out[rut] = datos
    return out


def leer_anual(ws, palabras, dias_base, obra, resumen=None):
    """Lee la hoja de un mes de la planilla de obra. Devuelve filas (formato resumen) y sus registros diarios.

    Formato nuevo (desde oct-26): 3 columnas por trabajador (Ausencia, Horas extra, Comentario) y una hoja Resumen
    con finiquito, bono noche, bono lejanía, trato de fin de semana y comentario. Formato anterior: 2 columnas.
    """
    titulo = texto(ws["A1"].value)
    m = re.search(r"(\d{4})", titulo)
    anio = int(m.group(1)) if m else dt.date.today().year
    mes_hoja = MESES.index(_mes_de_hoja(ws)) + 1
    inicio_mes = dt.date(anio, mes_hoja, 1)   # primer día del mes calendario de la hoja
    f_ing = _fila_etiqueta(ws, "ingreso", 30)
    f_vig = _fila_etiqueta(ws, "vigente hasta", 30)
    a_fecha = lambda v: v.date() if isinstance(v, dt.datetime) else (v if isinstance(v, dt.date) else None)  # noqa: E731
    ausencias = set(palabras) | set(AUSENCIAS_ANUAL)
    ancho = 3 if clave(ws.cell(5, 8).value) == "comentario" else 2
    marcas_resumen = leer_resumen_planilla(resumen) if resumen is not None else {}
    filas, detalles = [], []
    c, k = 6, 0
    while c <= ws.max_column:
        nombre = texto(ws.cell(3, c).value)
        rut = texto(ws.cell(4, c).value)
        k += 1
        if nombre or rut:
            ingreso = a_fecha(ws.cell(f_ing, c).value) if f_ing else None
            vigente = a_fecha(ws.cell(f_vig, c).value) if f_vig else None
            res = marcas_resumen.get(normalizar_rut(rut)) or marcas_resumen.get(k) or {}
            # Finiquito: la fecha del resumen manda; si no hay, el día marcado «Finiquito» en el detalle
            finiquito = res.get("finiquito")
            r = 6
            while finiquito is None and isinstance(ws.cell(r, 2).value, (int, float, dt.date, dt.datetime)):
                if clave(ws.cell(r, c).value) == "finiquito" and isinstance(ws.cell(r, 2).value, (dt.date, dt.datetime)):
                    finiquito = a_fecha(ws.cell(r, 2).value)
                r += 1
            regs = []
            r = 6
            while isinstance(ws.cell(r, 2).value, (int, float, dt.date, dt.datetime)):
                dia_txt = texto(ws.cell(r, 1).value)
                b = ws.cell(r, 2).value
                if isinstance(b, (dt.date, dt.datetime)):
                    fecha = a_fecha(b)
                else:
                    mes_txt = clave(ws.cell(r, 3).value)
                    mes = MESES.index(mes_txt) + 1 if mes_txt in MESES else mes_hoja
                    fecha = dt.date(anio - (mes > mes_hoja), mes, int(b))
                fuera = (ingreso and fecha < ingreso) or (vigente and fecha > vigente)
                post_finiquito = bool(finiquito and fecha > finiquito)
                sin_contrato = bool(fuera or post_finiquito)
                kd = clave(dia_txt)
                finde = kd.startswith("sabado") or kd.startswith("domingo") or "feriado" in kd
                marca = texto(ws.cell(r, c).value)
                km = clave(marca)
                # Días sin contrato (antes del ingreso, después del término o del finiquito) no son ausencias: se
                # descuentan aparte, en escala de 30 (comun.dias_fuera_base30).
                ausente = 1 if (not sin_contrato and any(p in km for p in ausencias)) else 0
                if fuera:
                    marca = "Fuera de contrato"
                elif post_finiquito:
                    marca = "Después del finiquito"
                valor = numero(ws.cell(r, c + 1).value)
                comentario = texto(ws.cell(r, c + 2).value) if ancho == 3 else ""
                if sin_contrato:
                    trabajo, he = 0, None
                elif finde:
                    # Sábado, domingo o feriado: un 1 en la celda de horas extra = trabajó el día completo
                    trabajo, he = (1 if (valor or 0) >= 1 and not ausente else 0), None
                else:
                    trabajo, he = (0 if ausente else 1), valor
                ent, sal = ws.cell(r, 4).value, ws.cell(r, 5).value
                obs = "; ".join(x for x in ((marca if ausente or sin_contrato or km == "finiquito" else ""), comentario) if x)
                regs.append({"fecha": fecha, "nombre": nombre, "he": he, "asistio": trabajo, "ausencia": ausente,
                             "entrada": ent if isinstance(ent, dt.time) else None,
                             "salida": sal if isinstance(sal, dt.time) else None,
                             "obs": obs, "dia": kd, "fds_fiable": 1})
                r += 1
            sab = sum(1 for g in regs if g["asistio"] and g["dia"] == "sabado")
            dom = sum(1 for g in regs if g["asistio"] and (g["dia"].startswith("domingo") or "feriado" in g["dia"]))
            partes = nombre.split()
            corte = 1 if len(partes) <= 3 else 2   # "Juan Perez Soto" → Juan | Perez Soto
            ultimo = min([x for x in (finiquito, vigente) if x], default=None)
            fin_hoja = regs[-1]["fecha"] if regs else inicio_mes
            antes, despues = dias_fuera_base30(dias_base, inicio_mes, fin_hoja, ingreso, ultimo)
            filas.append({"rut": rut, "nombre": " ".join(partes[:corte]), "apellido": " ".join(partes[corte:]),
                          "lugar": obra,
                          "dias": max(0, dias_base - sum(g["ausencia"] for g in regs) - antes - despues),
                          "ingreso": ingreso, "termino": vigente,
                          "he": sum(g["he"] or 0 for g in regs), "sab": sab, "dom": dom,
                          "monto_fds": None, "bonos": None, "obs": res.get("comentario") or "", "fila_archivo": None,
                          # Solo en la planilla nueva (con hoja Resumen): lo que marcó la obra este mes
                          "marcas": res.get("marcas") if resumen is not None else None,
                          "finiquito": finiquito})
            for g in regs:
                g.pop("dia")
            detalles.append({"hoja": ws.title, "registros": regs})
        c += ancho
    return filas, detalles, titulo


# ------------------------------------------------------------------ archivo completo
def leer_archivo(ruta, nombre, periodo, dias_base, palabras):
    """Lee un archivo de obra. Devuelve un dict con la obra, las filas (cada una con su detalle diario) y los avisos.

    Avisos: lista de {"nivel": "info" | "alerta", "texto": ...}. Lanza ValueError si el archivo no se puede leer.
    """
    obra = obra_desde_archivo(nombre)
    src = load_workbook(ruta, data_only=True)
    avisos = []
    aviso = lambda nivel, t: avisos.append({"nivel": nivel, "texto": t})  # noqa: E731

    if es_anual(src):
        hoja_mes = hoja_del_mes(src, periodo)
        if hoja_mes is None:
            raise ValueError(f"Es una planilla de obra por meses y no tiene la hoja del mes {periodo}.")
        obra = obra_de_planilla(src) or obra
        resumen = hoja_resumen_del_mes(src, hoja_mes)
        filas, detalles, periodo_txt = leer_anual(hoja_mes, palabras, dias_base, obra, resumen)
        for f, d in zip(filas, detalles):
            f["detalle"] = d["registros"]
            f["hojas"] = [d["hoja"]]
            regs = d["registros"]
            aviso("info", f"{nombre_propio(f['nombre'] + ' ' + f['apellido'])}: {f['dias']} días, {f['he']:g} horas extra, "
                          f"{f['sab']} sábados, {f['dom']} domingos/feriados, {sum(g['ausencia'] for g in regs)} ausencias.")
        formato = f"Planilla de obra SEI (hoja «{hoja_mes.title}»)"
        columnas, notas = [], []
    else:
        hoja_res = next((ws for ws in src.worksheets if clave(ws.title) == HOJA_RESUMEN), src.worksheets[0])
        filas, notas, periodo_txt, _, columnas = leer_resumen(hoja_res)
        formato = f"Formato antiguo (hoja «{hoja_res.title}» + hojas diarias)"
        for f in filas:
            f["detalle"], f["hojas"] = [], []
        asignadas = collections.Counter()
        vacias = []
        sin_unir = []
        for ws in src.worksheets:
            if ws.sheet_state != "visible" or ws is hoja_res:
                continue
            det, err = leer_detalle(ws, palabras)
            if err and err.startswith("sin nombre"):
                vacias.append(ws.title)
                continue
            if err:
                aviso("alerta", f"Hoja «{ws.title}»: no se pudo leer ({err}).")
                continue
            idx, err = unir_hoja_con_fila(det["trabajador"], filas)
            regs = det["registros"]
            fechas = [reg["fecha"] for reg in regs]
            if idx is None:
                aviso("alerta", f"Hoja «{ws.title}» ({nombre_propio(det['trabajador'])}): no se pudo unir a ningún "
                                f"trabajador del resumen ({err}). No se usa.")
                sin_unir.append(ws.title)
                continue
            asignadas[idx] += 1
            f = filas[idx]
            f["detalle"].extend(regs)
            f["hojas"].append(ws.title)
            quien = nombre_propio(f"{f['nombre']} {f['apellido']}")
            aviso("info", f"Hoja «{ws.title}» → {quien}: {len(regs)} días ({min(fechas):%d-%m-%Y} a {max(fechas):%d-%m-%Y}), "
                          f"{det['formato']}, horas extra de {det['fuente_he']}, {sum(r['ausencia'] for r in regs)} ausencias.")
            for fecha, monto in det["montos"]:
                aviso("alerta", f"Hoja «{ws.title}» ({quien}): el {fecha:%d-%m-%Y} hay anotado {monto:,.0f}".replace(",", ".")
                      + " en el detalle diario. Parece un monto, no horas: no se suma a las horas extra.")
        if vacias:
            aviso("info", f"Hojas diarias vacías (plantillas sin usar): {', '.join(vacias)}.")
        for i, f in enumerate(filas):
            quien = nombre_propio(f"{f['nombre']} {f['apellido']}")
            if asignadas[i] == 0:
                aviso("info", f"Sin hoja de detalle para {quien}.")
            elif asignadas[i] > 1:
                aviso("alerta", f"{asignadas[i]} hojas de detalle unidas a {quien}.")

    for f in filas:
        rut = normalizar_rut(f["rut"])
        quien = nombre_propio(f"{f['nombre']} {f['apellido']}")
        if rut and not rut_valido(rut):
            aviso("alerta", f"RUT inválido (dígito verificador): {formatear_rut(rut)} de {quien}.")
        if not rut:
            aviso("alerta", f"{quien} viene sin RUT: se busca por nombre en Trabajadores.")
    if notas:
        aviso("info", "Notas escritas fuera de la tabla: " + " | ".join(notas))

    return {"obra": obra, "periodo_txt": "" if periodo_txt is None else str(periodo_txt), "formato": formato,
            "columnas": columnas, "notas": notas, "filas": filas, "avisos": avisos}
