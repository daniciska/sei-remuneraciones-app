"""Base de datos local (SQLite): configuración, trabajadores, casos especiales, lo cargado del mes y el historial."""
import datetime as dt
import json
import os
import sqlite3

ESQUEMA = """
CREATE TABLE IF NOT EXISTS config (clave TEXT PRIMARY KEY, valor TEXT);
CREATE TABLE IF NOT EXISTS tarifas (obra TEXT PRIMARY KEY, sabado REAL, domingo REAL, orden INTEGER);
CREATE TABLE IF NOT EXISTS tipos (tipo TEXT PRIMARY KEY, clase TEXT NOT NULL, monto REAL, orden INTEGER);
CREATE TABLE IF NOT EXISTS ausencias (palabra TEXT PRIMARY KEY);
CREATE TABLE IF NOT EXISTS feriados (fecha TEXT PRIMARY KEY, nombre TEXT);
CREATE TABLE IF NOT EXISTS trabajadores (
    id INTEGER PRIMARY KEY, nombres TEXT, apellidos TEXT, rut TEXT, corto TEXT, activo TEXT DEFAULT 'Sí');
CREATE TABLE IF NOT EXISTS casos (
    id INTEGER PRIMARY KEY, rut TEXT, obra TEXT, tipo TEXT, sabado REAL, domingo REAL, bono REAL,
    desde TEXT, hasta TEXT, comentario TEXT);
CREATE TABLE IF NOT EXISTS archivos (
    id INTEGER PRIMARY KEY, periodo INTEGER, nombre TEXT, obra TEXT, ruta TEXT, cargado_el TEXT,
    formato TEXT, periodo_txt TEXT, columnas TEXT, avisos TEXT);
CREATE TABLE IF NOT EXISTS filas (
    id INTEGER PRIMARY KEY, archivo_id INTEGER REFERENCES archivos(id) ON DELETE CASCADE, orden INTEGER,
    rut TEXT, nombre TEXT, apellido TEXT, lugar TEXT, dias REAL, he REAL, sab REAL, dom REAL,
    monto_fds REAL, bonos REAL, obs TEXT, fila_archivo INTEGER, hojas TEXT, rut_corregido TEXT);
CREATE TABLE IF NOT EXISTS dias (
    id INTEGER PRIMARY KEY, fila_id INTEGER REFERENCES filas(id) ON DELETE CASCADE, fecha TEXT, nombre TEXT,
    entrada TEXT, salida TEXT, he REAL, asistio INTEGER, ausencia INTEGER, obs TEXT);
CREATE TABLE IF NOT EXISTS decisiones (
    fila_id INTEGER PRIMARY KEY REFERENCES filas(id) ON DELETE CASCADE, usar TEXT, dias REAL, he REAL, monto REAL);
CREATE TABLE IF NOT EXISTS historial (
    rut TEXT, fecha TEXT, obra TEXT, archivo TEXT, periodo INTEGER, trabajo INTEGER, ausencia INTEGER, he REAL);
CREATE INDEX IF NOT EXISTS ix_hist ON historial (rut, fecha);
CREATE TABLE IF NOT EXISTS obra_alias (origen TEXT PRIMARY KEY, obra TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS viaticos (
    id INTEGER PRIMARY KEY, periodo INTEGER, obra TEXT, rut TEXT, trabajador TEXT, monto REAL, desde TEXT, hasta TEXT,
    comentario TEXT, archivo TEXT, cargado_el TEXT);
CREATE TABLE IF NOT EXISTS horas_manuales (
    id INTEGER PRIMARY KEY, periodo INTEGER, rut TEXT, trabajador TEXT, horas REAL, comentario TEXT, cargado_el TEXT);
CREATE TABLE IF NOT EXISTS no_informados (
    periodo INTEGER, rut TEXT, dias REAL, visto INTEGER, PRIMARY KEY (periodo, rut));
CREATE TABLE IF NOT EXISTS reliquidaciones (
    id INTEGER PRIMARY KEY, periodo_original INTEGER, periodo_registro INTEGER, detectado_el TEXT, origen TEXT,
    rut TEXT, trabajador TEXT, obra TEXT, fecha TEXT, campo TEXT, antes TEXT, ahora TEXT);
CREATE TABLE IF NOT EXISTS meses_cerrados (
    periodo INTEGER PRIMARY KEY, desde TEXT, hasta TEXT, cerrado_el TEXT, archivos TEXT,
    trabajadores INTEGER, horas_extra REAL, desgaste REAL, foto TEXT, talana BLOB);
"""
# Columnas agregadas después de crear las primeras bases (se agregan si faltan).
MIGRACIONES = [("filas", "rut_corregido", "TEXT"), ("meses_cerrados", "foto", "TEXT"), ("meses_cerrados", "talana", "BLOB"),
               ("archivos", "obra_leida", "TEXT"), ("historial", "obs", "TEXT"), ("dias", "fds_fiable", "INTEGER"),
               ("historial", "fds_fiable", "INTEGER"), ("filas", "marcas", "TEXT"), ("filas", "finiquito", "TEXT"),
               # Datos de contrato que vienen de la exportación de TALANA
               ("trabajadores", "obra", "TEXT"), ("trabajadores", "sucursal", "TEXT"), ("trabajadores", "ingreso", "TEXT"),
               ("trabajadores", "contrato_hasta", "TEXT"), ("trabajadores", "tipo_contrato", "TEXT"),
               ("trabajadores", "egreso", "TEXT"), ("trabajadores", "talana_el", "TEXT"),
               ("filas", "ingreso", "TEXT"), ("filas", "termino", "TEXT"),   # de la planilla de obra
               ("viaticos", "pagado", "INTEGER"),
               # Bono a mano de un trabajador no informado por su obra (30-10-2026): tipo y monto (sin tipo = horas extra)
               ("horas_manuales", "tipo", "TEXT"), ("horas_manuales", "monto", "REAL")]   # 1 = ya pagado (anticipo): también va a «Descuento anticipo viático»


def carpeta_datos():
    """Carpeta de datos: SEI_DATOS si está definida; si no, 'datos' junto a la app."""
    base = os.environ.get("SEI_DATOS") or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "datos")
    os.makedirs(base, exist_ok=True)
    return base


def conectar(ruta=None):
    con = sqlite3.connect(ruta or os.path.join(carpeta_datos(), "sei.db"), check_same_thread=False)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys = ON")
    con.executescript(ESQUEMA)
    for tabla, col, tipo in MIGRACIONES:
        if col not in {r["name"] for r in con.execute(f"PRAGMA table_info({tabla})")}:
            con.execute(f"ALTER TABLE {tabla} ADD COLUMN {col} {tipo}")
    return con


def a_fecha(v):
    if v in (None, ""):
        return None
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    return dt.date.fromisoformat(str(v)[:10])


def iso(v):
    if v is None:
        return None
    if isinstance(v, (dt.date, dt.datetime, dt.time)):
        return v.isoformat()
    return str(v)


# ------------------------------------------------------------------ configuración
def config(con):
    c = {r["clave"]: r["valor"] for r in con.execute("SELECT clave, valor FROM config")}
    return {"periodo": int(c.get("periodo") or 0), "desde": a_fecha(c.get("desde")), "hasta": a_fecha(c.get("hasta")),
            "dias_base": int(float(c.get("dias_base") or 30)),
            # Regla desde oct-26 (confirmada): mes calendario y solo se suman los días del período que no estén ya
            # pagados. Sin la marca (meses de jun–sep) se usa la regla del Excel: todo el detalle cuenta.
            "solo_periodo": c.get("solo_periodo") in ("1", "True", "true", "Sí"),
            # Desde qué período se comparan los días ya pagados (AAAAMM). Vacío = siempre. En la base real es 202611:
            # en oct-26 (transición) no se avisan (pedido del usuario el 28-10-2026).
            "comparar_pagados_desde": int(c["comparar_pagados_desde"]) if c.get("comparar_pagados_desde") else None}


def guardar_config(con, **valores):
    for k, v in valores.items():
        con.execute("INSERT OR REPLACE INTO config VALUES (?, ?)", (k, iso(v)))
    con.commit()


def tarifas(con):
    return [dict(r) for r in con.execute("SELECT obra, sabado, domingo FROM tarifas ORDER BY orden, obra")]


def tipos(con):
    return [dict(r) for r in con.execute("SELECT tipo, clase, monto FROM tipos ORDER BY orden, tipo")]


def ausencias(con):
    return [r["palabra"] for r in con.execute("SELECT palabra FROM ausencias ORDER BY rowid")]


def feriados(con):
    return [{"fecha": a_fecha(r["fecha"]), "nombre": r["nombre"]} for r in con.execute("SELECT * FROM feriados ORDER BY fecha")]


def trabajadores(con):
    return [dict(r) for r in con.execute("SELECT * FROM trabajadores ORDER BY id")]


def casos(con):
    out = []
    for r in con.execute("SELECT * FROM casos ORDER BY id"):
        d = dict(r)
        d["desde"], d["hasta"] = a_fecha(d["desde"]), a_fecha(d["hasta"])
        out.append(d)
    return out


def crear_obra(con, obra, sabado=None, domingo=None):
    orden = con.execute("SELECT COALESCE(MAX(orden), 0) + 1 FROM tarifas").fetchone()[0]
    con.execute("INSERT INTO tarifas (obra, sabado, domingo, orden) VALUES (?,?,?,?)", (obra, sabado, domingo, orden))
    con.commit()


def guardar_tarifa_obra(con, obra, sabado, domingo):
    con.execute("UPDATE tarifas SET sabado = ?, domingo = ? WHERE obra = ?", (sabado, domingo, obra))
    con.commit()


def agregar_trabajador(con, nombres, apellidos, rut, corto=None):
    cur = con.execute("INSERT INTO trabajadores (nombres, apellidos, rut, corto, activo) VALUES (?,?,?,?, 'Sí')",
                      (nombres, apellidos, rut, corto))
    con.commit()
    return cur.lastrowid


def guardar_caso(con, caso):
    """Crea (sin id) o actualiza un caso especial. Devuelve el id."""
    campos = ("rut", "obra", "tipo", "sabado", "domingo", "bono", "desde", "hasta", "comentario")
    vals = [iso(caso.get(k)) if k in ("desde", "hasta") else caso.get(k) for k in campos]
    if caso.get("id"):
        cur = con.execute(f"UPDATE casos SET {', '.join(k + ' = ?' for k in campos)} WHERE id = ?", vals + [caso["id"]])
        if not cur.rowcount:
            raise ValueError("Ese caso ya no existe.")
        con.commit()
        return caso["id"]
    cur = con.execute(f"INSERT INTO casos ({', '.join(campos)}) VALUES ({', '.join('?' * len(campos))})", vals)
    con.commit()
    return cur.lastrowid


def borrar_caso(con, caso_id):
    con.execute("DELETE FROM casos WHERE id = ?", (caso_id,))
    con.commit()


def guardar_tipo(con, tipo, clase, monto):
    orden = con.execute("SELECT COALESCE(MAX(orden), -1) + 1 FROM tipos").fetchone()[0]
    con.execute("INSERT INTO tipos (tipo, clase, monto, orden) VALUES (?,?,?,?) "
                "ON CONFLICT(tipo) DO UPDATE SET clase = excluded.clase, monto = excluded.monto", (tipo, clase, monto, orden))
    con.commit()


def historial_valores(con):
    """{(rut, fecha): lo pagado ese día} para comparar con lo que informan las obras.

    Si el mismo trabajador tiene más de una fila ese día en el mismo mes (ej. dos filas en la misma obra), se juntan:
    horas extra sumadas, ausencia y trabajo si alguna lo tiene. Si el día quedó registrado en dos meses (el Excel
    volvía a guardar los días DUPLICADO), vale lo del último mes.
    """
    out = {}
    for r in con.execute("SELECT * FROM historial ORDER BY rowid"):
        k = (r["rut"], r["fecha"])
        if k not in out or (r["periodo"] or 0) > (out[k]["periodo"] or 0):
            out[k] = dict(r)
            continue
        if (r["periodo"] or 0) < (out[k]["periodo"] or 0):
            continue
        a = out[k]
        a["he"] = (a["he"] or 0) + (r["he"] or 0)
        a["ausencia"] = max(a["ausencia"] or 0, r["ausencia"] or 0)
        a["trabajo"] = max(a["trabajo"] or 0, r["trabajo"] or 0)
        a["obs"] = "; ".join(x for x in (a["obs"], r["obs"]) if x) if (a["obs"] is not None or r["obs"] is not None) else None
    return out


def guardar_reliquidaciones(con, filas, origen, periodo_registro, reemplazar=None):
    """Guarda cambios detectados. `reemplazar` = (periodo_original, origen): borra antes lo registrado con ese origen."""
    if reemplazar:
        con.execute("DELETE FROM reliquidaciones WHERE periodo_original = ? AND origen = ?", reemplazar)
    ahora = dt.datetime.now().isoformat(timespec="seconds")
    con.executemany(
        "INSERT INTO reliquidaciones (periodo_original, periodo_registro, detectado_el, origen, rut, trabajador, obra, "
        "fecha, campo, antes, ahora) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        [(c["periodo_original"], periodo_registro, ahora, origen, c["rut"], c["trabajador"], c["obra"], c.get("fecha"),
          c["campo"], str(c["antes"]), str(c["ahora"])) for c in filas])
    con.commit()


def viaticos(con, periodo):
    return [dict(r) for r in con.execute("SELECT * FROM viaticos WHERE periodo = ? ORDER BY id", (periodo,))]


def reemplazar_viaticos(con, periodo, filas, archivo):
    """La planilla de viáticos es una por mes (todas las obras): al subirla de nuevo reemplaza todo lo del mes."""
    borrar_viaticos(con, periodo, commit=False)
    ahora = dt.datetime.now().isoformat(timespec="seconds")
    con.executemany("INSERT INTO viaticos (periodo, obra, rut, trabajador, monto, pagado, comentario, archivo, cargado_el) "
                    "VALUES (?,?,?,?,?,?,?,?,?)",
                    [(periodo, f.get("obra"), f["rut"], f["trabajador"], f["monto"], 1 if f.get("pagado") else 0,
                      f.get("comentario"), archivo, ahora) for f in filas])
    con.commit()


def borrar_viaticos(con, periodo, commit=True):
    con.execute("DELETE FROM viaticos WHERE periodo = ?", (periodo,))
    if commit:
        con.commit()


def horas_manuales(con, periodo):
    return [dict(r) for r in con.execute("SELECT * FROM horas_manuales WHERE periodo = ? ORDER BY id", (periodo,))]


def agregar_horas_manuales(con, periodo, rut, trabajador, horas, comentario, tipo=None, monto=None):
    con.execute("INSERT INTO horas_manuales (periodo, rut, trabajador, horas, comentario, tipo, monto, cargado_el) "
                "VALUES (?,?,?,?,?,?,?,?)", (periodo, rut, trabajador, horas, comentario, tipo, monto,
                                             dt.datetime.now().isoformat(timespec="seconds")))
    con.commit()


def no_informados(con, periodo):
    return {r["rut"]: dict(r) for r in con.execute("SELECT * FROM no_informados WHERE periodo = ?", (periodo,))}


def guardar_no_informado(con, periodo, rut, **cambios):
    """`dias` (None = el de por defecto) y/o `visto` (1/0) de un trabajador no informado por su obra."""
    actual = no_informados(con, periodo).get(rut) or {"dias": None, "visto": 0}
    actual.update(cambios)
    con.execute("INSERT OR REPLACE INTO no_informados (periodo, rut, dias, visto) VALUES (?,?,?,?)",
                (periodo, rut, actual["dias"], actual["visto"]))
    con.commit()


def borrar_horas_manuales(con, periodo, hid):
    con.execute("DELETE FROM horas_manuales WHERE id = ? AND periodo = ?", (hid, periodo))
    con.commit()


def reliquidaciones(con):
    return [dict(r) for r in con.execute("SELECT * FROM reliquidaciones ORDER BY periodo_original DESC, trabajador, fecha, id")]


def historial_claves(con):
    return {(r["rut"], r["fecha"]) for r in con.execute("SELECT DISTINCT rut, fecha FROM historial")}


# ------------------------------------------------------------------ lo cargado del mes
def obra_alias(con):
    """{clave de la obra como viene en el archivo: obra configurada}."""
    return {r["origen"]: r["obra"] for r in con.execute("SELECT origen, obra FROM obra_alias")}


def guardar_alias(con, origen, obra):
    con.execute("INSERT OR REPLACE INTO obra_alias VALUES (?, ?)", (origen, obra))
    con.commit()


def guardar_archivo(con, periodo, nombre, ruta, leido):
    """Guarda lo extraído de un archivo de obra. Devuelve el id del archivo."""
    cur = con.execute(
        "INSERT INTO archivos (periodo, nombre, obra, obra_leida, ruta, cargado_el, formato, periodo_txt, columnas, avisos) "
        "VALUES (?,?,?,?,?,?,?,?,?,?)",
        (periodo, nombre, leido["obra"], leido.get("obra_leida") or leido["obra"], ruta,
         dt.datetime.now().isoformat(timespec="seconds"), leido["formato"],
         leido["periodo_txt"], json.dumps(leido["columnas"], ensure_ascii=False),
         json.dumps(leido["avisos"], ensure_ascii=False)))
    archivo_id = cur.lastrowid
    for i, f in enumerate(leido["filas"]):
        cur = con.execute(
            "INSERT INTO filas (archivo_id, orden, rut, nombre, apellido, lugar, dias, he, sab, dom, monto_fds, bonos, "
            "obs, fila_archivo, hojas, marcas, finiquito, ingreso, termino) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (archivo_id, i, f["rut"], f["nombre"], f["apellido"], f["lugar"], f["dias"], f["he"], f["sab"], f["dom"],
             f["monto_fds"], f["bonos"], f["obs"], f.get("fila_archivo"), json.dumps(f.get("hojas") or [], ensure_ascii=False),
             json.dumps(f["marcas"]) if f.get("marcas") is not None else None, iso(f.get("finiquito")),
             iso(f.get("ingreso")), iso(f.get("termino"))))
        fila_id = cur.lastrowid
        con.executemany(
            "INSERT INTO dias (fila_id, fecha, nombre, entrada, salida, he, asistio, ausencia, obs, fds_fiable) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            [(fila_id, iso(g["fecha"]), g["nombre"], iso(g["entrada"]), iso(g["salida"]), g["he"], g["asistio"],
              g["ausencia"], g["obs"], g.get("fds_fiable", 0)) for g in f.get("detalle") or []])
    con.commit()
    return archivo_id


def archivos(con, periodo):
    out = []
    for r in con.execute("SELECT * FROM archivos WHERE periodo = ? ORDER BY id", (periodo,)):
        d = dict(r)
        d["columnas"] = json.loads(d["columnas"] or "[]")
        d["avisos"] = json.loads(d["avisos"] or "[]")
        out.append(d)
    return out


def borrar_archivo(con, archivo_id):
    r = con.execute("SELECT periodo FROM archivos WHERE id = ?", (archivo_id,)).fetchone()
    if r and r["periodo"] != config(con)["periodo"]:
        raise ValueError("Ese archivo es de un mes cerrado: solo se puede consultar.")
    con.execute("DELETE FROM archivos WHERE id = ?", (archivo_id,))
    con.commit()


def filas(con, periodo):
    """Filas del resumen de las obras del período, en el orden de carga, con su detalle diario."""
    out = []
    q = ("SELECT f.*, a.nombre AS archivo, a.obra FROM filas f JOIN archivos a ON a.id = f.archivo_id "
         "WHERE a.periodo = ? ORDER BY a.id, f.orden")
    for r in con.execute(q, (periodo,)):
        d = dict(r)
        d["hojas"] = json.loads(d["hojas"] or "[]")
        d["marcas"] = json.loads(d["marcas"]) if d.get("marcas") else None
        d["detalle"] = [dict(g) for g in con.execute("SELECT * FROM dias WHERE fila_id = ? ORDER BY fecha, id", (d["id"],))]
        out.append(d)
    return out


def exigir_mes_en_curso(con, fila_id):
    """Las filas de meses cerrados no se tocan: el mes cerrado es solo consulta."""
    r = con.execute("SELECT a.periodo FROM filas f JOIN archivos a ON a.id = f.archivo_id WHERE f.id = ?", (fila_id,)).fetchone()
    if r is None or r["periodo"] != config(con)["periodo"]:
        raise ValueError("Esa fila es de un mes cerrado: solo se puede consultar.")


def corregir_rut(con, fila_id, rut):
    """RRHH indica qué trabajador es realmente la fila (RUT mal escrito o faltante). Vacío = vuelve a lo informado."""
    exigir_mes_en_curso(con, fila_id)
    con.execute("UPDATE filas SET rut_corregido = ? WHERE id = ?", (rut or None, fila_id))
    con.commit()


def meses_cerrados(con):
    """Meses cerrados, sin la foto (liviano), del más nuevo al más antiguo."""
    return [dict(r) for r in con.execute(
        "SELECT periodo, desde, hasta, cerrado_el, archivos, trabajadores, horas_extra, desgaste, "
        "foto IS NOT NULL AS con_foto FROM meses_cerrados ORDER BY periodo DESC")]


def mes_cerrado(con, periodo):
    r = con.execute("SELECT * FROM meses_cerrados WHERE periodo = ?", (periodo,)).fetchone()
    return dict(r) if r else None


def decisiones(con):
    return {r["fila_id"]: dict(r) for r in con.execute("SELECT * FROM decisiones")}


def guardar_decision(con, fila_id, usar=None, dias=None, he=None, monto=None):
    exigir_mes_en_curso(con, fila_id)
    if not (usar or dias is not None or he is not None or monto is not None):
        con.execute("DELETE FROM decisiones WHERE fila_id = ?", (fila_id,))
    else:
        con.execute("INSERT OR REPLACE INTO decisiones VALUES (?,?,?,?,?)", (fila_id, usar or None, dias, he, monto))
    con.commit()
