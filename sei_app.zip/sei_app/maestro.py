"""Obras y trabajadores: crear obras y subir la exportación de trabajadores de TALANA («Lista Empleados»).

De la exportación de TALANA SOLO se leen: RUT, nombre, apellidos, sucursal, fecha de ingreso, contrato hasta,
tipo de contrato, motivo de egreso y vigente. El archivo trae datos sensibles (sueldos, bancos, AFP, direcciones)
que no se leen ni se guardan; el archivo tampoco se guarda en disco.
"""
import datetime as dt
import io

from openpyxl import load_workbook

from . import db
from .comun import clave, formatear_rut, nombre_propio, normalizar_rut

NO_ES_OBRA = "__no_es_obra__"   # sucursal que no es obra (oficina): sus trabajadores no van a las planillas de obra

COLUMNAS = {   # clave del encabezado de TALANA → campo
    "rut": "rut", "nombre": "nombre", "apellido paterno": "paterno", "apellido materno": "materno",
    "sucursal": "sucursal", "fecha de ingreso": "ingreso", "contrato hasta": "hasta", "tipo de contrato": "tipo",
    "motivo de egreso": "egreso", "vigente": "vigente",
}


# ------------------------------------------------------------------ obras
def obras(con):
    """Obras configuradas (tabla de tarifas, sin ESTÁNDAR) con sus sucursales de TALANA y trabajadores activos."""
    trab = db.trabajadores(con)
    out = []
    for t in db.tarifas(con):
        if t["obra"] == "ESTÁNDAR":
            continue
        out.append({**t, "sucursales": sorted({x["sucursal"] for x in trab if x.get("obra") == t["obra"] and x.get("sucursal")}),
                    "trabajadores": sum(1 for x in trab if x.get("obra") == t["obra"] and x.get("activo") != "No")})
    return out


def crear_obra(con, d):
    obra = " ".join((d.get("obra") or "").split())
    if not obra:
        raise ValueError("Escribe el nombre de la obra.")
    if obra.upper() == "ESTÁNDAR" or any(clave(t["obra"]) == clave(obra) for t in db.tarifas(con)):
        raise ValueError(f"Ya existe una obra «{obra}».")
    sab, dom = d.get("sabado"), d.get("domingo")
    for v in (sab, dom):
        if v is not None and v < 0:
            raise ValueError("Las tarifas no pueden ser negativas.")
    db.crear_obra(con, obra, sab, dom)
    if d.get("sucursal"):
        db.guardar_alias(con, clave(d["sucursal"]), obra)
    return obra


def tarifa_obra(con, d):
    obra = d.get("obra")
    if obra not in [t["obra"] for t in db.tarifas(con)]:
        raise ValueError("Esa obra no existe.")
    db.guardar_tarifa_obra(con, obra, d.get("sabado"), d.get("domingo"))
    return obra


# ------------------------------------------------------------------ exportación de TALANA
def _fecha(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    s = str(v or "").strip()
    for formato in ("%d-%m-%Y", "%d/%m/%Y", "%Y-%m-%d"):
        try:
            return dt.datetime.strptime(s[:10], formato).date()
        except ValueError:
            continue
    return None


def leer_talana(contenido):
    """Personas de la exportación «Lista Empleados» de TALANA (solo los campos necesarios)."""
    try:
        wb = load_workbook(io.BytesIO(contenido), read_only=True, data_only=True)
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"No se pudo abrir el archivo: {e}") from e
    for ws in wb.worksheets:
        filas = ws.iter_rows(values_only=True)
        for i, fila in enumerate(filas):
            enc = {clave(v): j for j, v in enumerate(fila or []) if v}
            if "rut" in enc and "sucursal" in enc and "nombre" in enc:
                break
            if i > 10:
                enc = None
                break
        else:
            enc = None
        if not enc:
            continue
        col = {campo: enc[k] for k, campo in COLUMNAS.items() if k in enc}
        personas = []
        for fila in filas:
            g = lambda c: fila[col[c]] if c in col and col[c] < len(fila) else None  # noqa: E731
            rut = normalizar_rut(g("rut"))
            if not rut:
                continue
            personas.append({
                "rut": formatear_rut(rut),
                "nombres": nombre_propio(g("nombre")),
                "apellidos": nombre_propio(" ".join(str(x).strip() for x in (g("paterno"), g("materno")) if x)),
                "sucursal": " ".join(str(g("sucursal") or "").split()),
                "ingreso": _fecha(g("ingreso")),
                "hasta": _fecha(g("hasta")),
                "tipo": str(g("tipo") or "").strip(),
                "egreso": str(g("egreso") or "").strip(),
                "vigente": clave(g("vigente")) in ("si", "sí", "true", "1", ""),
            })
        if personas:
            return personas
    raise ValueError("No parece la exportación de trabajadores de TALANA: no se encontraron las columnas RUT, "
                     "Nombre y Sucursal.")


def obra_de_sucursal(con, sucursal):
    """Obra configurada para una sucursal de TALANA: elegida antes (se recuerda) o con el mismo nombre."""
    k = clave(sucursal)
    alias = db.obra_alias(con)
    if k in alias:
        return alias[k]
    for t in db.tarifas(con):
        if t["obra"] != "ESTÁNDAR" and clave(t["obra"]) == k:
            return t["obra"]
    return None


PALABRAS_VACIAS = {"sei", "de", "del", "la", "el", "los", "las", "obra", "proyecto", "centro", "comercial", "cc", "mall",
                   "plaza", "mp", "y"}


def obra_parecida(con, sucursal):
    """Obra configurada que comparte palabras con la sucursal (ej. «Bodegas DOITE» ~ «Bodega DOITE»). Solo sugiere."""
    def palabras(t):
        return {p.rstrip("s") for p in clave(t).replace("-", " ").split() if p not in PALABRAS_VACIAS and len(p) >= 3}
    ps = palabras(sucursal)
    puntajes = sorted(((len(ps & palabras(t["obra"])), t["obra"]) for t in db.tarifas(con) if t["obra"] != "ESTÁNDAR"),
                      reverse=True)
    if puntajes and puntajes[0][0] > 0 and (len(puntajes) == 1 or puntajes[0][0] > puntajes[1][0]):
        return puntajes[0][1]
    return None


def vista_previa(con, contenido):
    """Lo que haría la importación, sin guardar nada: sucursales con su obra, trabajadores nuevos y actualizados."""
    personas = leer_talana(contenido)
    actuales = {normalizar_rut(t["rut"]): t for t in db.trabajadores(con) if t["rut"]}
    sucursales = {}
    for p in personas:
        s = sucursales.setdefault(p["sucursal"], {"sucursal": p["sucursal"], "personas": 0, "nuevos": 0,
                                                 "obra": obra_de_sucursal(con, p["sucursal"])})
        s["personas"] += 1
        s["nuevos"] += normalizar_rut(p["rut"]) not in actuales
    en_archivo = {normalizar_rut(p["rut"]) for p in personas}
    no_estan = [t for r, t in actuales.items() if r not in en_archivo and t.get("activo") != "No"]
    for s in sucursales.values():
        s["sugerencia"] = "no_es_obra" if "oficina" in clave(s["sucursal"]) else None
        s["parecida"] = None if s["obra"] else obra_parecida(con, s["sucursal"])
    return {
        "personas": len(personas),
        "nuevos": sum(1 for p in personas if normalizar_rut(p["rut"]) not in actuales),
        "actualizados": sum(1 for p in personas if normalizar_rut(p["rut"]) in actuales),
        "sucursales": sorted(sucursales.values(), key=lambda s: -s["personas"]),
        "no_estan": [{"rut": t["rut"], "nombre": f"{t['nombres']} {t['apellidos']}", "obra": t.get("obra")} for t in no_estan],
    }


def importar(con, contenido, mapeo):
    """Guarda los trabajadores de TALANA. `mapeo` = {sucursal: obra | NO_ES_OBRA | {"nueva": nombre}}.

    - Por RUT: si existe se actualizan nombres, apellidos y contrato (el «nombre corto» se conserva); si no, se crea.
    - Activo = No si TALANA dice que no está vigente o tiene motivo de egreso.
    - Los que están en la app y no vienen en el archivo NO se tocan (se muestran en la vista previa).
    - La sucursal → obra queda recordada para la próxima vez.
    """
    personas = leer_talana(contenido)
    faltan = sorted({p["sucursal"] for p in personas} - set(mapeo))
    if faltan:
        raise ValueError("Falta elegir la obra de: " + ", ".join(faltan))
    obras_ok = {t["obra"] for t in db.tarifas(con)}
    destino = {}
    for suc, elegida in mapeo.items():
        if isinstance(elegida, dict) and elegida.get("nueva"):
            nombre = " ".join(elegida["nueva"].split())
            if nombre not in obras_ok:
                crear_obra(con, {"obra": nombre})
                obras_ok.add(nombre)
            elegida = nombre
        if elegida != NO_ES_OBRA and elegida not in obras_ok:
            raise ValueError(f"La obra «{elegida}» no existe.")
        db.guardar_alias(con, clave(suc), elegida)
        destino[suc] = None if elegida == NO_ES_OBRA else elegida
    actuales = {normalizar_rut(t["rut"]): t for t in db.trabajadores(con) if t["rut"]}
    ahora = dt.datetime.now().isoformat(timespec="seconds")
    nuevos = actualizados = 0
    for p in personas:
        activo = "Sí" if p["vigente"] and not p["egreso"] else "No"
        vals = (p["nombres"], p["apellidos"], destino[p["sucursal"]], p["sucursal"], db.iso(p["ingreso"]),
                db.iso(p["hasta"]), p["tipo"], p["egreso"] or None, activo, ahora)
        t = actuales.get(normalizar_rut(p["rut"]))
        if t:
            con.execute("UPDATE trabajadores SET nombres = ?, apellidos = ?, obra = ?, sucursal = ?, ingreso = ?, "
                        "contrato_hasta = ?, tipo_contrato = ?, egreso = ?, activo = ?, talana_el = ? WHERE id = ?",
                        vals + (t["id"],))
            actualizados += 1
        else:
            con.execute("INSERT INTO trabajadores (nombres, apellidos, obra, sucursal, ingreso, contrato_hasta, "
                        "tipo_contrato, egreso, activo, talana_el, rut) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        vals + (p["rut"],))
            nuevos += 1
    con.commit()
    return {"nuevos": nuevos, "actualizados": actualizados}


def plazo_y_termino(t):
    """Contrato para la planilla de obra (misma regla de la entrega del 05-10-2026): Indefinido → «Indefinido»;
    Plazo Fijo → «Plazo fijo» + término = contrato hasta; con motivo de egreso → «Finalizado»."""
    hasta = t.get("contrato_hasta")
    if t.get("egreso"):
        return "Finalizado", hasta
    if clave(t.get("tipo_contrato")) == "indefinido":
        return "Indefinido", None
    if clave(t.get("tipo_contrato")).startswith("plazo"):
        return "Plazo fijo", hasta
    return None, hasta
