"""Operaciones de la app sobre la base: estado del mes, cargar archivos de obra y cerrar el mes."""
import calendar
import datetime as dt
import json
import os
import re

from . import db, lector, maestro, motor, talana
from .comun import clave, formatear_rut, nombre_mes, nombre_propio, normalizar_rut, obra_desde_archivo, rut_valido


def estado(con):
    """Todo lo que muestran las pantallas para el mes en curso."""
    res = motor.calcular(con)
    cfg = db.config(con)
    trab = db.trabajadores(con)
    nombres = {normalizar_rut(t["rut"]): motor.se_muestra_como(t) for t in trab if t["rut"]}
    return {
        **res,
        "mes": nombre_mes(cfg["periodo"]) if cfg["periodo"] else "",
        "cerrado": None,
        "archivos": [{k: a[k] for k in ("id", "nombre", "obra", "cargado_el", "formato", "periodo_txt", "columnas", "avisos")}
                     | {"filas": sum(1 for f in res["filas"] if f["archivo"] == a["nombre"]),
                        "obra_leida": a.get("obra_leida") or a["obra"],
                        "obra_configurada": a["obra"] in obras_configuradas(con)}
                     for a in db.archivos(con, cfg["periodo"])],
        "maestro": {
            "tarifas": db.tarifas(con),
            "tipos": db.tipos(con),
            "casos": [x | {"trabajador": nombres.get(normalizar_rut(x["rut"]), "?")} for x in db.casos(con)],
            "trabajadores": [t | {"muestra": motor.se_muestra_como(t), "rut_ok": rut_valido(t["rut"]) if t["rut"] else None}
                             for t in trab],
            "feriados": db.feriados(con),
            "ausencias": db.ausencias(con),
            "obras": obras(con),
            "obras_configuradas": obras_configuradas(con),
            "obras_detalle": maestro.obras(con),
        },
        "archivo_talana": talana.nombre_archivo(cfg["periodo"]),
        "reliquidaciones": db.reliquidaciones(con),
        "cuadratura": cuadratura(con, res["filas"]),
        "meses_cerrados_todos": [{"periodo": m["periodo"], "mes": nombre_mes(m["periodo"]), "desde": m["desde"], "hasta": m["hasta"]}
                                 for m in db.meses_cerrados(con)],
    }


def cuadratura(con, filas):
    """Trabajadores por obra: los que declara la planilla de la obra (mes en curso) frente a los de TALANA.

    TALANA = trabajadores activos con esa obra (sucursal de la exportación). Devuelve una fila por obra con los que
    están en ambas, los que solo vienen en la planilla (y dónde los tiene TALANA) y los que solo están en TALANA.
    """
    trab = db.trabajadores(con)
    if not any(t.get("talana_el") for t in trab):
        return {"talana": False, "obras": []}
    por_rut = {normalizar_rut(t["rut"]): t for t in trab if t.get("rut")}
    talana = {}
    for t in trab:
        if t.get("obra") and t.get("activo") != "No" and t.get("rut"):
            talana.setdefault(t["obra"], {})[normalizar_rut(t["rut"])] = t
    archivo = {}
    for f in filas:
        archivo.setdefault(f["obra"], {})[f["rut"] if f["rut"] != motor.SIN_RUT else f"sin-rut-{f['id']}"] = f
    out = []
    for obra in sorted(set(talana) | set(archivo), key=clave):
        a, t = archivo.get(obra, {}), talana.get(obra, {})
        solo_archivo = []
        for rut, f in a.items():
            if rut in t:
                continue
            otro = por_rut.get(rut)
            if not otro:
                donde = "no está en TALANA"
            elif otro.get("activo") == "No":
                donde = "en TALANA ya no está vigente" + (f" ({otro['egreso'].lower()})" if otro.get("egreso") else "")
            elif otro.get("obra"):
                donde = f"en TALANA está en {otro['obra']}"
            else:
                donde = f"en TALANA está en «{otro.get('sucursal') or 'sin sucursal'}» (no es obra)"
            solo_archivo.append({"trabajador": f["trabajador"], "rut": f["rut_txt"], "motivo": donde})
        solo_talana = [{"trabajador": motor.se_muestra_como(x), "rut": x["rut"],
                        "motivo": "no viene en la planilla de la obra" if a else "no llegó la planilla de esta obra"}
                       for rut, x in t.items() if rut not in a]
        out.append({"obra": obra, "en_archivo": len(a), "en_talana": len(t), "en_ambas": sum(1 for r in a if r in t),
                    "llego_archivo": bool(a), "configurada": obra in obras_configuradas(con),
                    "solo_archivo": solo_archivo, "solo_talana": solo_talana})
    return {"talana": True, "obras": out}


def planilla_obra(con, obra, desde, hasta):
    """Planilla de obra (formato nuevo) para descargar: los trabajadores activos de esa obra según TALANA,
    con su fecha de ingreso y contrato. Devuelve (nombre del archivo, bytes)."""
    import io
    from . import planilla_obra as po
    if obra not in obras_configuradas(con):
        raise ValueError("Elige una obra de la lista.")
    try:
        d = tuple(int(x) for x in desde.split("-"))
        h = tuple(int(x) for x in hasta.split("-"))
    except (AttributeError, ValueError):
        raise ValueError("Elige los meses (desde y hasta).") from None
    meses = po.meses_entre(d, h)
    if not meses or len(meses) > 12:
        raise ValueError("El rango de meses tiene que ser de 1 a 12 meses, con «desde» antes de «hasta».")
    # Marcas ya escritas en el Resumen de cada mes (pedido 28-10-2026): trato de fin de semana si tiene tarifa especial,
    # y bono noche / lejanía si tiene ese bono; casos vigentes en ese mes, en esta obra o en TODAS.
    tipos = {t["tipo"]: t for t in db.tipos(con)}
    casos = db.casos(con)

    def marcas_de(rut):
        por_mes = {}
        for anio, mes in meses:
            ini, fin = po.periodo(anio, mes)
            m = set()
            for c in casos:
                if normalizar_rut(c["rut"]) != normalizar_rut(rut) or (c["obra"] or "TODAS") not in ("TODAS", obra):
                    continue
                if (c["desde"] and c["desde"] > fin) or (c["hasta"] and c["hasta"] < ini):
                    continue
                clase, k = (tipos.get(c["tipo"]) or {}).get("clase"), clave(c["tipo"])
                if clase == "TARIFA":
                    m.add("trato")
                elif clase == "BONO" and "noche" in k:
                    m.add("noche")
                elif clase == "BONO" and "lejan" in k:
                    m.add("lejania")
            por_mes[f"{anio}-{mes:02d}"] = m
        return {"marcas": por_mes}

    trabajadores = []
    for t in db.trabajadores(con):
        if t.get("obra") != obra or t.get("activo") == "No" or not t.get("rut"):
            continue
        plazo, termino = maestro.plazo_y_termino(t)
        trabajadores.append({"nombre": nombre_propio(f"{t['nombres'] or ''} {t['apellidos'] or ''}"), "rut": t["rut"],
                             "ingreso": t.get("ingreso"), "plazo": plazo, "termino": termino, **marcas_de(t["rut"])})
    if len(trabajadores) > po.MAX_TRAB:
        raise ValueError(f"La obra tiene {len(trabajadores)} trabajadores y la planilla admite {po.MAX_TRAB}.")
    buf = io.BytesIO()
    po.construir(obra, meses, trabajadores).save(buf)
    nombre = po.nombre_archivo(obra, meses)
    if len(meses) == 1:   # «(nov-2026 a nov-2026)» -> «(nov-2026)»
        nombre = re.sub(r"\((\S+) a \1\)", r"(\1)", nombre)
    return nombre, buf.getvalue()


def agregar_horas_manuales(con, rut, horas, comentario, tipo=None, monto=None):
    """Horas extra (o un bono) a mano, en el mes en curso (pedidos y confirmados el 30-10-2026):
    - horas extra para quien NO es de obra (oficina): van solo a «Horas Extra Trabajadas»;
    - horas extra o un bono para un trabajador de obra que su obra no informó (motor.no_informados).
    """
    t = next((x for x in db.trabajadores(con) if x.get("rut") and normalizar_rut(x["rut"]) == normalizar_rut(rut or "")), None)
    no_inf = t and normalizar_rut(t["rut"]) in {x["rut"] for x in motor.calcular(con)["no_informados"]}
    oficina = t and not t.get("obra") and t.get("activo") != "No"
    if not (oficina or no_inf) or (tipo and not no_inf):
        raise ValueError("Elige un trabajador activo de oficina, o uno que su obra no informó este mes.")
    if tipo:
        bono = next((x for x in db.tipos(con) if x["tipo"] == tipo and x["clase"] == "BONO"), None)
        if not bono:
            raise ValueError("Elige el tipo de bono.")
        monto = monto if monto is not None else bono.get("monto")
        if not monto or monto <= 0:   # regla: no se guarda un bono de $0
            raise ValueError(f"Escribe el monto del {tipo.lower()}.")
        horas = None
    elif not horas or horas <= 0:
        raise ValueError("Escribe la cantidad de horas extra (mayor que 0).")
    else:
        monto = None
    periodo = db.config(con)["periodo"]
    db.agregar_horas_manuales(con, periodo, t["rut"], nombre_propio(f"{t['nombres'] or ''} {t['apellidos'] or ''}"),
                              horas, (comentario or "").strip() or None, tipo, monto)
    return {"ok": True}


def marcar_no_informado(con, rut, dias=None, visto=None, por_defecto=False):
    """Días a mano (o volver a los de por defecto) o «visto» de un trabajador no informado por su obra."""
    rut = normalizar_rut(rut or "")
    if rut not in {x["rut"] for x in motor.calcular(con)["no_informados"]}:
        raise ValueError("Ese trabajador ya no aparece como no informado.")
    periodo, cambios = db.config(con)["periodo"], {}
    if por_defecto:
        cambios["dias"] = None
    elif dias is not None:
        if dias < 0 or dias > 31:
            raise ValueError("Los días tienen que estar entre 0 y 30.")
        cambios["dias"] = dias
    if visto is not None:
        cambios["visto"] = 1 if visto else 0
    db.guardar_no_informado(con, periodo, rut, **cambios)
    return {"ok": True}


def talana_nueva(con):
    """Fecha de la exportación de TALANA subida después del último cierre de mes, o None si no hay
    (el Paquete del mes se arma solo con la lista de trabajadores al día; pedido 30-10-2026)."""
    ultima = max((t["talana_el"] for t in db.trabajadores(con) if t.get("talana_el")), default=None)
    cierre = max((m["cerrado_el"] or "" for m in db.meses_cerrados(con)), default="")
    return ultima if ultima and ultima > cierre else None


def paquete_mes(con, mes):
    """Paquete del mes (pedido 30-10-2026): un zip con la planilla de ese mes de cada obra que tiene trabajadores
    activos en TALANA. Las obras sin trabajadores se saltan. Devuelve (nombre del zip, bytes)."""
    import io
    import zipfile
    if not talana_nueva(con):
        raise ValueError("Primero sube la exportación de TALANA de este mes (pestaña «1 · Trabajadores»).")
    try:
        anio, m = (int(x) for x in mes.split("-"))
    except (AttributeError, ValueError):
        raise ValueError("Elige el mes.") from None
    con_trab = {t["obra"] for t in db.trabajadores(con) if t.get("activo") != "No" and t.get("rut")}
    obras_mes = [o for o in obras_configuradas(con) if o in con_trab]
    if not obras_mes:
        raise ValueError("Ninguna obra tiene trabajadores activos. Sube primero la exportación de TALANA.")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for obra in obras_mes:
            try:
                nombre, contenido = planilla_obra(con, obra, mes, mes)
            except ValueError as e:
                raise ValueError(f"{obra}: {e}") from None
            z.writestr(nombre, contenido)
    return f"Planillas obras ({nombre_mes(anio * 100 + m)}).zip", buf.getvalue()


def obras(con):
    """Obras para elegir en un caso especial: las de la tabla de tarifas y las cargadas este mes."""
    lista = [t["obra"] for t in db.tarifas(con) if t["obra"] != "ESTÁNDAR"]
    for a in db.archivos(con, db.config(con)["periodo"]):
        if a["obra"] not in lista:
            lista.append(a["obra"])
    return lista


def obra_configurada(con, obra_leida):
    """Obra de la tabla de tarifas que corresponde al nombre leído del archivo: igual, o elegida antes por RRHH."""
    k = clave(obra_leida)
    for o in obras_configuradas(con):
        if clave(o) == k:
            return o
    return db.obra_alias(con).get(k)


def obras_configuradas(con):
    return [t["obra"] for t in db.tarifas(con) if t["obra"] != "ESTÁNDAR"]


def asignar_obra(con, archivo_id, obra):
    """RRHH indica a qué obra configurada corresponde un archivo. Se recuerda para los meses siguientes."""
    a = con.execute("SELECT * FROM archivos WHERE id = ?", (archivo_id,)).fetchone()
    if a is None:
        raise ValueError("Ese archivo ya no está cargado.")
    if a["periodo"] != db.config(con)["periodo"]:
        raise ValueError("Ese archivo es de un mes cerrado: solo se puede consultar.")
    if obra not in obras_configuradas(con):
        raise ValueError("Elige una obra de la lista.")
    leida = a["obra_leida"] or a["obra"]
    db.guardar_alias(con, clave(leida), obra)
    con.execute("UPDATE archivos SET obra = ? WHERE id = ?", (obra, archivo_id))
    con.commit()
    return {"obra_leida": leida, "obra": obra}


def guardar_caso(con, d):
    """Valida y guarda un caso especial (hoja «Tarifas y Bonos» del Excel). Devuelve el id."""
    rut = normalizar_rut(d.get("rut"))
    if not rut or not any(normalizar_rut(t["rut"]) == rut for t in db.trabajadores(con)):
        raise ValueError("Elige un trabajador de la lista.")
    tipos = {t["tipo"]: t for t in db.tipos(con)}
    tipo = (d.get("tipo") or "").strip()
    if tipo not in tipos:
        raise ValueError("Elige un tipo de la lista.")
    clase = tipos[tipo]["clase"]
    sab, dom, bono = d.get("sabado"), d.get("domingo"), d.get("bono")
    if clase == "TARIFA":
        if sab is None and dom is None:
            raise ValueError("Una tarifa especial necesita el valor del sábado, del domingo/feriado o de ambos.")
        bono = None
    else:
        sab = dom = None   # un bono no cambia la tarifa; sin monto se usa el monto por defecto del tipo
        if bono is None and tipos[tipo]["monto"] is None:
            raise ValueError(f"«{tipo}» no tiene monto por defecto: escribe el monto del bono.")
    for v in (sab, dom, bono):
        if v is not None and v < 0:
            raise ValueError("Los montos no pueden ser negativos.")
    desde, hasta = db.a_fecha(d.get("desde")), db.a_fecha(d.get("hasta"))
    if desde and hasta and hasta < desde:
        raise ValueError("«Hasta» es anterior a «Desde».")
    obra = (d.get("obra") or "").strip() or "TODAS"
    return db.guardar_caso(con, {"id": d.get("id"), "rut": formatear_rut(rut), "obra": obra, "tipo": tipo,
                                 "sabado": sab, "domingo": dom, "bono": bono, "desde": desde, "hasta": hasta,
                                 "comentario": (d.get("comentario") or "").strip() or None})


def agregar_trabajador(con, d):
    """Agrega un trabajador nuevo a Trabajadores (por ahora a mano, desde Revisión).

    Si viene `fila_id`, esa fila queda asignada al trabajador nuevo (cuando el archivo trae el RUT vacío o distinto).
    """
    nombres = nombre_propio(" ".join((d.get("nombres") or "").split()))
    apellidos = nombre_propio(" ".join((d.get("apellidos") or "").split()))
    corto = nombre_propio(" ".join((d.get("corto") or "").split())) or None
    rut = normalizar_rut(d.get("rut"))
    if not nombres or not apellidos:
        raise ValueError("Escribe los nombres y los apellidos.")
    if not rut_valido(rut):
        raise ValueError(f"El RUT {formatear_rut(rut) or '(vacío)'} no es válido: revisa el número y el dígito verificador.")
    for t in db.trabajadores(con):
        if normalizar_rut(t["rut"]) == rut:
            raise ValueError(f"Ese RUT ya está en Trabajadores como {motor.se_muestra_como(t)}: elígelo en «¿Quién es?».")
    nuevo = {"nombres": nombres, "apellidos": apellidos, "corto": corto}
    muestra = motor.se_muestra_como(nuevo)
    if any(motor.se_muestra_como(t) == muestra for t in db.trabajadores(con)):
        raise ValueError(f"Ya hay otro trabajador que se muestra como «{muestra}»: escribe un nombre corto distinto.")
    if d.get("fila_id"):
        db.exigir_mes_en_curso(con, int(d["fila_id"]))
    db.agregar_trabajador(con, nombres, apellidos, formatear_rut(rut), corto)
    if d.get("fila_id"):
        fila = con.execute("SELECT rut FROM filas WHERE id = ?", (int(d["fila_id"]),)).fetchone()
        if normalizar_rut(fila["rut"]) != rut:
            db.corregir_rut(con, int(d["fila_id"]), formatear_rut(rut))
    return {"rut": formatear_rut(rut), "muestra": muestra}


def guardar_tipo(con, d):
    """Agrega un tipo nuevo de tarifa o bono (o cambia el monto por defecto de uno existente)."""
    tipo = " ".join((d.get("tipo") or "").split())
    clase = d.get("clase")
    if not tipo:
        raise ValueError("Escribe el nombre del tipo.")
    if clase not in ("TARIFA", "BONO"):
        raise ValueError("La clase tiene que ser TARIFA o BONO.")
    actual = next((t for t in db.tipos(con) if t["tipo"].lower() == tipo.lower()), None)
    if actual and actual["clase"] != clase and any(c["tipo"] == actual["tipo"] for c in db.casos(con)):
        raise ValueError(f"«{actual['tipo']}» ya existe como {actual['clase']} y hay casos que lo usan: no se puede cambiar de clase.")
    db.guardar_tipo(con, actual["tipo"] if actual else tipo, clase, d.get("monto") if clase == "BONO" else None)
    return actual["tipo"] if actual else tipo


def mes_siguiente(f):
    """Mismo día del mes siguiente (o el último día si ese mes es más corto)."""
    y, m = f.year + (f.month == 12), f.month % 12 + 1
    return dt.date(y, m, min(f.day, calendar.monthrange(y, m)[1]))


def fin_de_mes(f):
    return dt.date(f.year, f.month, calendar.monthrange(f.year, f.month)[1])


def periodo_siguiente(con):
    """Propuesta para el mes siguiente: desde = hasta + 1 día.

    Regla nueva (desde oct-26, confirmada): mes calendario, del 1 al último día. Si el período no parte un día 1
    (transición, como 25-09 → 31-10), termina el último día del mes siguiente.
    Regla anterior (Excel, jun–sep): hasta = el mismo día del mes siguiente (25 → 24).
    """
    cfg = db.config(con)
    desde = cfg["hasta"] + dt.timedelta(days=1)
    if cfg["solo_periodo"]:
        hasta = fin_de_mes(desde if desde.day == 1 else mes_siguiente(desde.replace(day=1)))
    else:
        hasta = mes_siguiente(cfg["hasta"])
    return {"periodo": hasta.year * 100 + hasta.month, "desde": desde, "hasta": hasta}


def cerrar(con, desde=None, hasta=None):
    """Cierra el mes en curso (igual que cerrar_periodo.py del skill) y deja listo el siguiente.

    1. Guarda la foto del mes (lo cargado, la revisión con sus decisiones y la configuración) y el archivo TALANA.
    2. Pasa al historial los días del detalle con trabajo o ausencia, para avisar DUPLICADO en los meses siguientes.
    3. Avanza el período. Desde/hasta del mes siguiente se pueden cambiar (el corte puede variar).
    Lo cargado del mes queda en la base (no se borra); el mes nuevo parte vacío.
    """
    cfg = db.config(con)
    periodo = cfg["periodo"]
    if db.mes_cerrado(con, periodo):
        raise ValueError(f"{nombre_mes(periodo)} ya está cerrado.")
    foto = estado(con)
    if not foto["resumen"]["listo"]:
        raise ValueError("Todavía no está listo para TALANA: termina la revisión antes de cerrar el mes.")
    archivo_talana = talana.generar(foto["talana"])
    sig = periodo_siguiente(con)
    desde, hasta = db.a_fecha(desde) or sig["desde"], db.a_fecha(hasta) or sig["hasta"]
    if hasta < desde:
        raise ValueError("El mes siguiente termina antes de empezar: revisa las fechas.")
    nuevo = hasta.year * 100 + hasta.month
    if nuevo == periodo or db.mes_cerrado(con, nuevo):
        raise ValueError(f"El período {nombre_mes(nuevo)} ya existe: revisa las fechas.")

    foto["cerrado"] = dt.datetime.now().isoformat(timespec="seconds")
    historial, cambiados = [], []
    for f in foto["filas"]:
        if f["rut"] == motor.SIN_RUT:
            continue
        for g in f["detalle"]:
            if g["clase"] == "cuenta" and (g["trabajo"] or g["ausencia"]):
                historial.append((f["rut"], g["fecha"], f["obra"], f["archivo"], periodo, g["trabajo"], g["ausencia"], g["he"],
                                  g["obs"], g.get("fds_fiable") or 0))
            elif g["cambios"]:
                cambiados.append((f["rut"], g, f["obra"], f["archivo"], g["cambios"]))
        if f.get("reliquidacion"):
            db.guardar_reliquidaciones(con, f["reliquidacion"], f["archivo"], periodo)
    if cfg["solo_periodo"]:
        # Un día que ya está en el historial no se agrega otra vez (ej. oct-26: del 25 al 30-09 ya se pagó en septiembre
        # y en octubre no se comparan los ya pagados). Así el historial no queda con el mismo día dos veces.
        ya = db.historial_claves(con)
        historial = [h for h in historial if (h[0], h[1]) not in ya]
    con.executemany("INSERT INTO historial (rut, fecha, obra, archivo, periodo, trabajo, ausencia, he, obs, fds_fiable) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?)", historial)
    # Días ya pagados que cambiaron: el historial queda con lo último informado (la diferencia quedó en reliquidaciones)
    pagado = db.historial_valores(con)
    for rut, g, obra_g, archivo, cs in cambiados:
        reemplazar_dia_historial(con, rut, g, obra_g, archivo, pagado.get((rut, g["fecha"]), {}).get("periodo") or periodo)
    r = foto["resumen"]
    con.execute("INSERT INTO meses_cerrados VALUES (?,?,?,?,?,?,?,?,?,?)",
                (periodo, db.iso(cfg["desde"]), db.iso(cfg["hasta"]), foto["cerrado"],
                 ", ".join(sorted(a["nombre"] for a in foto["archivos"])), r["trabajadores"], r["he"], r["desgaste"],
                 json.dumps(foto, default=db.iso, ensure_ascii=False), archivo_talana))
    con.commit()
    db.guardar_config(con, periodo=nuevo, desde=desde, hasta=hasta)
    return {"periodo": periodo, "dias_historial": len(historial), "siguiente": nuevo, "desde": desde, "hasta": hasta}


def reemplazar_dia_historial(con, rut, g, obra, archivo, periodo):
    """Deja una sola entrada del historial para ese trabajador y día, con lo último informado."""
    con.execute("DELETE FROM historial WHERE rut = ? AND fecha = ?", (rut, g["fecha"]))
    con.execute("INSERT INTO historial (rut, fecha, obra, archivo, periodo, trabajo, ausencia, he, obs, fds_fiable) "
                "VALUES (?,?,?,?,?,?,?,?,?,?)",
                (rut, g["fecha"], obra, archivo, periodo, g["trabajo"], g["ausencia"], g["he"], g["obs"], g.get("fds_fiable") or 0))


def cargar_correccion(con, periodo, nombre, contenido):
    """Archivo corregido de un mes cerrado: compara con lo pagado y registra los cambios como reliquidación.

    - Por día (del período de ese mes): horas extra, ausencia/licencia y, si el formato lo marca, trabajo de fin de
      semana, contra el historial. El historial queda con lo nuevo, así volver a subir el archivo no repite cambios.
    - Por trabajador (si el mes tiene foto): días, horas extra, sábados, domingos/feriados y monto informados.
    """
    m = db.mes_cerrado(con, periodo)
    if not m:
        raise ValueError(f"{nombre_mes(periodo)} no está cerrado.")
    desde, hasta = db.a_fecha(m["desde"]), db.a_fecha(m["hasta"])
    nombre = nombre_seguro(nombre)
    carpeta = os.path.join(carpeta_periodo(periodo), "correcciones")
    os.makedirs(carpeta, exist_ok=True)
    ruta = os.path.join(carpeta, nombre)
    with open(ruta, "wb") as fh:
        fh.write(contenido)
    cfg = db.config(con)
    try:
        leido = lector.leer_archivo(ruta, nombre, periodo, cfg["dias_base"], db.ausencias(con))
    except Exception as e:  # noqa: BLE001
        raise ValueError(f"No se pudo leer «{nombre}»: {e}") from e
    obra = obra_configurada(con, leido["obra"]) or leido["obra"]
    ctx = motor.Contexto(con)
    pagado = db.historial_valores(con)
    foto = json.loads(m["foto"]) if m["foto"] else None
    ya = {(r["rut"], r["obra"], r["campo"], r["ahora"]) for r in db.reliquidaciones(con) if r["periodo_original"] == periodo}
    filas_foto = [x for x in (foto or {}).get("filas", []) if clave(x["obra"]) == clave(obra)]
    usadas = set()
    cambios, avisos, dias_hist, dias_nuevos = [], [], [], {}
    for f in leido["filas"]:
        rut, _, _ = motor.identificar(ctx, {"rut": f["rut"], "nombre": f["nombre"], "apellido": f["apellido"]})
        # Si en el mes pagado el RUT del archivo se corrigió en la revisión, se usa la misma corrección
        mismo = next((x for x in filas_foto if normalizar_rut(x["informado"]["rut"]) == normalizar_rut(f["rut"]) and f["rut"]
                      and x.get("rut_corregido")), None)
        if mismo:
            rut = mismo["rut"]
        quien = nombre_propio(f"{f['nombre']} {f['apellido']}")
        if rut == motor.SIN_RUT or rut not in ctx.por_rut:
            avisos.append(f"{quien}: no está en Trabajadores, no se pudo comparar.")
            continue
        trabajador = ctx.por_rut[rut]["muestra"]
        base = {"periodo_original": periodo, "rut": rut, "trabajador": trabajador, "obra": obra}
        for g in f.get("detalle") or []:
            fecha = db.a_fecha(g["fecha"])
            if not (desde <= fecha <= hasta):
                continue
            gi = dict(g, fecha=db.iso(fecha), tipo_dia=ctx.tipo_dia(fecha), trabajo=1 if (g["asistio"] == 1 or motor.num(g["he"]) > 0) else 0)
            k = (rut, gi["fecha"])
            if k in dias_nuevos:   # el mismo trabajador en otra fila ese día: se juntan, igual que en el historial
                a = dias_nuevos[k][1]
                a["he"] = motor.num(a["he"]) + motor.num(gi["he"])
                a["ausencia"], a["trabajo"] = max(a["ausencia"], gi["ausencia"]), max(a["trabajo"], gi["trabajo"])
                a["obs"] = "; ".join(x for x in (a["obs"], gi["obs"]) if x)
            else:
                dias_nuevos[k] = (base, gi)
        if foto:
            # Un trabajador puede tener más de una fila en la misma obra (ej. dos turnos en la misma obra): en orden
            antes = next((x for x in filas_foto if x["rut"] == rut and x["id"] not in usadas), None)
            if antes:
                usadas.add(antes["id"])
            o = {"dias": motor.num(f["dias"]), "he": motor.num(f["he"]), "sab": motor.num(f["sab"]), "dom": motor.num(f["dom"]),
                 "monto": motor.num(f["monto_fds"]) + motor.num(f["bonos"])}
            if antes is None:
                resumen = [("Aparece en la obra", "no", "sí")]
            else:
                a = antes["obra_val"]
                resumen = [(et, a[k], o[k]) for k, et in (("dias", "Días informados"), ("he", "Horas extra informadas"),
                                                          ("sab", "Sábados informados"), ("dom", "Domingos/feriados informados"),
                                                          ("monto", "Monto informado")) if abs(motor.num(a[k]) - o[k]) > motor.EPS]
            for campo, va, vn in resumen:
                ahora = vn if isinstance(vn, str) else motor.fmt(vn)
                if (rut, obra, campo, str(ahora)) not in ya:
                    cambios.append({**base, "fecha": None, "campo": campo, "antes": va if isinstance(va, str) else motor.fmt(va),
                                    "ahora": ahora})
    dias_cambio = []
    for (rut, fecha), (base, gi) in sorted(dias_nuevos.items(), key=lambda x: x[0][1]):
        p = pagado.get((rut, fecha)) or {"he": 0, "ausencia": 0, "trabajo": 0, "obs": "",
                                         "fds_fiable": gi.get("fds_fiable"), "periodo": periodo}
        cs = motor.comparar_dia(ctx, gi, p)
        if cs:
            dias_cambio += [{**base, "fecha": fecha, **c} for c in cs]
            dias_hist.append((rut, gi, base["obra"]))
    cambios = dias_cambio + cambios
    db.guardar_reliquidaciones(con, cambios, nombre, cfg["periodo"])
    for rut, g, obra_g in dias_hist:
        reemplazar_dia_historial(con, rut, g, obra_g, nombre, periodo)
    con.commit()
    if not foto:
        avisos.append(f"{nombre_mes(periodo)} se cerró en el Excel (sin foto en la app): solo se compararon los días, "
                      "no el resumen de cada trabajador.")
    return {"periodo": periodo, "obra": obra, "cambios": cambios, "avisos": avisos}


def foto_mes(con, periodo):
    """Estado guardado de un mes cerrado (solo consulta)."""
    m = db.mes_cerrado(con, periodo)
    if not m or not m["foto"]:
        raise ValueError(f"No hay datos guardados de {nombre_mes(periodo)}.")
    return json.loads(m["foto"])


def carpeta_periodo(periodo):
    ruta = os.path.join(db.carpeta_datos(), "archivos", str(periodo))
    os.makedirs(ruta, exist_ok=True)
    return ruta


def nombre_seguro(nombre):
    return re.sub(r'[\\/:*?"<>|]', "_", os.path.basename(nombre)).strip() or "archivo.xlsx"


def cargar(con, nombre, contenido):
    """Guarda el archivo en la carpeta del período, lo lee y guarda lo extraído.

    Si ya hay un archivo de la misma obra (otra versión, ej. «H&M ALC V.2»), lo reemplaza.
    Devuelve {"archivo_id", "obra", "reemplazo": [nombres], "avisos": [...]}. Lanza ValueError si no se puede leer.
    """
    cfg = db.config(con)
    nombre = nombre_seguro(nombre)
    if not nombre.lower().endswith((".xlsx", ".xlsm")):
        raise ValueError("Solo se pueden cargar archivos Excel (.xlsx).")
    ruta = os.path.join(carpeta_periodo(cfg["periodo"]), nombre)
    with open(ruta, "wb") as fh:
        fh.write(contenido)
    try:
        leido = lector.leer_archivo(ruta, nombre, cfg["periodo"], cfg["dias_base"], db.ausencias(con))
    except Exception as e:  # noqa: BLE001 — cualquier error de lectura se informa a RRHH tal cual
        raise ValueError(f"No se pudo leer «{nombre}»: {e}") from e
    leido["obra_leida"] = leido["obra"]
    leido["obra"] = obra_configurada(con, leido["obra"]) or leido["obra"]
    reemplazo = []
    for a in db.archivos(con, cfg["periodo"]):
        if a["nombre"] == nombre or clave(a["obra"]) == clave(leido["obra"]) or \
                clave(obra_desde_archivo(a["nombre"])) == clave(obra_desde_archivo(nombre)):
            db.borrar_archivo(con, a["id"])
            reemplazo.append(a["nombre"])
    archivo_id = db.guardar_archivo(con, cfg["periodo"], nombre, ruta, leido)
    return {"archivo_id": archivo_id, "obra": leido["obra"], "reemplazo": reemplazo, "avisos": leido["avisos"],
            "filas": len(leido["filas"])}
