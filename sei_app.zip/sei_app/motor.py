"""Motor de cálculo: hace lo mismo que las fórmulas de las hojas Revisión y TALANA del libro Excel.

Cada fila de una obra pasa por: identificar al trabajador → lo que informa la obra → lo que calcula la planilla
(detalle diario y tarifas) → alertas → estado (OK / Revisar / Revisado) → lo que va a TALANA.
Las columnas del libro original se indican entre corchetes, ej. [Revisión!Y], para poder comparar.
"""
from . import db
from .comun import (TALANA_COLUMNAS, TALANA_DESGASTE, TALANA_DIAS, TALANA_HE, TALANA_VIATICOS, TALANA_ANTICIPO_VIATICO, clave, dias_fuera_base30,
                    formatear_rut, nombre_propio, normalizar_rut, rut_valido)

SIN_RUT = "SIN RUT"
EPS = 1e-9
# Trato de fin de semana (confirmado el 28-10-2026): sábado $70.000 y domingo/feriado $80.000. Se usa cuando la obra
# lo marca en la planilla y el trabajador no tiene una tarifa especial en Tarifas y bonos.
TRATO_FDS = {"sabado": (70000, "trato de fin de semana (marcado por la obra)"),
             "domingo": (80000, "trato de fin de semana (marcado por la obra)")}


def se_muestra_como(t):
    """[Trabajadores!H] nombre corto, o primer nombre + primer apellido."""
    if (t.get("corto") or "").strip():
        return nombre_propio(t["corto"].strip())
    p = ((t.get("nombres") or "").split() or [""])[0]
    a = ((t.get("apellidos") or "").split() or [""])[0]
    return nombre_propio(f"{p} {a}")


def pesos(v):
    return "$" + f"{round(v or 0):,.0f}".replace(",", ".")


def num(v):
    """Como N() de Excel: vacío → 0."""
    return v if isinstance(v, (int, float)) else 0


def fmt(v):
    if v is None:
        return ""
    return f"{v:g}" if isinstance(v, float) else str(v)


class Contexto:
    """Todo lo que el cálculo necesita de la base: configuración, tarifas, casos y trabajadores."""

    def __init__(self, con):
        self.cfg = db.config(con)
        self.tarifas = {t["obra"]: t for t in db.tarifas(con)}
        self.estandar = self.tarifas.get("ESTÁNDAR") or {"sabado": 0, "domingo": 0}
        self.tipos = {t["tipo"]: t for t in db.tipos(con)}
        self.casos = db.casos(con)
        self.trabajadores = db.trabajadores(con)
        self.feriados = {f["fecha"]: f["nombre"] for f in db.feriados(con)}
        self.historial = db.historial_claves(con)
        desde = self.cfg["comparar_pagados_desde"]
        self.compara_pagados = self.cfg["solo_periodo"] and (desde is None or self.cfg["periodo"] >= desde)
        self.pagado = db.historial_valores(con) if self.compara_pagados else {}
        self.palabras = db.ausencias(con)
        self.por_rut, self.por_largo, self.por_corto = {}, {}, {}
        for t in self.trabajadores:
            rut = normalizar_rut(t["rut"])
            if not rut:
                continue
            t["muestra"] = se_muestra_como(t)
            self.por_rut[rut] = t
            self.por_largo.setdefault(clave(f"{(t['nombres'] or '').strip()} {(t['apellidos'] or '').strip()}"), rut)
            self.por_corto.setdefault(clave(t["muestra"]), rut)

    def caso_vigente(self, c):
        """[Tarifas y Bonos!N] Desde/Hasta vacíos = siempre vigente; si no, se cruza con el período."""
        ini, fin = self.cfg["desde"], self.cfg["hasta"]
        return bool(c["rut"] and c["tipo"]) and (c["desde"] is None or fin is None or c["desde"] <= fin) and \
            (c["hasta"] is None or ini is None or c["hasta"] >= ini)

    def clase(self, c):
        return (self.tipos.get(c["tipo"]) or {}).get("clase") or ""

    def tarifa(self, rut, obra, campo):
        """[Revisión!Y/Z] Caso especial de la obra → caso especial TODAS → tarifa de la obra → ESTÁNDAR."""
        nombre = "Sábado" if campo == "sabado" else "Domingo / feriado"
        if rut != SIN_RUT:
            for alcance in (obra, "TODAS"):
                vals = [c[campo] for c in self.casos
                        if normalizar_rut(c["rut"]) == rut and self.clase(c) == "TARIFA" and self.caso_vigente(c)
                        and (c["obra"] or "TODAS") == alcance and c[campo] is not None]
                if vals:
                    origen = f"tarifa especial ({'todas las obras' if alcance == 'TODAS' else alcance})"
                    return sum(vals) / len(vals), origen
        t = self.tarifas.get(obra)
        if t and isinstance(t.get(campo), (int, float)):
            return t[campo], f"tarifa de la obra {obra}"
        return num(self.estandar.get(campo)), f"tarifa ESTÁNDAR ({nombre.lower()})"

    def bonos(self, rut, alcance):
        """[Tarifas y Bonos!O] Bonos vigentes del trabajador para una obra (o TODAS)."""
        out = []
        for c in self.casos:
            if normalizar_rut(c["rut"]) != rut or (c["obra"] or "TODAS") != alcance:
                continue
            if self.clase(c) != "BONO" or not self.caso_vigente(c):
                continue
            monto = c["bono"] if c["bono"] is not None else num((self.tipos.get(c["tipo"]) or {}).get("monto"))
            out.append({"tipo": c["tipo"], "monto": monto, "obra": alcance, "comentario": c.get("comentario") or ""})
        return out

    def tipo_dia(self, fecha):
        f = db.a_fecha(fecha)
        if f in self.feriados:
            return "Feriado"
        return {5: "Sábado", 6: "Domingo"}.get(f.weekday(), "Hábil")


def tipo_ausencia(palabras, obs, ausencia):
    """'licencia' / 'permiso' / … según la palabra que aparezca en la observación del día."""
    if not ausencia:
        return "—"
    k = clave(obs)
    return next((p for p in palabras if p in k), "ausencia")


def comparar_dia(ctx, g, pagado):
    """Cambios de un día ya pagado: horas extra, ausencia/licencia y (si el formato lo marca) trabajo de fin de semana."""
    cambios = []
    he_a, he_n = num(pagado["he"]), num(g["he"])
    if abs(he_a - he_n) > EPS:
        cambios.append({"campo": "Horas extra", "antes": fmt(he_a), "ahora": fmt(he_n)})
    aus_a, aus_n = bool(pagado["ausencia"]), bool(g["ausencia"])
    t_a = tipo_ausencia(ctx.palabras, pagado.get("obs") or "", aus_a)   # historial del Excel: sin observación
    t_n = tipo_ausencia(ctx.palabras, g["obs"] or "", aus_n)
    if aus_a != aus_n:
        cambios.append({"campo": "Ausencia / licencia", "antes": t_a, "ahora": t_n})
    elif aus_a and pagado.get("obs") is not None and t_a != t_n:
        cambios.append({"campo": "Tipo de ausencia", "antes": t_a, "ahora": t_n})
    if g["tipo_dia"] != "Hábil" and g.get("fds_fiable") and pagado.get("fds_fiable") and bool(pagado["trabajo"]) != bool(g["trabajo"]):
        cambios.append({"campo": f"Trabajó ({g['tipo_dia'].lower()})", "antes": "sí" if pagado["trabajo"] else "no",
                        "ahora": "sí" if g["trabajo"] else "no"})
    return cambios


def identificar(ctx, f):
    """[Datos obras!P,Q] RUT informado; si no viene, se busca el nombre completo y luego el nombre corto."""
    rut = normalizar_rut(f["rut"])
    como = "informado por la obra"
    if f.get("rut_corregido"):
        rut, como = normalizar_rut(f["rut_corregido"]), "corregido en la revisión"
    if not rut:
        k = clave(f"{f['nombre'] or ''} {f['apellido'] or ''}")
        rut = ctx.por_largo.get(k) or ctx.por_corto.get(k) or ""
        como = "reconocido por el nombre" if rut else ""
    if not rut:
        return SIN_RUT, "SIN RUT", ""
    estado = "OK" if rut in ctx.por_rut else "No está en Trabajadores"
    return rut, estado, como


def calcular(con):
    """Calcula todas las filas del período y la carga TALANA. Devuelve un dict listo para la app."""
    ctx = Contexto(con)
    cfg = ctx.cfg
    dias_base = cfg["dias_base"]
    filas = db.filas(con, cfg["periodo"])
    decisiones = db.decisiones(con)

    # Primera pasada: identificación y totales por RUT (para la suma de días entre obras).
    for f in filas:
        f["rut_clave"], f["estado_rut"], f["rut_como"] = identificar(ctx, f)
    dias_por_rut = {}
    for f in filas:
        if f["rut_clave"] != SIN_RUT:
            dias_por_rut[f["rut_clave"]] = dias_por_rut.get(f["rut_clave"], 0) + num(f["dias"])

    vistos_rut, vistos_rut_obra, vistos_marca = set(), set(), set()
    salida = []
    for f in filas:
        rut, obra = f["rut_clave"], f["obra"]
        t = ctx.por_rut.get(rut)
        trabajador = t["muestra"] if t else nombre_propio(f"{f['nombre'] or ''} {f['apellido'] or ''}".strip())

        # Lo que informa la obra [F, G, H]
        o_dias, o_he = num(f["dias"]), num(f["he"])
        o_monto = num(f["monto_fds"]) + num(f["bonos"])
        obra_informa_monto = f["monto_fds"] is not None or f["bonos"] is not None   # [AM]

        # Detalle diario [AC, I, J] y días ya pagados [AG]
        det = f["detalle"]
        dup = 0
        reliq = []
        for g in det:
            g["tipo_dia"] = ctx.tipo_dia(g["fecha"])
            g["trabajo"] = 1 if (g["asistio"] == 1 or num(g["he"]) > 0) else 0
            fecha = db.a_fecha(g["fecha"])
            g["en_periodo"] = bool(cfg["desde"] and cfg["hasta"] and cfg["desde"] <= fecha <= cfg["hasta"])
            g["duplicado"] = bool(rut != SIN_RUT and (g["trabajo"] or g["ausencia"]) and (rut, g["fecha"]) in ctx.historial)
            g["clase"], g["cambios"] = "cuenta", []
            if cfg["solo_periodo"]:
                # Regla desde oct-26: solo cuentan los días del período que no estén pagados. Los ya pagados se
                # comparan con lo pagado (cambios = reliquidación); los de un mes futuro no se usan.
                pagado = ctx.pagado.get((rut, g["fecha"])) if rut != SIN_RUT else None
                if cfg["hasta"] and fecha > cfg["hasta"]:
                    g["clase"] = "futuro"
                elif pagado:
                    g["clase"] = "pagado"
                    g["cambios"] = comparar_dia(ctx, g, pagado)
                    reliq += [{"fecha": g["fecha"], "periodo_original": pagado["periodo"], **c} for c in g["cambios"]]
                elif cfg["desde"] and fecha < cfg["desde"]:
                    g["clase"] = "anterior"
            else:
                dup += g["duplicado"]
        cuenta = [g for g in det if g["clase"] == "cuenta"]
        n_det = len(cuenta)
        # Regla desde oct-26 (confirmada el 28-10-2026): los días antes del ingreso (de Trabajadores/TALANA) y después
        # del finiquito no se trabajan; se descuentan de los 30 solo los del mes calendario (entró el 05-10 → 30 − 4).
        # Se cuenta en escala de 30 con el número del día (comun.dias_fuera_base30): finiquito el 14 → 14 días.
        sin_contrato = 0
        if cfg["solo_periodo"] and cfg["hasta"]:
            ingreso = db.a_fecha(f.get("ingreso")) or db.a_fecha((ctx.por_rut.get(rut) or {}).get("ingreso"))
            ultimo = min([x for x in (db.a_fecha(f.get("finiquito")), db.a_fecha(f.get("termino"))) if x], default=None)
            for g in cuenta:
                fecha = db.a_fecha(g["fecha"])
                g["sin_contrato"] = bool((ingreso and fecha < ingreso) or (ultimo and fecha > ultimo))
            antes, despues = dias_fuera_base30(dias_base, cfg["hasta"].replace(day=1), cfg["hasta"], ingreso, ultimo)
            sin_contrato = antes + despues
        # Las ausencias en días sin contrato no se descuentan dos veces
        ausencias = sum(1 for g in cuenta if g["ausencia"] == 1 and not g.get("sin_contrato")) + sin_contrato
        p_dias = max(0, dias_base - ausencias) if n_det else None
        p_he = sum(num(g["he"]) for g in cuenta) if n_det else None
        n_clase = {k: sum(1 for g in det if g["clase"] == k) for k in ("pagado", "futuro", "anterior")}

        # Tarifas y bonos [U, W, Y, Z, AA, AB, K]
        sab, dom = num(f["sab"]), num(f["dom"])
        t_sab, o_sab = ctx.tarifa(rut, obra, "sabado")
        t_dom, o_dom = ctx.tarifa(rut, obra, "domingo")
        fds = sab * t_sab + dom * t_dom
        bonos = []
        if rut != SIN_RUT:
            if (rut, obra) not in vistos_rut_obra:      # [AI] bonos de la obra: una vez por trabajador y obra
                bonos += ctx.bonos(rut, obra)
            if rut not in vistos_rut:                   # [AH] bonos de TODAS: una vez por trabajador
                bonos += ctx.bonos(rut, "TODAS")
        primera_del_rut = rut != SIN_RUT and rut not in vistos_rut
        if rut != SIN_RUT:
            vistos_rut.add(rut)
            vistos_rut_obra.add((rut, obra))
        # Planilla nueva: mandan las marcas de la obra (trato FDS, bono noche, bono lejanía); el monto sale de la app.
        # Si no coinciden con Tarifas y bonos, se avisa y la fila queda en Revisar (confirmado el 28-10-2026).
        avisos_marcas = []
        marcas = f.get("marcas")
        if marcas is not None and rut != SIN_RUT:
            especial = "tarifa especial" in o_sab or "tarifa especial" in o_dom
            if marcas.get("trato") and not especial:
                (t_sab, o_sab), (t_dom, o_dom) = TRATO_FDS["sabado"], TRATO_FDS["domingo"]
                avisos_marcas.append("La obra marcó trato de fin de semana y no está en Tarifas y bonos: "
                                     f"se usa {pesos(t_sab)} el sábado y {pesos(t_dom)} el domingo.")
            elif not marcas.get("trato") and especial:
                t_sab, o_sab = ctx.tarifa(SIN_RUT, obra, "sabado")
                t_dom, o_dom = ctx.tarifa(SIN_RUT, obra, "domingo")
                avisos_marcas.append("Tiene tarifa especial en Tarifas y bonos, pero la obra no marcó trato de fin de "
                                     "semana: no se aplica.")
            fds = sab * t_sab + dom * t_dom
            for marca, palabra in (("noche", "noche"), ("lejania", "lejan")):
                tipo = next((t for t in ctx.tipos if palabra in clave(t) and ctx.tipos[t]["clase"] == "BONO"), None)
                if tipo is None:
                    continue
                del_tipo = [b for b in bonos if b["tipo"] == tipo]
                if marcas.get(marca) and not del_tipo and (rut, tipo) not in vistos_marca:
                    config = [b for b in ctx.bonos(rut, obra) + ctx.bonos(rut, "TODAS") if b["tipo"] == tipo]
                    monto = config[0]["monto"] if config else (ctx.tipos[tipo].get("monto") if tipo in ctx.tipos else None)
                    bonos.append({"tipo": tipo, "monto": num(monto), "obra": obra, "comentario": "marcado por la obra"})
                    if not config:
                        avisos_marcas.append(f"La obra marcó {tipo.lower()} y no está en Tarifas y bonos: "
                                             + (f"se usa el monto del tipo ({pesos(monto)})." if monto else "no tiene monto."))
                elif not marcas.get(marca) and del_tipo:
                    bonos = [b for b in bonos if b["tipo"] != tipo]
                    avisos_marcas.append(f"Tiene {tipo.lower()} en Tarifas y bonos, pero la obra no lo marcó: no se paga.")
                if marcas.get(marca):
                    vistos_marca.add((rut, tipo))
        p_monto = fds + sum(b["monto"] for b in bonos)

        # Alertas [AD, AE, AF, AK]
        suma_dias = dias_por_rut.get(rut) if rut != SIN_RUT else None
        dif_dias = bool(n_det and abs(o_dias - p_dias) > EPS)
        dif_he = bool(n_det and abs(o_he - p_he) > EPS)
        # Con la regla desde oct-26, el trabajador en más de una obra lo resuelve dos_obras() (después del ciclo).
        excede = not cfg["solo_periodo"] and suma_dias is not None and suma_dias > dias_base
        f_dias = dif_dias or dup > 0 or excede
        f_he = dif_he or dup > 0
        f_monto = obra_informa_monto and round(o_monto) != round(p_monto)

        # Decisión de RRHH [L, M, N, O]
        d = decisiones.get(f["id"]) or {}
        usar = d.get("usar")
        decidido = bool(usar or d.get("dias") is not None or d.get("he") is not None or d.get("monto") is not None)
        # RUT inválido o que no está en Trabajadores: queda en Revisar hasta que se corrija el trabajador
        # (confirmado por el usuario el 26-10-2026; en el Excel solo era una nota). Obra/Planilla no lo libera.
        rut_invalido = rut != SIN_RUT and not rut_valido(rut) and not f.get("rut_corregido")
        falta_trabajador = rut == SIN_RUT or f["estado_rut"] != "OK" or rut_invalido
        pendiente = bool(falta_trabajador or ((f_dias or f_he or f_monto or avisos_marcas) and not decidido))   # [AL] + reglas nuevas
        estado = "Revisar" if pendiente else ("Revisado" if decidido else "OK")         # [B]

        # Lo que va a TALANA [P, Q, R]
        if d.get("dias") is not None:
            v_dias, fuente_dias = d["dias"], "tu revisión"
        elif usar == "Planilla" and p_dias is not None:
            v_dias, fuente_dias = p_dias, "planilla"
        else:
            v_dias, fuente_dias = o_dias, "obra"
        if d.get("he") is not None:
            v_he, fuente_he = d["he"], "tu revisión"
        elif usar == "Planilla" and p_he is not None:
            v_he, fuente_he = p_he, "planilla"
        else:
            v_he, fuente_he = o_he, "obra"
        if d.get("monto") is not None:
            v_monto, fuente_monto = d["monto"], "tu revisión"
        elif usar == "Planilla" or not obra_informa_monto:
            v_monto, fuente_monto = p_monto, "planilla"
        else:
            v_monto, fuente_monto = o_monto, "obra"

        # Qué revisar [E]
        notas = []
        if rut == SIN_RUT:
            notas.append("Falta el RUT: agrégalo en Trabajadores.")
        else:
            if rut_invalido:
                notas.append("RUT inválido (dígito verificador): elige quién es.")
            if f["estado_rut"] != "OK":
                notas.append("No está en Trabajadores: elige quién es.")
        if dif_dias:
            notas.append(f"Días: obra {fmt(o_dias)}, detalle {fmt(p_dias)}.")
        if dif_he:
            notas.append(f"Horas extra: obra {fmt(o_he)}, detalle {fmt(p_he)}.")
        if f_monto:
            notas.append(f"Monto: obra {pesos(o_monto)}, tarifas {pesos(p_monto)}.")
        if not obra_informa_monto and p_monto > 0:
            notas.append("La obra no informa montos: se usan las tarifas.")
        if dup:
            notas.append(f"{dup} día(s) ya pagados en un mes anterior.")
        notas += avisos_marcas
        if f.get("finiquito"):
            notas.append(f"Finiquitado el {db.a_fecha(f['finiquito']):%d-%m-%Y}.")
        if excede:
            notas.append(f"Suma {fmt(suma_dias)} días entre obras.")
        if n_clase["pagado"]:
            con_cambio = sum(1 for g in det if g["cambios"])
            notas.append(f"{n_clase['pagado']} día(s) ya pagados en un mes anterior: no se suman"
                         + (f"; {con_cambio} con cambios respecto de lo pagado." if con_cambio else ", sin cambios."))
        if n_clase["anterior"]:
            notas.append(f"{n_clase['anterior']} día(s) antes del período sin pago registrado: no se suman.")
        if n_clase["futuro"]:
            notas.append(f"{n_clase['futuro']} día(s) del mes siguiente: no se usan este mes.")
        if not det:
            notas.append("Sin detalle diario.")
        elif not n_det:
            notas.append("El detalle no trae días de este período.")

        # Traza del cálculo, para mostrar "la magia"
        rango = f" del {db.a_fecha(cfg['desde']):%d-%m} al {db.a_fecha(cfg['hasta']):%d-%m}" if cfg["solo_periodo"] else ""
        traza = {
            "dias": (f"{dias_base} días base − {ausencias - sin_contrato} ausencia(s) del detalle{rango}"
                     + (f" − {sin_contrato} día(s) sin contrato (base 30: antes del ingreso o después del finiquito)"
                        if sin_contrato else "")
                     + f" = {fmt(p_dias)}" if n_det
                     else "Sin detalle diario del período: no se puede recalcular."),
            "he": (f"Suma de las horas extra de {n_det} día(s) del detalle{rango} = {fmt(p_he)}" if n_det
                   else "Sin detalle diario del período: no se puede recalcular."),
            "sab": {"cantidad": sab, "tarifa": t_sab, "origen": o_sab, "total": sab * t_sab},
            "dom": {"cantidad": dom, "tarifa": t_dom, "origen": o_dom, "total": dom * t_dom},
            "bonos": bonos,
            "monto": p_monto,
        }

        salida.append({
            "id": f["id"], "archivo": f["archivo"], "obra": obra, "lugar": f["lugar"], "trabajador": trabajador,
            "rut": rut, "rut_txt": formatear_rut(rut) if rut != SIN_RUT else SIN_RUT, "estado_rut": f["estado_rut"],
            "rut_como": f["rut_como"], "rut_corregido": bool(f.get("rut_corregido")),
            "falta_trabajador": falta_trabajador, "informado": {"rut": f["rut"], "nombre": f["nombre"], "apellido": f["apellido"],
                                                   "obs": f["obs"], "monto_fds": f["monto_fds"], "bonos": f["bonos"]},
            "obra_val": {"dias": o_dias, "he": o_he, "monto": o_monto, "sab": sab, "dom": dom},
            "planilla": {"dias": p_dias, "he": p_he, "monto": p_monto},
            "obra_informa_monto": obra_informa_monto,
            "alertas": {"dias": f_dias, "he": f_he, "monto": f_monto},
            "decision": {"usar": usar, "dias": d.get("dias"), "he": d.get("he"), "monto": d.get("monto")},
            "estado": estado, "pendiente": pendiente, "notas": notas,
            "talana": {"dias": v_dias, "he": v_he, "monto": v_monto},
            "fuente": {"dias": fuente_dias, "he": fuente_he, "monto": fuente_monto},
            "primera_del_rut": primera_del_rut, "suma_dias": suma_dias, "duplicados": dup, "propuesta": None,
            "_decidido": decidido,
            "traza": traza, "hojas": f["hojas"], "marcas": marcas, "finiquito": f.get("finiquito"),
            "reliquidacion": [{**c, "rut": rut, "trabajador": trabajador, "obra": obra} for c in reliq],
            "detalle": [{"fecha": g["fecha"], "tipo_dia": g["tipo_dia"], "nombre": g["nombre"], "entrada": g["entrada"],
                         "salida": g["salida"], "he": g["he"], "trabajo": g["trabajo"], "ausencia": g["ausencia"],
                         "obs": g["obs"], "en_periodo": g["en_periodo"], "duplicado": g["duplicado"],
                         "clase": g["clase"], "cambios": g["cambios"], "fds_fiable": g.get("fds_fiable"),
                         "sin_contrato": g.get("sin_contrato", False)} for g in det],
        })

    if cfg["solo_periodo"]:
        dos_obras(salida, ctx)
    for s in salida:
        del s["_decidido"]

    viaticos = db.viaticos(con, cfg["periodo"])
    manuales = db.horas_manuales(con, cfg["periodo"])
    faltan = no_informados(con, ctx, salida, manuales)
    return {"config": {**cfg, "desde": db.iso(cfg["desde"]), "hasta": db.iso(cfg["hasta"])},
            "filas": salida, "talana": talana(salida, viaticos, ctx, manuales, faltan),
            "resumen": resumen(salida, viaticos, ctx, manuales, faltan), "viaticos": viaticos, "horas_manuales": manuales,
            "no_informados": faltan}


def no_informados(con, ctx, salida, manuales):
    """Trabajadores de una obra según TALANA que la planilla de esa obra no trae (pedido y confirmado el 30-10-2026).

    Solo obras cuya planilla ya se cargó este mes, trabajadores activos con contrato en el período y que no vienen
    en ninguna planilla del mes (si vienen en otra obra, ya están informados).
    - Van a TALANA con 30 días por defecto, descontando los días antes del ingreso o después del término del contrato
      (regla base 30, comun.dias_fuera_base30); RRHH puede escribir otro número.
    - Se les puede agregar horas extra o un bono a mano (tabla horas_manuales).
    - Quedan pendientes (el mes no queda listo) hasta que RRHH los marque como vistos, cambie los días o agregue algo.
    """
    cfg = ctx.cfg
    if not cfg["solo_periodo"] or not cfg["hasta"]:
        return []
    inicio, fin = cfg["hasta"].replace(day=1), cfg["hasta"]
    obras = {f["obra"] for f in salida}
    informados = {f["rut"] for f in salida}
    guardados = db.no_informados(con, cfg["periodo"])
    con_manual = {normalizar_rut(m["rut"]) for m in manuales}
    out = []
    for rut, t in ctx.por_rut.items():
        if t.get("obra") not in obras or t.get("activo") == "No" or rut in informados:
            continue
        ingreso, termino = db.a_fecha(t.get("ingreso")), db.a_fecha(t.get("contrato_hasta"))
        if (ingreso and ingreso > fin) or (termino and termino < (cfg["desde"] or inicio)):
            continue
        antes, despues = dias_fuera_base30(cfg["dias_base"], inicio, fin, ingreso, termino)
        g = guardados.get(rut) or {}
        defecto = max(0, cfg["dias_base"] - antes - despues)
        dias = g["dias"] if g.get("dias") is not None else defecto
        visto = bool(g.get("visto")) or g.get("dias") is not None or rut in con_manual
        out.append({"rut": rut, "rut_txt": t.get("rut"), "trabajador": t["muestra"], "obra": t["obra"],
                    "ingreso": db.iso(ingreso), "termino": db.iso(termino), "dias_defecto": defecto, "dias": dias,
                    "dias_editados": g.get("dias") is not None, "visto": visto, "pendiente": not visto})
    return sorted(out, key=lambda x: (clave(x["obra"]), x["trabajador"]))


def dias_trabajados(s):
    """Fechas del período (que cuentan) en que el trabajador trabajó según el detalle de esa fila."""
    return {g["fecha"] for g in s["detalle"] if g["clase"] == "cuenta" and g["trabajo"]}


def rango(fechas):
    f = sorted(fechas)
    return f"del {f[0][8:10]}-{f[0][5:7]} al {f[-1][8:10]}-{f[-1][5:7]} ({len(f)} día(s))" if f else "sin días trabajados"


def dos_obras(salida, ctx):
    """Trabajador en más de una fila del mes (regla confirmada por el usuario el 29-10-2026).

    - Apoyo (las fechas trabajadas en las otras obras están todas en su obra de TALANA): los días salen de su obra de
      TALANA; en las otras filas se proponen 0 días y RRHH acepta con un clic. Horas extra y montos se suman.
    - Reasignación (las fechas no se repiten), caso mixto, sin detalle diario, ninguna obra es la de TALANA o la misma
      obra dos veces: no se propone nada; queda en Revisar con el aviso y RRHH decide.
    Las filas que no son de su obra quedan en Revisar hasta que RRHH decida.
    """
    grupos = {}
    for s in salida:
        if s["rut"] != SIN_RUT:
            grupos.setdefault(s["rut"], []).append(s)
    for rut, filas in grupos.items():
        if len(filas) < 2:
            continue
        oficial = (ctx.por_rut.get(rut) or {}).get("obra")
        de_oficial = [s for s in filas if s["obra"] == oficial]
        otras = [s for s in filas if s not in de_oficial]
        detalle = {s["id"]: dias_trabajados(s) for s in filas}
        tramos = "; ".join(f"en {s['obra']} {rango(detalle[s['id']])}" for s in filas)

        if len(de_oficial) != 1:
            if not oficial:
                motivo = "no tiene obra en TALANA"
            elif not de_oficial:
                motivo = f"ninguna es su obra en TALANA ({oficial})"
            else:
                motivo = f"aparece {len(de_oficial)} veces en su obra de TALANA"
            tipo = f"Está en {len(filas)} filas este mes y {motivo}: elige los días ({tramos})."
        elif any(not any(g["clase"] == "cuenta" for g in s["detalle"]) for s in filas):
            tipo = ("Está en más de una obra y una no trae detalle diario: no se puede saber si fue apoyo o "
                    f"reasignación. Elige los días ({tramos}).")
        else:
            base = detalle[de_oficial[0]["id"]]
            if all(detalle[s["id"]] <= base for s in otras):
                tipo = None
            elif all(not (detalle[s["id"]] & base) for s in otras):
                tipo = f"Parece reasignación (las fechas no se repiten): elige los días ({tramos})."
            else:
                tipo = f"Está en más de una obra y solo algunas fechas se repiten: elige los días ({tramos})."

        if tipo is None:
            o = de_oficial[0]
            nombres = ", ".join(s["obra"] for s in otras)
            o["notas"].append(f"Apoyo en {nombres} (mismos días): se usan los días de esta obra, su obra en TALANA; "
                              "las horas extra de las otras obras se suman.")
            for s in otras:
                s["propuesta"] = {"dias": 0}
                s["notas"].append(f"Apoyo a {o['obra']}, su obra en TALANA (mismos días): se proponen 0 días aquí; "
                                  "las horas extra y montos de esta obra se suman.")
                pendiente_por(s)
        else:
            for s in filas:
                s["notas"].append(tipo)
                pendiente_por(s)


def pendiente_por(s):
    """Deja la fila en Revisar hasta que RRHH decida (si ya decidió, queda Revisado)."""
    if not s["_decidido"]:
        s["pendiente"], s["estado"] = True, "Revisar"
        s["alertas"]["dias"] = True


def talana(filas, viaticos=(), ctx=None, manuales=(), faltan=()):
    """[TALANA] Una fila por RUT (en el orden en que aparecen). PENDIENTE si alguna de sus filas falta revisar.

    Viáticos (planilla de viáticos del mes, pedida el 28-10-2026) van a la columna «Viáticos», sumados por RUT.
    Quien tiene viático y no viene en ningún archivo de obra igual va a TALANA, solo con su viático.
    Viático ya pagado (Pagado = SI, confirmado el 29-10-2026): el monto va a «Viáticos» y también a
    «Descuento anticipo viático». Si no está pagado, solo a «Viáticos».
    Horas extra manuales de quienes no son de obra (confirmado el 30-10-2026): van solo a «Horas Extra Trabajadas»,
    sumadas por RUT; «Días Trabajados» queda vacío (la oficina la maneja TALANA).
    No informados por su obra (ver no_informados): sus días van a «Días Trabajados»; las horas extra y bonos a mano
    que se les agreguen, a «Horas Extra Trabajadas» y a «Asignación Desgaste de Herramientas» (como todos los bonos).
    """
    orden, por_rut = [], {}

    def fila(rut, trabajador):
        if rut not in por_rut:
            orden.append(rut)
            por_rut[rut] = {"rut": rut, "trabajador": trabajador, "obras": [], "pendiente": False,
                            "dias": 0, "he": 0, "monto": 0, "viatico": 0, "anticipo": 0,
                            "solo_viatico": True, "manual": False, "no_informado": False}
        return por_rut[rut]

    for f in filas:
        if f["rut"] == SIN_RUT:
            continue
        t = fila(f["rut"], f["trabajador"])
        t["solo_viatico"] = False
        t["obras"].append(f["obra"])
        t["pendiente"] |= f["pendiente"]
        for k in ("dias", "he", "monto"):
            t[k] += num(f["talana"][k])
    for v in viaticos:
        rut = normalizar_rut(v["rut"])
        maestro = (ctx.por_rut.get(rut) if ctx else None) or {}
        t = fila(rut, maestro.get("muestra") or v["trabajador"])
        t["viatico"] += num(v["monto"])
        if v.get("pagado"):
            t["anticipo"] += num(v["monto"])
        if v.get("obra") and v["obra"] not in t["obras"]:
            t["obras"].append(v["obra"])
    for x in faltan:
        t = fila(x["rut"], x["trabajador"])
        t["dias"] += num(x["dias"])
        t["solo_viatico"], t["no_informado"] = False, True
        t["pendiente"] |= x["pendiente"]
        if x["obra"] not in t["obras"]:
            t["obras"].append(x["obra"])
    for m in manuales:
        rut = normalizar_rut(m["rut"])
        maestro = (ctx.por_rut.get(rut) if ctx else None) or {}
        t = fila(rut, maestro.get("muestra") or m["trabajador"])
        if m.get("tipo"):
            t["monto"] += num(m.get("monto"))
        else:
            t["he"] += num(m["horas"])
        t["solo_viatico"], t["manual"] = False, True
        lugar = maestro.get("obra") or maestro.get("sucursal") or "Oficina"
        if lugar not in t["obras"]:
            t["obras"].append(lugar)
    out = []
    for rut in orden:
        t = por_rut[rut]
        valores = {TALANA_DIAS: t["dias"], TALANA_HE: t["he"], TALANA_DESGASTE: t["monto"], TALANA_VIATICOS: t["viatico"],
                   TALANA_ANTICIPO_VIATICO: t["anticipo"]}
        celdas = {c: ("PENDIENTE" if t["pendiente"] else (valores[c] or None)) if c in valores else None
                  for c in TALANA_COLUMNAS[1:]}
        out.append({**t, "obras": sorted(set(t["obras"]), key=t["obras"].index), "celdas": celdas})
    return out


def resumen(filas, viaticos=(), ctx=None, manuales=(), faltan=()):
    tal = talana(filas, viaticos, ctx, manuales, faltan)
    return {
        "filas": len(filas),
        "trabajadores": len(tal),
        "obras": len({f["obra"] for f in filas}),
        "revisar": sum(1 for f in filas if f["estado"] == "Revisar"),
        "revisado": sum(1 for f in filas if f["estado"] == "Revisado"),
        "ok": sum(1 for f in filas if f["estado"] == "OK"),
        "sin_rut": sum(1 for f in filas if f["rut"] == SIN_RUT),
        "dias_detalle": sum(len(f["detalle"]) for f in filas),
        "reliquidaciones": sum(len(f.get("reliquidacion") or []) for f in filas),
        "he": sum(t["he"] for t in tal),
        "desgaste": sum(t["monto"] for t in tal),
        "viaticos": sum(t["viatico"] for t in tal),
        "anticipo_viaticos": sum(t["anticipo"] for t in tal),
        "solo_viatico": [t["trabajador"] for t in tal if t["solo_viatico"]],
        "no_informados": len(faltan),
        "no_informados_pendientes": sum(1 for x in faltan if x["pendiente"]),
        "listo": bool(filas) and not any(f["pendiente"] for f in filas) and not any(x["pendiente"] for x in faltan),
    }
